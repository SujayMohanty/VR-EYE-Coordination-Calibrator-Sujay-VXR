# Tracking record schema (v1.0)

Defined in `visionx/models/tracking_models.py` (`TrackingRecord`, `validate_record`). One record per processed frame;
both windows, the recorder, captures and replay use this single structure. Missing = `null`/`None`, never `0`.

## Conventions
| Item | Convention |
|---|---|
| `*_xy` | Source camera frame pixels, origin top-left, +x right, +y down, pixel-index convention (centre of top-left pixel = (0,0)). **Never mirrored**; mirroring is display only. |
| `*_rel` (u,v) | Eye-relative. Corner line runs from the image-left eye corner (`corner_a`) to the image-right corner (`corner_b`). u=0 at `corner_a`, u=1 at `corner_b`; v=0 on the corner line, +v toward the lower eyelid. Units: eye widths. Invariant to eye roll and scale. Pupil centre is typically u≈0.5. |
| `capture_ts` | `time.monotonic()` seconds at frame grab. `wall_time` = unix seconds. `latency_ms` = capture→record done. |
| `pupil_*_px` | Apparent size in image pixels (width/height = axis-aligned extent of the fitted ellipse; diameter = equivalent). **Not millimetres.** |
| `openness` | Eye aspect ratio (EAR) from 6 landmarks. |
| `quality` | Heuristic 0..1: detector quality × openness × stability × jump × crop-size factors. **Not a probability.** |
| `direction` | Image-plane / eye-relative label (8-way, with hysteresis), not real-world gaze direction. |
| `left` | The subject's left eye (appears on image-right when unmirrored). |

## Invariants (enforced by `validate_record`)
* `valid=True` ⇒ `status="tracking"` and `pupil_xy` present. `valid=False` ⇒ `pupil_xy`/`pupil_rel` are null (no stale coordinates).
* `candidate_xy` is the raw detector candidate; `pupil_xy` is the accepted, filtered position — the blue reticle and the displayed numbers both use `pupil_xy`.
* `gaze.valid=False` ⇒ no `norm_xy`/`direction`. `gaze.status` ∈ `not_calibrated | ok | invalid | native`.
* `provider` ∈ `webcam | native_vr | replay | test`. `test` records come only from the synthetic test provider.
* `reason` examples: `no_face`, `eye_closed`, `eye_crop_too_small`, `low_contrast`, `no_pupil_contour`, `low_quality`, `implausible_jump`, `stale`.

## Files
* Session folder `<capture.directory>/<session_id>[_n]/`: `manifest.json`, `records.jsonl`, `records.csv`, `events.jsonl`, optional `video.mp4` (opt-in).
* Captures `<capture.directory>/captures/`: `cap_<session>_<n>.json` (+ `_<artifact>.png`) and `samples.csv`.
* CSV columns: `CSV_COLUMNS` (stable names, e.g. `left_pupil_xy_x`, `right_quality`, `gaze_norm_x`).
* Events (`events.jsonl`, `record.events`): `type, ts, wall_time` + metadata. Types: `blink, eye_closure, prolonged_closure, fixation,
  saccade, smooth_pursuit_like (off by default), tracking_lost, tracking_recovered`. UI-level events (`capture_saved`) are shown in the timeline only.
