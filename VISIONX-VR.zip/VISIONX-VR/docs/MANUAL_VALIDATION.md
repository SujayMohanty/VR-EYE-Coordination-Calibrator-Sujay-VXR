# Manual validation checklist (hardware required)

Run `python scripts/check_environment.py` first. Tick each item on your machine; none of these were executed by the authors
(the build sandbox had no camera, display or PySide6).

1. [ ] **Camera starts**: Tracking ▸ Start Tracking shows live video; Diagnostics shows camera name/resolution/FPS.
2. [ ] **Face & eyes detected**: face box and eye outlines follow you; NO FACE appears when you leave frame.
3. [ ] **Blue markers follow real pupils**: look left/right/up/down — the reticle moves with the pupil. Cover one eye: that eye goes LOST (text only, no stale reticle).
4. [ ] **Both eye crops update** from the same session (Pupil Monitor, both panels live, frame numbers advance).
5. [ ] **Monitor opens/reopens without duplicating the camera**: close it, reopen several times; the camera LED stays on once; Diagnostics "Threads alive" does not grow.
6. [ ] **Reticle ↔ numbers agree**: toggle coordinates; the label equals the pupil px in the panel; Freeze view keeps the image/values frozen while plots keep running.
7. [ ] **Capture Sample** creates `captures/cap_*.json` + a row in `samples.csv`; invalid eyes are stored as invalid.
8. [ ] **Capture Image** saves the ticked artifacts (Settings ▸ Capture); double-click the history entry shows the stored files; raw ≠ annotated.
9. [ ] **Recording**: a confirmation dialog appears; REC indicator visible in both windows; Stop writes `manifest.json`, `records.csv/jsonl`.
10. [ ] **Exports** (Analytics ▸ Export): CSV/JSON row counts equal `manifest.counts.records`; timestamps monotonic.
11. [ ] **Calibration**: 9-point completes, summary shows cross-validated error, profile saves/loads; Validate shows error at independent targets.
12. [ ] **Tracking loss indicated**: look away / cover camera — LOST/NO FACE chip and `tracking_lost` event; `tracking_recovered` on return.
13. [ ] **Camera recovery**: unplug/replug USB camera — state shows reconnecting, then streaming (driver dependent).
14. [ ] **Shutdown**: File quit → camera LED off; process exits (no lingering python.exe).
15. [ ] **VR unavailable is harmless**: choose *Native VR via UDP bridge* with no headset app → clear message; switch back to Webcam and tracking works.
16. [ ] **Window layout**: two monitors and one monitor; Restore Default Window Layout; close main while monitor open (monitor stays), close monitor then main (app quits).
17. [ ] **Accuracy sanity** (research use): compare against a fixation target grid; webcam pupil tracking is approximate and lighting dependent.
