import math, unittest
import helpers  # noqa
from visionx.models.tracking_models import *


class TestModels(unittest.TestCase):
    def test_roundtrip(self):
        r = helpers.make_record(1.0, (0.5, 0.0), (0.4, 0.1))
        r.events.append(make_event("blink", 1.0, 2.0, eye="left"))
        r2 = TrackingRecord.from_dict(r.to_dict())
        self.assertEqual(r2.left.pupil_xy, r.left.pupil_xy)
        self.assertIsInstance(r2.left.pupil_xy, tuple)
        self.assertEqual(r2.events[0]["type"], "blink")
        self.assertEqual(validate_record(r2), [])

    def test_json_roundtrip_converts_lists_to_tuples(self):
        import json
        r = helpers.make_record(1.0, (0.5, 0.0), None)
        r2 = TrackingRecord.from_dict(json.loads(json.dumps(r.to_dict())))
        self.assertEqual(r2.left.pupil_rel, (0.5, 0.0))
        self.assertEqual(r2.frame_size, (640, 480))

    def test_valid_requires_coordinates(self):
        r = TrackingRecord(); r.left.valid, r.left.status = True, "tracking"
        self.assertTrue(any("pupil_xy missing" in p for p in validate_record(r)))

    def test_stale_coordinates_rejected_when_invalid(self):
        r = TrackingRecord(); r.right.pupil_xy = (1.0, 2.0)
        self.assertTrue(any("stale" in p for p in validate_record(r)))
        with self.assertRaises(ValueError):
            r.validate()

    def test_nan_and_range(self):
        r = helpers.make_record(0, (0.5, 0), None); r.left.pupil_xy = (math.nan, 1.0)
        self.assertTrue(any("not finite" in p for p in validate_record(r)))
        r = TrackingRecord(); r.left.quality = 1.5
        self.assertTrue(any("quality" in p for p in validate_record(r)))

    def test_gaze_invalid_cannot_carry_coords(self):
        r = TrackingRecord(); r.gaze.norm_xy = (0.5, 0.5)
        self.assertTrue(any("stale" in p for p in validate_record(r)))

    def test_flatten_columns_stable_and_missing_is_none(self):
        row = flatten_record(TrackingRecord())
        self.assertEqual(list(row), CSV_COLUMNS)
        self.assertIsNone(row["left_pupil_xy_x"])

    def test_overall_state(self):
        self.assertEqual(overall_state(TrackingRecord()), "no_face")
        self.assertEqual(overall_state(helpers.make_record(0, None, None)), "lost")
        self.assertEqual(overall_state(helpers.make_record(0, (.5, 0), None)), "tracking")


if __name__ == "__main__":
    unittest.main()
