import tempfile, unittest
import numpy as np
import helpers  # noqa
from helpers import make_record
from visionx.calibration.calibration_manager import *
from visionx.tracking.gaze_estimator import GazeModel, fit_gaze_model, eye_features


def synth_uv(target, rng, noise=0.003):
    """SYNTHETIC user: eye-relative pupil position is a known smooth function of the gaze target."""
    x, y = target
    return (0.5 + 0.22 * (x - 0.5) + 0.02 * (x - .5) * (y - .5) + rng.normal(0, noise), 0.02 + 0.10 * (y - 0.5) + rng.normal(0, noise))


def run_cal(mgr, rng, fn=synth_uv, max_steps=20000):
    t, n = 0.0, 0
    mgr.start(t)
    while mgr.state == "running" and n < max_steps:
        tgt = mgr.current_target; uv = fn(tgt, rng)
        mgr.feed(make_record(t, uv, uv, frame_id=n), t); t += 1 / 30; n += 1
    return mgr


class TestCalibration(unittest.TestCase):
    def test_nine_point_fit_and_prediction(self):
        rng = np.random.default_rng(0)
        m = run_cal(CalibrationManager(9, 15, 300), rng)
        self.assertEqual(m.state, "done"); self.assertEqual(m.metrics["n_targets"], 9)
        for tgt in [(0.3, 0.6), (0.8, 0.2), (0.5, 0.5)]:
            f = eye_features(make_record(0, synth_uv(tgt, rng, 0), synth_uv(tgt, rng, 0)))
            px, py = m.model.predict(f)
            self.assertLess(np.hypot(px - tgt[0], py - tgt[1]), 0.05)
        self.assertLess(m.metrics["cv_mean_error_norm"], 0.08)

    def test_five_point_uses_simple_model(self):
        m = run_cal(CalibrationManager(5, 15, 0), np.random.default_rng(1))
        self.assertEqual(m.state, "done"); self.assertEqual(m.model.degree, 1)   # only degree 1 is validatable

    def test_settle_time_and_quality_rejection(self):
        m = CalibrationManager(5, 5, 500, min_quality=0.5); m.start(0.0)
        m.feed(make_record(0.1, (0.5, 0), (0.5, 0)), 0.1)
        self.assertEqual(m.status()["collected"], 0)                     # inside settle window
        m.feed(make_record(0.7, (0.5, 0), (0.5, 0), quality=0.2), 0.7)
        self.assertEqual(m.status()["collected"], 0); self.assertEqual(m.status()["rejected"], 1)
        m.feed(make_record(0.8, None, None), 0.8)                        # no valid eye
        self.assertEqual(m.status()["collected"], 0)
        m.feed(make_record(0.9, (0.5, 0), (0.5, 0)), 0.9); self.assertEqual(m.status()["collected"], 1)

    def test_retry_skip_cancel_pause(self):
        rng = np.random.default_rng(2); m = CalibrationManager(5, 5, 0); m.start(0.0)
        m.feed(make_record(0.1, (0.5, 0), (0.5, 0)), 0.1); m.retry_current(0.2)
        self.assertEqual(m.status()["collected"], 0)
        m.skip_current(0.3); self.assertEqual(m.status()["target_index"], 1); self.assertEqual(m.status()["skipped"], [0])
        m.pause(0.4); m.feed(make_record(0.5, (0.5, 0), (0.5, 0)), 0.5); self.assertEqual(m.status()["collected"], 0)
        m.resume(1.0); m.cancel(); self.assertEqual(m.state, "cancelled")

    def test_needs_attention_after_timeout(self):
        m = CalibrationManager(5, 5, 0, timeout_s=2.0); m.start(0.0)
        m.feed(make_record(5.0, None, None), 5.0); self.assertTrue(m.needs_attention)

    def test_too_few_targets_fails_gracefully(self):
        m = CalibrationManager(5, 5, 0); m.start(0.0)
        for _ in range(3): m.skip_current(0.0)
        for i in range(10):
            if m.state != "running": break
            m.feed(make_record(i, (0.5, 0), (0.5, 0)), i)
        self.assertEqual(m.state, "failed"); self.assertIn("targets", m.error)

    def test_validation_with_independent_targets(self):
        rng = np.random.default_rng(3)
        cal = run_cal(CalibrationManager(9, 15, 0), rng)
        v = run_cal(CalibrationManager(mode="validate", model=cal.model, samples_per_point=15, settle_ms=0), rng)
        self.assertEqual(v.state, "done"); self.assertLess(v.metrics["mean_accuracy_norm"], 0.05)
        bad = lambda tgt, r: synth_uv((1 - tgt[0], 1 - tgt[1]), r)          # user looks elsewhere -> large error
        v2 = run_cal(CalibrationManager(mode="validate", model=cal.model, samples_per_point=10, settle_ms=0), rng, bad)
        self.assertGreater(v2.metrics["mean_accuracy_norm"], 0.2)

    def test_profile_roundtrip_and_delete(self):
        cal = run_cal(CalibrationManager(9, 10, 0), np.random.default_rng(4))
        with tempfile.TemporaryDirectory() as d:
            save_profile(d, "Alice 1", cal.model, {"width": 1280})
            self.assertEqual(list_profiles(d), ["Alice 1"])
            m2, doc = load_profile(d, "Alice 1")
            f = np.array([0.52, 0.03]); self.assertEqual(cal.model.predict(f), m2.predict(f))
            self.assertIn("NOT a native VR", doc["warning"])
            self.assertTrue(delete_profile(d, "Alice 1")); self.assertEqual(list_profiles(d), [])
            with self.assertRaises(ValueError): save_profile(d, "///", cal.model, {})

    def test_bad_model_version_rejected(self):
        with self.assertRaises(ValueError): GazeModel.from_dict({"model_version": "9.0"})


if __name__ == "__main__":
    unittest.main()
