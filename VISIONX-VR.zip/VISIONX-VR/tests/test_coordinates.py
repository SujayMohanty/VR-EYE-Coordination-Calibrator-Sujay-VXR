import unittest
import numpy as np
import helpers  # noqa
from visionx.utils.coordinate_transforms import *


class TestTransforms(unittest.TestCase):
    def test_roundtrip_all_configs(self):
        for mirror in (False, True):
            for dst in ((800, 500), (300, 900), (1280, 720)):
                vt = ViewTransform.fit(640, 480, *dst, mirror=mirror)
                for p in [(0, 0), (320.5, 100.25), (639, 479)]:
                    q = vt.to_source(*vt.to_view(*p))
                    self.assertAlmostEqual(q[0], p[0], 6); self.assertAlmostEqual(q[1], p[1], 6)

    def test_aspect_preserved_and_centered(self):
        vt = ViewTransform.fit(640, 480, 800, 800)
        self.assertAlmostEqual(vt.scale, 1.25)
        self.assertAlmostEqual(vt.off_x, 0.0); self.assertAlmostEqual(vt.off_y, 100.0)

    def test_mirror_flips_x(self):
        a = ViewTransform.fit(100, 50, 100, 50, mirror=False).to_view(10, 20)
        b = ViewTransform.fit(100, 50, 100, 50, mirror=True).to_view(10, 20)
        self.assertAlmostEqual(a[0], 10); self.assertAlmostEqual(b[0], 89); self.assertAlmostEqual(a[1], b[1])

    def test_render_matches_to_view(self):
        """A single bright pixel must land where to_view() says (checks image warp == point maths)."""
        for mirror in (False, True):
            for dst in ((320, 240), (1000, 700), (500, 500)):
                src = np.zeros((48, 64, 3), np.uint8); src[20, 41] = 255
                vt = ViewTransform.fit(64, 48, *dst, mirror=mirror)
                out = vt.render(src, bg=(0, 0, 0)).astype(float).sum(2)
                ys, xs = np.mgrid[0:out.shape[0], 0:out.shape[1]]
                cx, cy = (out * xs).sum() / out.sum(), (out * ys).sum() / out.sum()
                ex, ey = vt.to_view(41, 20)
                self.assertLess(abs(cx - ex), 0.8, (mirror, dst, cx, ex)); self.assertLess(abs(cy - ey), 0.8)

    def test_vector_matches_scalar(self):
        vt = ViewTransform.fit(640, 480, 777, 555, mirror=True)
        pts = np.array([[1.0, 2.0], [300.0, 400.5]])
        arr = vt.to_view_arr(pts)
        for p, a in zip(pts, arr):
            self.assertTrue(np.allclose(vt.to_view(*p), a))

    def test_crop_mapping(self):
        box = (30, 40, 90, 80)
        self.assertEqual(frame_to_crop(crop_to_frame((5.5, 6.5), box), box), (5.5, 6.5))

    def test_rel_coords_and_roll_invariance(self):
        a, b = (100.0, 100.0), (180.0, 100.0)
        self.assertEqual(rel_from_corners((140.0, 100.0), a, b), (0.5, 0.0))
        u, v = rel_from_corners((140.0, 108.0), a, b)
        self.assertAlmostEqual(v, 0.1)           # +v is down
        # rotate eye by 30 deg: same (u, v)
        th = np.radians(30); R = np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]])
        f = lambda p: tuple(np.array(a) + R @ (np.array(p) - np.array(a)))
        u2, v2 = rel_from_corners(f((140.0, 108.0)), a, f(b))
        self.assertAlmostEqual(u, u2); self.assertAlmostEqual(v, v2)
        back = rel_to_frame((u, v), a, b)
        self.assertAlmostEqual(back[0], 140.0); self.assertAlmostEqual(back[1], 108.0)

    def test_degenerate_corners(self):
        self.assertIsNone(rel_from_corners((1, 1), (5, 5), (5, 5)))


if __name__ == "__main__":
    unittest.main()
