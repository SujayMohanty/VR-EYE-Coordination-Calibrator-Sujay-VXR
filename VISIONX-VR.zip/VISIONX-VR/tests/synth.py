"""SYNTHETIC test data. Draws a cartoon face with a known pupil position so detector/pipeline
behaviour can be unit-tested. Passing these tests does NOT demonstrate real-world accuracy."""
from __future__ import annotations

import math
from typing import Dict, Optional, Tuple

import cv2
import numpy as np

from visionx.tracking.eye_region import SIDES
from visionx.tracking.landmark_tracker import FaceLandmarks, LandmarkTracker

W, H = 640, 480
EYE_W = 80.0
CENTERS = {"right": (230.0, 230.0), "left": (410.0, 230.0)}   # subject-right appears image-left


def eye_ellipse_axes(open_frac: float = 1.0):
    return EYE_W / 2, 12.0 * open_frac + 0.5


def draw_face(pupil_off: Dict[str, Tuple[float, float]], open_frac: float = 1.0, highlight: bool = True,
              noise: float = 0.0, seed: int = 0, iris_bgr=(70, 95, 125)) -> np.ndarray:
    img = np.full((H, W, 3), (150, 170, 205), np.uint8)
    for side, (cx, cy) in CENTERS.items():
        a, b = eye_ellipse_axes(open_frac)
        mask = np.zeros((H, W), np.uint8)
        cv2.ellipse(mask, (int(cx), int(cy)), (int(a), int(b)), 0, 0, 360, 255, -1)
        layer = img.copy()
        cv2.ellipse(layer, (int(cx), int(cy)), (int(a), int(b)), 0, 0, 360, (225, 225, 230), -1)
        ox, oy = pupil_off[side]
        px, py = cx + ox, cy + oy
        cv2.circle(layer, (int(round(px * 16)) // 16, int(round(py * 16)) // 16), 11, iris_bgr, -1, cv2.LINE_AA)
        cv2.circle(layer, (int(round(px)), int(round(py))), 5, (12, 12, 15), -1, cv2.LINE_AA)
        if highlight:
            cv2.circle(layer, (int(round(px)) + 3, int(round(py)) - 3), 1, (255, 255, 255), -1)
        img[mask > 0] = layer[mask > 0]
    if noise:
        rng = np.random.default_rng(seed)
        img = np.clip(img.astype(np.float32) + rng.normal(0, noise, img.shape), 0, 255).astype(np.uint8)
    return img


def make_landmarks(pupil_off: Dict[str, Tuple[float, float]], open_frac: float = 1.0) -> np.ndarray:
    P = np.zeros((478, 2), np.float32)
    P[:] = (W / 2, H / 2)
    a, b = eye_ellipse_axes(open_frac)
    for side, (cx, cy) in CENTERS.items():
        d = SIDES[side]
        # which contour index sits at theta=pi (image-left corner)?
        img_left, img_right = (d["outer"], d["inner"]) if side == "right" else (d["inner"], d["outer"])
        P[img_left] = (cx - a, cy)
        P[img_right] = (cx + a, cy)
        cont = d["contour"]
        ci = {v: i for i, v in enumerate(cont)}
        # arcs: upper from img_left -> img_right, lower back
        seq_up = cont[ci[d["outer"]] + 1:ci[d["inner"]]] if side == "left" else cont[1:ci[d["inner"]]]
        seq_lo = [c for c in cont if c not in seq_up and c not in (d["outer"], d["inner"])]
        up = list(seq_up) if side == "right" else list(reversed(seq_up))   # order img_left->img_right
        lo = list(reversed(seq_lo)) if side == "right" else list(seq_lo)   # order img_left->img_right
        for arc, sign in ((up, -1), (lo, 1)):
            n = len(arc)
            for k, idx in enumerate(arc):
                th = math.pi * (k + 1) / (n + 1)
                P[idx] = (cx - a * math.cos(th), cy + sign * b * math.sin(th))
        e = d["ear"]
        xo = 0.25 * a
        k = math.sqrt(1 - 0.0625)
        if side == "right":   # 160 top-outer(img-left), 158 top-inner, 153 bottom-inner, 144 bottom-outer
            P[e[1]], P[e[2]], P[e[4]], P[e[5]] = (cx - xo, cy - b * k), (cx + xo, cy - b * k), \
                                                 (cx + xo, cy + b * k), (cx - xo, cy + b * k)
        else:                 # 385 top-inner(img-left), 387 top-outer, 373 bottom-outer, 380 bottom-inner
            P[e[1]], P[e[2]], P[e[4]], P[e[5]] = (cx - xo, cy - b * k), (cx + xo, cy - b * k), \
                                                 (cx + xo, cy + b * k), (cx - xo, cy + b * k)
        ox, oy = pupil_off[side]
        P[d["iris"]] = (cx + ox, cy + oy)
        for j, idx in enumerate(d["ring"]):
            ang = j * math.pi / 2
            P[idx] = (cx + ox + 11 * math.cos(ang), cy + oy + 11 * math.sin(ang))
    return P


class SyntheticLandmarkTracker(LandmarkTracker):
    """TEST-ONLY landmark source that returns the ground-truth geometry of draw_face()."""
    def __init__(self):
        self.pupil_off = {"left": (0.0, 0.0), "right": (0.0, 0.0)}
        self.open_frac = 1.0
        self.present = True

    def process(self, frame, ts) -> Optional[FaceLandmarks]:
        if not self.present:
            return None
        return FaceLandmarks(make_landmarks(self.pupil_off, self.open_frac))
