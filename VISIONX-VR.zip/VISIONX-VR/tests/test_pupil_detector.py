import unittest
import numpy as np, cv2
import helpers  # noqa
from synth import draw_face, make_landmarks, CENTERS
from visionx.tracking.eye_region import build_eye_geometry
from visionx.tracking.pupil_detector import detect_pupil
from visionx.utils.coordinate_transforms import frame_to_crop


def run(side, off, **kw):
    po = {"left": off, "right": off}
    fr = draw_face(po, **kw)
    g = build_eye_geometry(make_landmarks(po, kw.get("open_frac", 1.0)), side, 640, 480)
    x0, y0, x1, y1 = g.box
    crop = fr[y0:y1, x0:x1]
    poly = [frame_to_crop(tuple(p), g.box) for p in g.contour]
    r = detect_pupil(crop, frame_to_crop(g.iris_center, g.box), g.iris_radius, poly)
    cx, cy = CENTERS[side]
    return r, (r.center[0] + x0 - (cx + off[0]), r.center[1] + y0 - (cy + off[1])) if r.found else None, g


class TestPupil(unittest.TestCase):
    def test_localises_known_pupils_subpixel(self):
        errs = []
        for side in ("left", "right"):
            for off in [(0, 0), (5, 1), (-6, -2), (3, 3), (-4, 2)]:
                r, e, _ = run(side, off, noise=2.0)
                self.assertTrue(r.found, (side, off, r.reason))
                errs.append(np.hypot(*e))
        self.assertLess(max(errs), 1.0, errs)

    def test_diameter_estimate(self):
        r, _, _ = run("left", (0, 0))
        self.assertAlmostEqual(r.diameter, 10.0, delta=1.5)    # true pupil diameter 10 px (synthetic)

    def test_highlight_does_not_shift_centre(self):
        a = run("left", (4, 0), highlight=True)[1]; b = run("left", (4, 0), highlight=False)[1]
        self.assertLess(np.hypot(*a), 1.0); self.assertLess(np.hypot(*b), 1.0)

    def test_low_contrast_reports_not_found(self):
        # pupil the same grey as the iris -> there is nothing to find; must not invent a centre
        po = {"left": (0, 0), "right": (0, 0)}
        fr = draw_face(po)
        g = build_eye_geometry(make_landmarks(po), "left", 640, 480)
        x0, y0, x1, y1 = g.box
        crop = np.full((y1 - y0, x1 - x0, 3), 120, np.uint8)
        r = detect_pupil(crop, frame_to_crop(g.iris_center, g.box), g.iris_radius)
        self.assertFalse(r.found); self.assertIsNone(r.center); self.assertEqual(r.reason, "low_contrast")

    def test_empty_crop(self):
        self.assertEqual(detect_pupil(np.zeros((0, 0, 3), np.uint8)).reason, "empty_crop")

    def test_debug_view_is_crop_sized_and_derived(self):
        r, _, g = run("right", (0, 0))
        x0, y0, x1, y1 = g.box
        self.assertEqual(r.debug.shape[:2], (y1 - y0, x1 - x0))

    def test_dark_iris_low_contrast_is_flagged_not_wrong(self):
        r, e, _ = run("left", (0, 0), iris_bgr=(30, 30, 35))   # near-black iris: hard case
        if r.found:                                           # if found it must still be accurate
            self.assertLess(np.hypot(*e), 2.0)
        else:
            self.assertIsNone(r.center)


if __name__ == "__main__":
    unittest.main()
