import json, time, unittest, math
import helpers  # noqa
from visionx.vr.transport import *
from visionx.vr.udp_provider import UdpBridgeProvider
from visionx.vr.gaze_interaction import GazeInteractionEngine, Target
from visionx.vr.openxr_adapter import probe_openxr, OpenXRProvider
from visionx.vr.synthetic_provider import SyntheticGazeProvider


class TestPackets(unittest.TestCase):
    def test_roundtrip_and_normalisation(self):
        p = decode_packet(encode_packet(3, 1.5, True, [0, 1, 0], [0, 0, -2], 0.9))
        self.assertEqual(p.direction, (0.0, 0.0, -1.0)); self.assertEqual(p.seq, 3)

    def test_invalid_packet_carries_no_coordinates(self):
        p = decode_packet(encode_packet(1, 1.0, False, [1, 2, 3], [0, 0, 1], 0.1))
        self.assertIsNone(p.origin); self.assertIsNone(p.direction)

    def test_rejections(self):
        bad = [b"{", b"[]", json.dumps({"v": 2}).encode(), encode_packet(1, 1, True, None, None),
               encode_packet(1, 1, True, None, [0, 0, 0]), json.dumps({"v": 1, "seq": 1, "t": 1, "valid": True, "direction": [float("nan"), 0, 1]}).encode(),
               encode_packet(1, 1, True, None, [0, 0, 1], 1.5), b"x" * 5000, json.dumps({"v": 1, "seq": 1, "t": 1, "valid": "yes"}).encode()]
        for b in bad:
            with self.assertRaises(PacketError, msg=b[:30]): decode_packet(b)


class TestUdp(unittest.TestCase):
    def setUp(self):
        self.prov = UdpBridgeProvider(0, stale_ms=150, session_id="s"); st = self.prov.start()
        if not st.initialized: self.skipTest(st.detail)
        self.tx = UdpGazeSender(self.prov.rx.port)

    def tearDown(self):
        self.tx.close(); self.prov.stop()

    def wait_rec(self, t=1.0):
        t0 = time.time()
        while time.time() - t0 < t:
            r = self.prov.poll()
            if r: return r
            time.sleep(0.01)

    def test_valid_gaze_is_native_vr_not_webcam(self):
        self.tx.send(True, [0, 1.6, 0], [0, 0, -1], 0.95)
        r = self.wait_rec()
        self.assertEqual(r.provider, "native_vr"); self.assertTrue(r.gaze.valid); self.assertEqual(r.gaze.status, "native")
        self.assertEqual(r.gaze.direction, (0, 0, -1)); self.assertTrue(self.prov.status().valid_gaze_received)
        self.assertEqual(r.validate().provider, "native_vr")

    def test_stale_data_becomes_invalid_not_reused(self):
        self.tx.send(True, None, [0, 0, -1], 1.0); self.assertTrue(self.wait_rec().gaze.valid)
        time.sleep(0.3); r = self.wait_rec(0.5)
        self.assertFalse(r.gaze.valid); self.assertEqual(r.gaze.reason, "stale"); self.assertIsNone(r.gaze.direction)
        self.assertFalse(self.prov.status().valid_gaze_received)
        time.sleep(0.2); self.assertIsNone(self.prov.poll())            # reported once, not every poll

    def test_headset_invalid_flag(self):
        self.tx.send(False); r = self.wait_rec(); self.assertFalse(r.gaze.valid); self.assertEqual(r.gaze.reason, "headset_reports_invalid")

    def test_garbage_counted(self):
        import socket; s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.sendto(b"junk", ("127.0.0.1", self.prov.rx.port)); s.close()
        time.sleep(0.2); self.assertEqual(self.prov.rx.rejected, 1)


class TestProvidersHonesty(unittest.TestCase):
    def test_synthetic_provider_labelled(self):
        p = SyntheticGazeProvider(); r = p.poll()
        self.assertEqual(r.provider, "test"); self.assertIn("NOT real", p.name); self.assertEqual(r.notes, "SYNTHETIC")

    def test_openxr_never_claims_tracking(self):
        st = OpenXRProvider().start()
        self.assertFalse(st.initialized); self.assertFalse(st.valid_gaze_received); self.assertIsNone(OpenXRProvider().poll())
        self.assertIsInstance(probe_openxr().detail, str)


class TestInteraction(unittest.TestCase):
    def eng(self, **kw):
        e = GazeInteractionEngine(dwell_ms=500, cooldown_ms=1000, **kw); e.add_target(Target("A", (0.4, 0.4, 0.6, 0.6))); e.add_target(Target("B", (0.7, 0.4, 0.9, 0.6))); return e

    def run_gaze(self, e, seq, dt=0.05, t0=0.0, **kw):
        ev = []
        for i, (v, xy) in enumerate(seq): ev += e.update(t0 + i * dt, v, xy, **kw)
        return ev

    def types(self, ev): return [x["type"] for x in ev]

    def test_enter_dwell_select_once(self):
        ev = self.run_gaze(self.eng(), [(True, (0.5, 0.5))] * 40)      # 2 s on target, cooldown 1 s
        t = self.types(ev); self.assertEqual(t[0], "gaze_enter"); self.assertEqual(t.count("select"), 1)

    def test_cancel_rules(self):
        for seq, reason in [([(True, (0.5, 0.5))] * 3 + [(False, None)], "invalid_gaze"),
                            ([(True, (0.5, 0.5))] * 3 + [(True, (0.8, 0.5))], "target_changed"),
                            ([(True, (0.5, 0.5))] * 3 + [(True, (0.1, 0.1))], "left_target")]:
            ev = self.run_gaze(self.eng(), seq); c = [x for x in ev if x["type"] == "dwell_cancel"]
            self.assertEqual(c[0]["reason"], reason); self.assertNotIn("select", self.types(ev))

    def test_pause_and_provider_change_cancel(self):
        e = self.eng(); self.run_gaze(e, [(True, (0.5, 0.5))] * 3, provider="webcam")
        self.assertEqual(self.types(e.update(0.2, True, (0.5, 0.5), provider="native_vr"))[0], "dwell_cancel")
        e2 = self.eng(); self.run_gaze(e2, [(True, (0.5, 0.5))] * 3)
        self.assertEqual(e2.update(0.2, True, (0.5, 0.5), paused=True)[0]["reason"], "paused")

    def test_low_quality_gaze_ignored(self):
        e = self.eng(min_quality=0.6); ev = self.run_gaze(e, [(True, (0.5, 0.5))] * 30, quality=0.3)
        self.assertEqual(ev, [])

    def test_blink_select_disabled_by_default_and_confirm(self):
        e = self.eng(); self.run_gaze(e, [(True, (0.5, 0.5))] * 2)
        self.assertIsNone(e.on_blink(1.0)); self.assertEqual(e.confirm(1.0)["method"], "confirm"); self.assertIsNone(e.confirm(1.1))   # cooldown
        e2 = self.eng(blink_select=True); self.run_gaze(e2, [(True, (0.5, 0.5))] * 2); self.assertEqual(e2.on_blink(1.0)["method"], "blink")


if __name__ == "__main__":
    unittest.main()
