"""Shared helpers for tests. Everything built here is SYNTHETIC."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for p in (str(ROOT), str(ROOT / "tests")):
    if p not in sys.path:
        sys.path.insert(0, p)

from visionx.models.tracking_models import EyeMeasurement, TrackingRecord  # noqa: E402


def make_record(ts, left_uv=None, right_uv=None, openness=0.3, session="s", frame_id=0, face=True,
                quality=0.9, calib=None):
    r = TrackingRecord(session_id=session, frame_id=frame_id, capture_ts=ts, wall_time=1_700_000_000 + ts,
                       frame_size=(640, 480), face_detected=face, calibration_id=calib)
    for side, uv in (("left", left_uv), ("right", right_uv)):
        e = r.eye(side)
        e.openness = openness if face else None
        e.corner_a, e.corner_b = (100.0, 100.0), (180.0, 100.0)
        if uv is not None:
            e.valid, e.status, e.provenance, e.quality = True, "tracking", "pupil_detector", quality
            e.pupil_rel = tuple(uv)
            e.pupil_xy = (100.0 + 80 * uv[0], 100.0 + 80 * uv[1])
    r.state = "tracking" if (left_uv or right_uv) else ("lost" if face else "no_face")
    return r
