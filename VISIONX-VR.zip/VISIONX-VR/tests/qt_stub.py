"""NOT PySide6. A permissive stand-in so GUI *Python logic* can be executed where Qt is unavailable.
It cannot validate real Qt API usage, layout or painting."""
import sys, types


class _Meta(type):
    def __getattr__(cls, n):
        if n.startswith('__'): raise AttributeError(n)
        return _D()


class _D(metaclass=_Meta):
    """Absorbs any attribute/call; numeric-ish so simple arithmetic works."""
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        if n.startswith("__"): raise AttributeError(n)
        return _D()
    def __call__(self, *a, **k): return _D()
    def __iter__(self): return iter(())
    def __int__(self): return 0
    def __index__(self): return 0
    def __float__(self): return 0.0
    def __bool__(self): return True
    def __or__(self, o): return self
    __ror__ = __and__ = __rand__ = __invert__ = __or__
    def __lt__(self, o): return False
    __gt__ = __le__ = __ge__ = __lt__
    def __add__(self, o): return self
    __radd__ = __sub__ = __rsub__ = __mul__ = __rmul__ = __truediv__ = __rtruediv__ = __neg__ = __add__


class _BoundSignal:
    def __init__(self): self.cbs = []
    def connect(self, f, *a): self.cbs.append(f)
    def emit(self, *a):
        for f in list(self.cbs): f(*a)
    def disconnect(self, *a): pass


class Signal:
    def __init__(self, *types): pass
    def __set_name__(self, owner, name): self.name = "_sig_" + name
    def __get__(self, obj, owner=None):
        if obj is None: return self
        if self.name not in obj.__dict__: obj.__dict__[self.name] = _BoundSignal()
        return obj.__dict__[self.name]


def Slot(*a, **k): return lambda f: f


class _W(_D):
    _vis = False
    def __init__(self, *a, **k): self._geo = None
    def width(self): return 640
    def height(self): return 400
    def isVisible(self): return self._vis
    def show(self): self._vis = True
    def hide(self): self._vis = False
    def isMinimized(self): return False
    def windowState(self): return 0
    def setWindowState(self, s): pass
    def setGeometry(self, r): self._geo = r
    def geometry(self): return _D()
    def screen(self): return _D()
    def value(self): return 10.0
    def text(self): return ""
    def isChecked(self): return True
    def currentText(self): return "overlay"
    def count(self): return 0
    def currentItem(self): return None
    def isSliderDown(self): return False
    def verticalScrollBar(self): return _D()


class QObject(_W):
    def __init__(self, *a, **k): super().__init__()
class QTimer(_W):
    def __init__(self, *a, **k): self.timeout = _BoundSignal()
class QAction(_W):
    def __init__(self, *a, **k): self.triggered = _BoundSignal(); self.toggled = _BoundSignal(); self._en = True; self._tt = ""
    def setEnabled(self, v): self._en = v
    def setToolTip(self, t): self._tt = t
    def text(self): return "act"
class _Btn(_W):
    def __init__(self, *a, **k): self.clicked = _BoundSignal(); self.toggled = _BoundSignal(); self._en = True
    def setEnabled(self, v): self._en = v


def install():
    names_w = ["QWidget", "QMainWindow", "QDialog", "QGroupBox", "QLabel", "QListWidget", "QListWidgetItem", "QScrollArea", "QSplitter",
               "QToolBar", "QVBoxLayout", "QHBoxLayout", "QFormLayout", "QSizePolicy", "QMessageBox", "QFileDialog", "QInputDialog",
               "QColorDialog", "QDialogButtonBox", "QTabWidget", "QPlainTextEdit", "QLineEdit", "QApplication", "QSlider"]
    btn = ["QPushButton", "QToolButton", "QCheckBox", "QComboBox", "QSpinBox", "QDoubleSpinBox"]
    core = types.ModuleType("PySide6.QtCore"); gui = types.ModuleType("PySide6.QtGui"); wid = types.ModuleType("PySide6.QtWidgets")
    pk = types.ModuleType("PySide6")
    core.Qt = _D(); core.Signal, core.Slot, core.QObject, core.QTimer = Signal, Slot, QObject, QTimer
    for n in ("QPointF", "QRectF", "QSize", "QUrl", "QRect"): setattr(core, n, _D)
    gui.QAction = QAction; gui.QActionGroup = _D
    for n in ("QColor", "QFont", "QImage", "QPainter", "QPen", "QPixmap", "QDesktopServices", "QGuiApplication"): setattr(gui, n, _D)
    for n in names_w: setattr(wid, n, type(n, (_W,), {}))
    for n in btn: setattr(wid, n, type(n, (_Btn,), {}))
    wid.QApplication.setOverrideCursor = staticmethod(lambda *a: None); wid.QApplication.restoreOverrideCursor = staticmethod(lambda *a: None)
    gui.QGuiApplication = type("QGuiApplication", (_D,), {"screens": staticmethod(lambda: []), "primaryScreen": staticmethod(lambda: None)})
    pk.QtCore, pk.QtGui, pk.QtWidgets = core, gui, wid
    sys.modules.update({"PySide6": pk, "PySide6.QtCore": core, "PySide6.QtGui": gui, "PySide6.QtWidgets": wid})
