"""The blue reticle must be drawn exactly where the numeric coordinate says (main view AND eye view)."""
import time, unittest
import numpy as np
import helpers  # noqa
from synth import draw_face, SyntheticLandmarkTracker
from visionx.config import Settings
from visionx.render.overlay import *
from visionx.render.trails import TrailSet, TrailBuffer
from visionx.tracking.webcam_provider import WebcamTrackingEngine
from visionx.utils.coordinate_transforms import ViewTransform

SEC = np.array(hexbgr("#40E7FF"))


def centroid_of_secondary(img, near, radius=60):
    m = (np.abs(img.astype(int) - SEC).sum(2) == 0)
    ys, xs = np.nonzero(m)
    k = np.hypot(xs - near[0], ys - near[1]) < radius
    return (xs[k].mean(), ys[k].mean(), int(k.sum())) if k.any() else None


def make_bundle(off=(5, 2), quality=1.0, tracker_present=True):
    s = Settings(); s.set("tracking.head_pose", False); s.set("tracking.smoothing_method", "none")
    tr = SyntheticLandmarkTracker(); tr.pupil_off = {"left": off, "right": off}; tr.present = tracker_present
    b = WebcamTrackingEngine(s, tr, "s").process(draw_face(tr.pupil_off), time.monotonic(), 1)
    for e in (b.record.left, b.record.right):
        if e.valid: e.quality = quality                 # symmetric confidence arc for centroid test
    return b


OPTS = dict(coords=False, trail=False, gaze=False, eye_outline=False, iris=False, face_box=False)


class TestReticle(unittest.TestCase):
    def test_main_view_reticle_centered_on_accepted_coordinate(self):
        b = make_bundle()
        for mirror in (False, True):
            for size in ((800, 600), (1280, 720), (500, 700)):
                img = render_main(b, size, OverlayOptions(mirror=mirror, **OPTS))
                vt = ViewTransform.fit(640, 480, *size, mirror)
                for side in ("left", "right"):
                    e = b.record.eye(side); ex, ey = vt.to_view(*e.pupil_xy)
                    c = centroid_of_secondary(img, (ex, ey))
                    self.assertIsNotNone(c, (mirror, size, side))
                    self.assertLess(np.hypot(c[0] - ex, c[1] - ey), 1.2, (mirror, size, side, c, (ex, ey)))

    def test_eye_panel_reticle_centered(self):
        b = make_bundle((-4, 1))
        for mirror in (False, True):
            for zoom in (1.0, 2.0):
                img = render_eye(b, "left", (480, 320), OverlayOptions(mirror=mirror, **OPTS), "overlay", zoom)
                e = b.record.left; x0, y0, x1, y1 = e.eye_box
                vt = ViewTransform.fit(x1 - x0, y1 - y0, 480, 320, mirror, zoom)
                ex, ey = vt.to_view(e.pupil_xy[0] - x0, e.pupil_xy[1] - y0)
                c = centroid_of_secondary(img, (ex, ey), 80)
                self.assertIsNotNone(c); self.assertLess(np.hypot(c[0] - ex, c[1] - ey), 1.5, (mirror, zoom, c, (ex, ey)))

    def test_annotated_capture_uses_source_orientation(self):
        b = make_bundle(); img = render_annotated_frame(b, OverlayOptions(mirror=True, **OPTS))
        e = b.record.left; c = centroid_of_secondary(img, e.pupil_xy)
        self.assertLess(np.hypot(c[0] - e.pupil_xy[0], c[1] - e.pupil_xy[1]), 1.2)

    def test_no_reticle_when_tracking_lost(self):
        b = make_bundle(tracker_present=False)
        img = render_main(b, (800, 600), OverlayOptions(mirror=False, **OPTS))
        self.assertFalse((np.abs(img.astype(int) - SEC).sum(2) == 0).any())
        self.assertFalse(((img[..., 0] > 200) & (img[..., 1] > 120) & (img[..., 2] < 40)).any())   # no electric-blue pixels at all
        b2 = make_bundle(); b2.record.left.valid = False; b2.record.left.status = "lost"; b2.record.left.pupil_xy = None
        img2 = render_eye(b2, "left", (400, 300), OverlayOptions(**OPTS), "overlay")
        self.assertFalse((np.abs(img2.astype(int) - SEC).sum(2) == 0).any())

    def test_low_confidence_draws_hollow_marker_only(self):
        b = make_bundle(); e = b.record.left
        e.valid, e.status, e.candidate_xy, e.pupil_xy = False, "low_confidence", e.pupil_xy, None
        img = render_main(b, (800, 600), OverlayOptions(**OPTS))
        vt = ViewTransform.fit(640, 480, 800, 600, False); cx, cy = vt.to_view(*e.candidate_xy)
        self.assertIsNone(centroid_of_secondary(img, (cx, cy), 40))             # no filled centre dot (not "tracking")

    def test_processed_view_is_labelled_derived_and_modes_render(self):
        b = make_bundle()
        for m in VIEW_MODES:
            img = render_eye(b, "right", (400, 240), OverlayOptions(), m)
            self.assertEqual(img.shape, (240, 400, 3)); self.assertEqual(img.dtype, np.uint8)
        a = render_eye(b, "right", (400, 240), OverlayOptions(), "raw"); p = render_eye(b, "right", (400, 240), OverlayOptions(), "processed")
        self.assertGreater(np.abs(a.astype(int) - p.astype(int)).mean(), 5)

    def test_placeholder_when_no_data(self):
        self.assertEqual(render_main(None, (320, 200), OverlayOptions()).shape, (200, 320, 3))
        self.assertEqual(render_eye(None, "left", (200, 100), OverlayOptions()).shape, (100, 200, 3))

    def test_coordinate_label_equals_record_value(self):
        b = make_bundle(); e = b.record.left
        self.assertEqual(coord_label(e), f"L ({e.pupil_xy[0]:.1f}, {e.pupil_xy[1]:.1f})")


class TestTrails(unittest.TestCase):
    def test_bounded_and_breaks(self):
        t = TrailBuffer(5)
        for i in range(10): t.push(i * 0.03, (i, i))
        self.assertEqual(len(t.q), 5)
        t.push(0.5, None); t.push(0.53, (1, 1)); t.push(0.56, (2, 2))
        self.assertEqual(len(t.polylines()), 2)             # invalid sample splits the trail

    def test_time_gap_breaks_trail(self):
        t = TrailBuffer(50)
        for i in range(3): t.push(i * 0.03, (i, 0))
        for i in range(3): t.push(2.0 + i * 0.03, (i, 5))
        self.assertEqual(len(t.polylines()), 2)

    def test_trailset_only_records_accepted(self):
        ts = TrailSet(10); r = helpers.make_record(0, (0.5, 0), None)
        ts.update(r); r2 = helpers.make_record(0.03, (0.52, 0), None); ts.update(r2)
        self.assertEqual(len(ts.px["left"].q), 2); self.assertEqual(len(ts.px["right"].q), 0)
        ts.set_maxlen(3); self.assertEqual(ts.px["left"].q.maxlen, 3); ts.clear("left"); self.assertEqual(len(ts.px["left"].q), 0)


if __name__ == "__main__":
    unittest.main()
