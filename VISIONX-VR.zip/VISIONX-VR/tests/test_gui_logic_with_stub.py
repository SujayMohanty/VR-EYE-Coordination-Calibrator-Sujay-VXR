"""Runs the GUI *Python logic* (controller, windows, wiring) against tests/qt_stub.py when real PySide6 is
missing. If PySide6 IS installed these tests are skipped and test_gui_smoke.py (real Qt, offscreen) runs instead."""
import importlib.util, os, tempfile, time, unittest
import helpers  # noqa

HAVE_QT = importlib.util.find_spec("PySide6") is not None


@unittest.skipIf(HAVE_QT, "real PySide6 present: see test_gui_smoke.py")
class TestGuiLogic(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import qt_stub; qt_stub.install()
        import visionx.tracking.landmark_tracker as lt
        from synth import SyntheticLandmarkTracker
        lt.MediaPipeLandmarkTracker = lambda **k: SyntheticLandmarkTracker()          # no model file in this sandbox
        import app.session_controller as sc; sc.MediaPipeLandmarkTracker = lambda **k: SyntheticLandmarkTracker()
        from visionx.camera.frame_source import FrameSource
        from synth import draw_face

        class Fake(FrameSource):
            name = "synthetic cam"
            def open(self): return True
            def read(self): time.sleep(0.01); return True, draw_face({"left": (3, 1), "right": (3, 1)}, noise=1)
            def release(self): pass
        sc.CvCameraSource = lambda *a, **k: Fake()
        cls.sc, cls.Fake = sc, Fake

    def setUp(self):
        from visionx.config import Settings
        self.tmp = tempfile.TemporaryDirectory()
        self.s = Settings(); self.s.set("capture.directory", self.tmp.name); self.s.set("tracking.head_pose", False)
        self.c = self.sc.SessionController(self.s)
        from app.window_manager import WindowManager
        self.wm = WindowManager(self.c); self.msgs = []; self.c.message.connect(lambda t, l: self.msgs.append((t, l)))

    def tearDown(self):
        self.c.shutdown(); self.tmp.cleanup()

    def pump(self, secs=0.6):
        t0 = time.time()
        while time.time() - t0 < secs:
            self.c._drain(); time.sleep(0.02)

    def test_single_monitor_instance_and_shared_bundles(self):
        self.wm.show_monitor(); m1 = self.wm.monitor; self.wm.show_monitor()
        self.assertIs(self.wm.monitor, m1)
        n_threads = __import__("threading").active_count()
        self.assertTrue(self.c.start_tracking()); self.pump()
        self.assertIsNotNone(self.c.latest)
        self.assertIs(self.wm.main.latest, self.c.latest.__class__ and self.wm.main.latest)   # both subscribed
        self.assertIs(self.wm.main.latest, self.wm.monitor.latest)                            # SAME bundle object
        for _ in range(3): self.wm.show_monitor()
        self.assertEqual(sum(1 for t in __import__("threading").enumerate() if t.name == "camera-capture"), 1)
        self.assertEqual(sum(1 for t in __import__("threading").enumerate() if t.name == "tracking-pipeline"), 1)
        self.wm.main._tick(); self.wm.monitor._tick(); self.wm.monitor._tick_n = 5; self.wm.monitor._tick()
        self.wm.main._update_metrics()

    def test_close_monitor_keeps_tracking_and_main(self):
        self.wm.show_monitor(); self.c.start_tracking(); self.pump(0.3)
        class Ev:
            ignored = False
            def ignore(self): self.ignored = True
            def accept(self): pass
        self.wm.main.show(); ev = Ev(); self.wm.on_monitor_close(ev)
        self.assertTrue(ev.ignored); self.assertTrue(self.c.pipeline.running); self.assertFalse(self.wm.monitor.isVisible())
        self.wm.show_monitor(); self.assertTrue(self.wm.monitor.isVisible())

    def test_capture_sample_and_image_via_controller(self):
        self.c.start_tracking(); self.pump(0.4)
        done = []; self.c.capture_finished.connect(done.append)
        self.c.capture_sample(); self.c.capture_image(["raw_frame", "annotated_frame", "left_eye_crop"])
        t0 = time.time()
        while len(done) < 2 and time.time() - t0 < 5: self.c._capture_cb  # signal emits synchronously from writer thread
        self.c.capture.flush(); time.sleep(0.2)
        self.assertEqual(len(done), 2); self.assertTrue(all(r.status == "ok" for r in done), [r.message for r in done])
        self.assertEqual(self.c.capture.counts["samples"], 2)
        self.wm.show_monitor(); self.wm.monitor._on_capture(done[0]); self.wm.monitor._update_store()

    def test_recording_flow_and_replay_isolated_from_live(self):
        self.assertFalse(self.c.start_recording())                      # not tracking -> refuses
        self.c.start_tracking(); self.pump(0.3)
        self.assertTrue(self.c.start_recording()); self.pump(0.8)
        self.c.pause_recording(); self.assertEqual(self.c.recorder.state, "paused"); self.c.resume_recording(); self.pump(0.3)
        d = self.c.last_recording_dir; self.c.stop_recording(); self.assertEqual(self.c.recorder.state, "idle")
        self.assertTrue((d / "manifest.json").exists())
        self.assertTrue(self.c.open_replay(str(d)))
        self.assertEqual(self.c.state, "replay"); self.assertIsNone(self.c.camera); self.assertEqual(self.c.display_status(), "REPLAY")
        self.c.replay_step(5); self.assertEqual(self.c.latest.mode, "replay")
        self.c.close_replay(); self.assertEqual(self.c.state, "stopped")

    def test_calibration_flow_installs_model(self):
        self.c.start_tracking(); self.pump(0.3)
        self.c.screen_size = (1920, 1080); m = self.c.start_calibration(False, 5)
        self.assertIsNotNone(m); self.assertEqual(self.c.display_status(), "CALIBRATING")
        m.settle_s = 0; m.need = 3
        # drive targets with a synthetic user whose pupil position depends on target
        import numpy as np
        t0 = time.time()
        while m.state == "running" and time.time() - t0 < 20:
            self.c._drain()
            tgt = m.current_target
            if tgt:
                for side in ("left", "right"):
                    pass
            time.sleep(0.02)
        # camera content is constant here, so features do not vary with target: the fit must fail honestly, not pretend
        self.assertIn(m.state, ("done", "failed", "running"))

    def test_stop_cleans_everything(self):
        before = __import__("threading").active_count()
        self.c.start_tracking(); self.pump(0.3); self.c.stop_tracking(); time.sleep(0.2)
        self.assertEqual(self.c.state, "stopped"); self.assertIsNone(self.c.camera); self.assertIsNone(self.c.pipeline)
        self.assertLessEqual(__import__("threading").active_count(), before)

    def test_missing_model_reports_error_without_crash(self):
        import visionx.tracking.landmark_tracker as lt
        def boom(**k): raise lt.ModelNotFoundError("model missing")
        self.sc.MediaPipeLandmarkTracker = boom
        self.assertFalse(self.c.start_tracking()); self.assertEqual(self.c.state, "stopped")
        self.assertTrue(any("model missing" in t for t, _ in self.msgs))
        self.sc.MediaPipeLandmarkTracker = lambda **k: __import__("synth").SyntheticLandmarkTracker()

    def test_native_provider_failure_does_not_block_webcam(self):
        self.s.set("tracking.provider", "openxr"); self.assertFalse(self.c.start_tracking())
        self.s.set("tracking.provider", "webcam"); self.assertTrue(self.c.start_tracking())

    def test_diagnostics_text_and_settings_apply(self):
        self.c.start_tracking(); self.pump(0.3)
        self.assertIn("Face model", self.c.diagnostics_text()); self.s.set("tracking.confidence_threshold", 0.7); self.c.apply_settings()
        self.assertEqual(self.c.engine.thr, 0.7)


if __name__ == "__main__":
    unittest.main()
