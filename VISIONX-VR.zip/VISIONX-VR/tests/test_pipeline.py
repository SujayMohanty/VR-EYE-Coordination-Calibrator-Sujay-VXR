import threading, time, unittest
import numpy as np
import helpers  # noqa
from synth import draw_face, SyntheticLandmarkTracker, CENTERS
from visionx.analysis.analysis_engine import AnalysisEngine
from visionx.camera.camera_manager import CameraCapture
from visionx.camera.frame_source import FrameSource
from visionx.config import Settings
from visionx.models.tracking_models import validate_record
from visionx.pipeline import TrackingPipeline
from visionx.tracking.webcam_provider import WebcamTrackingEngine


def engine(**kw):
    s = Settings(); s.set("tracking.smoothing_method", "none"); s.set("tracking.head_pose", False)
    for k, v in kw.items(): s.set(k.replace("__", "."), v)
    tr = SyntheticLandmarkTracker()
    return WebcamTrackingEngine(s, tr, "sess"), tr


class TestEngine(unittest.TestCase):
    def test_accepts_and_matches_truth(self):
        eng, tr = engine()
        tr.pupil_off = {"left": (5, 2), "right": (5, 2)}
        b = eng.process(draw_face(tr.pupil_off, noise=1.5), time.monotonic(), 1)
        self.assertEqual(validate_record(b.record), [])
        for s in ("left", "right"):
            e = b.record.eye(s); cx, cy = CENTERS[s]
            self.assertTrue(e.valid); self.assertEqual(e.provenance, "pupil_detector")
            self.assertLess(np.hypot(e.pupil_xy[0] - cx - 5, e.pupil_xy[1] - cy - 2), 1.0)
            self.assertIsNotNone(e.pupil_rel); self.assertIsNotNone(e.pupil_diameter_px)
        self.assertEqual(b.record.state, "tracking")

    def test_left_and_right_independent(self):
        eng, tr = engine()
        tr.pupil_off = {"left": (6, 0), "right": (-6, 0)}
        r = eng.process(draw_face(tr.pupil_off), time.monotonic(), 1).record
        self.assertGreater(r.left.pupil_rel[0], 0.5); self.assertLess(r.right.pupil_rel[0], 0.5)

    def test_no_face_clears_everything(self):
        eng, tr = engine()
        eng.process(draw_face(tr.pupil_off), 1.0, 1)
        tr.present = False
        r = eng.process(draw_face(tr.pupil_off), 1.03, 2).record
        self.assertEqual(r.state, "no_face"); self.assertEqual(validate_record(r), [])
        for e in (r.left, r.right):
            self.assertFalse(e.valid); self.assertIsNone(e.pupil_xy); self.assertEqual(e.reason, "no_face")

    def test_closed_eye_is_rejected_not_guessed(self):
        eng, tr = engine()
        tr.open_frac = 0.05
        r = eng.process(draw_face({"left": (0, 0), "right": (0, 0)}, open_frac=0.05), 1.0, 1).record
        for e in (r.left, r.right):
            self.assertFalse(e.valid); self.assertEqual(e.reason, "eye_closed"); self.assertIsNone(e.pupil_xy)
        self.assertEqual(r.state, "lost")

    def test_recovers_after_loss(self):
        eng, tr = engine()
        tr.present = False; eng.process(draw_face(tr.pupil_off), 1.0, 1)
        tr.present = True
        self.assertTrue(eng.process(draw_face(tr.pupil_off), 1.03, 2).record.left.valid)

    def test_low_confidence_candidate_not_accepted(self):
        eng, tr = engine()
        eng.thr = 0.999
        r = eng.process(draw_face(tr.pupil_off), 1.0, 1).record
        self.assertEqual(r.left.status, "low_confidence")
        self.assertIsNotNone(r.left.candidate_xy); self.assertIsNone(r.left.pupil_xy)   # candidate != accepted

    def test_iris_fallback_is_labelled(self):
        eng, tr = engine(tracking__allow_iris_fallback=True)
        r = eng.process(draw_face(tr.pupil_off, iris_bgr=(120, 120, 120)).copy() * 0 + 120, 1.0, 1).record  # featureless
        self.assertTrue(r.left.valid); self.assertEqual(r.left.provenance, "iris_fallback")
        self.assertLessEqual(r.left.quality, 0.6)

    def test_smoothing_reduces_jitter(self):
        rng = np.random.default_rng(1)
        out = {}
        for m in ("none", "ema"):
            eng, tr = engine(tracking__smoothing_method=m, tracking__smoothing_strength=0.8)
            xs = []
            for i in range(25):
                tr.pupil_off = {"left": (0, 0), "right": (0, 0)}
                xs.append(eng.process(draw_face(tr.pupil_off, noise=6, seed=i), 1.0 + i * 0.033, i).record.left.pupil_xy[0])
            out[m] = np.std(xs[5:])
        self.assertLess(out["ema"], out["none"] + 1e-9)

    def test_jump_is_penalised_then_accepted_if_persistent(self):
        from visionx.tracking.quality import EyeQuality
        from visionx.tracking.eye_region import EyeGeometry
        from visionx.tracking.pupil_detector import PupilResult
        g = EyeGeometry("left", (0, 0), (80, 0), (0, 0, 80, 40), np.zeros((4, 2), np.float32), (40, 0), 10, 0.3, 80.0)
        det = PupilResult(True, (1, 1), quality=0.9)
        q = EyeQuality(); q.accepted((0.3, 0.0))
        res = [q.assess(g, det, (0.8, 0.0), 80) for _ in range(5)]
        self.assertEqual([r[1] for r in res[:3]], ["implausible_jump"] * 3)
        self.assertLess(res[0][0], 0.35)                    # penalised
        self.assertIsNone(res[4][1]); self.assertGreater(res[4][0], 0.8)   # persistent -> accepted

class FakeSource(FrameSource):
    def __init__(self, fail_after=None):
        self.n, self.fail_after, self.opened, self.released = 0, fail_after, 0, 0
        self.name = "fake"
    def open(self): self.opened += 1; return True
    def read(self):
        time.sleep(0.005); self.n += 1
        if self.fail_after and self.n > self.fail_after: return False, None
        return True, draw_face({"left": (0, 0), "right": (0, 0)})
    def release(self): self.released += 1


class TestLifecycle(unittest.TestCase):
    def test_pipeline_runs_pauses_and_stops_cleanly(self):
        cam = CameraCapture(lambda: FakeSource()); got = []
        eng, tr = engine()
        pl = TrackingPipeline(cam, eng, AnalysisEngine(Settings()), got.append)
        before = threading.active_count()
        cam.start(); pl.start(); time.sleep(0.6)
        self.assertGreater(len(got), 5)
        pl.pause(); time.sleep(0.15); n = len(got); time.sleep(0.2)
        self.assertEqual(len(got), n)                     # paused: nothing processed
        pl.resume(); time.sleep(0.2); self.assertGreater(len(got), n)
        self.assertTrue(pl.stop()); cam.stop()
        time.sleep(0.1)
        self.assertLessEqual(threading.active_count(), before)   # no leaked threads
        self.assertEqual(cam.state, "closed")

    def test_slow_consumer_drops_instead_of_backlog(self):
        cam = CameraCapture(lambda: FakeSource()); got = []
        class Slow(WebcamTrackingEngine):
            def process(s, *a):
                time.sleep(0.05); return super().process(*a)
        s = Settings(); s.set("tracking.head_pose", False)
        pl = TrackingPipeline(cam, Slow(s, SyntheticLandmarkTracker()), AnalysisEngine(s), got.append)
        cam.start(); pl.start(); time.sleep(0.8); pl.stop(); cam.stop()
        self.assertGreater(pl.frames_dropped, 0)
        ids = [b.record.frame_id for b in got]; self.assertEqual(ids, sorted(ids))

    def test_camera_reconnects_after_failures(self):
        srcs = []
        def f():
            s = FakeSource(fail_after=10 if not srcs else None); srcs.append(s); return s
        cam = CameraCapture(f, max_failures=5, retry_s=0.05); cam.start()
        t0 = time.time()
        while len(srcs) < 2 and time.time() - t0 < 4: time.sleep(0.05)
        time.sleep(0.2); self.assertEqual(len(srcs), 2); self.assertEqual(cam.state, "streaming")
        self.assertEqual(cam.reconnects, 1); cam.stop(); self.assertEqual(srcs[-1].released, 1)

    def test_camera_open_failure_reports_error(self):
        class Bad(FakeSource):
            def open(self): return False
        cam = CameraCapture(lambda: Bad(), retry_s=0.05); cam.start(); time.sleep(0.3)
        self.assertEqual(cam.state, "error"); self.assertIn("unavailable", cam.detail); cam.stop()

    def test_get_latest_only_returns_newer(self):
        cam = CameraCapture(lambda: FakeSource()); cam.start(); time.sleep(0.1)
        p = cam.get_latest(-1, 0.5); self.assertIsNotNone(p)
        q = cam.get_latest(p.frame_id, 0.5); self.assertGreater(q.frame_id, p.frame_id); cam.stop()


if __name__ == "__main__":
    unittest.main()
