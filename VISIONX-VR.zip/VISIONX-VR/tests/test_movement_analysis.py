import math, unittest
import helpers  # noqa
from helpers import make_record
from visionx.analysis.analysis_engine import AnalysisEngine
from visionx.analysis.fixation_detector import FixationDetector
from visionx.analysis.saccade_detector import SaccadeDetector, PursuitDetector
from visionx.analysis.movement_metrics import EyeMovement


def feed(eng, pts, dt=1 / 30, t0=0.0):
    recs = []
    for i, p in enumerate(pts):
        r = make_record(t0 + i * dt, p, p, frame_id=i)
        eng.update(r); recs.append(r)
    return recs


class TestMovement(unittest.TestCase):
    def test_velocity_and_direction(self):
        eng = AnalysisEngine()
        recs = feed(eng, [(0.3 + 0.01 * i, 0.0) for i in range(15)])      # 0.3 u/s... *30 = 0.3/s? 0.01/0.0333
        e = recs[-1].left
        self.assertAlmostEqual(e.speed_uv, 0.3, delta=0.02)
        self.assertEqual(e.direction, "stable")                           # below threshold 0.35
        recs = feed(AnalysisEngine(), [(0.2 + 0.03 * i, 0.0) for i in range(15)])
        self.assertEqual(recs[-1].left.direction, "right"); self.assertGreater(recs[-1].left.velocity_uv[0], 0.8)
        recs = feed(AnalysisEngine(), [(0.5, 0.0 + 0.03 * i) for i in range(15)])
        self.assertEqual(recs[-1].left.direction, "down")
        recs = feed(AnalysisEngine(), [(0.5 - 0.03 * i, 0.03 * i) for i in range(15)])
        self.assertEqual(recs[-1].left.direction, "down-left")

    def test_missing_sample_breaks_series_no_zero_velocity(self):
        eng = AnalysisEngine()
        recs = feed(eng, [(0.3 + 0.03 * i, 0) for i in range(8)] + [None] + [(0.7, 0)] * 3)
        miss = recs[8].left
        self.assertIsNone(miss.velocity_uv); self.assertEqual(miss.direction, "unknown")
        self.assertIsNone(recs[9].left.velocity_uv)          # first valid after gap: no velocity either
        self.assertIsNotNone(recs[10].left.velocity_uv)

    def test_direction_hysteresis_no_flicker(self):
        m, labels = EyeMovement(0.35), []
        from visionx.models.tracking_models import EyeMeasurement
        for i in range(40):
            e = EyeMeasurement(valid=True, status="tracking", pupil_xy=(0, 0), pupil_rel=(0.3 + 0.03 * i, 0.003 * math.sin(i) * 3))
            m.update(i / 30, e); labels.append(e.direction)
        self.assertEqual(set(labels[10:]), {"right"})

    def test_saccade_detected_with_amplitude(self):
        eng = AnalysisEngine()
        pts = [(0.3, 0)] * 10 + [(0.3, 0), (0.38, 0), (0.46, 0), (0.54, 0)] + [(0.54, 0)] * 10
        recs = feed(eng, pts)
        sac = [e for r in recs for e in r.events if e["type"] == "saccade"]
        self.assertEqual(len(sac), 1)
        self.assertAlmostEqual(sac[0]["amplitude_uv"], 0.24, delta=0.03); self.assertEqual(sac[0]["direction"], "right")
        self.assertEqual(sac[0]["quality"], "webcam_approximate")

    def test_saccade_not_inferred_across_gap(self):
        eng = AnalysisEngine()
        recs = feed(eng, [(0.3, 0)] * 10 + [None] * 3 + [(0.7, 0)] * 10)
        self.assertEqual([e for r in recs for e in r.events if e["type"] == "saccade"], [])

    def test_fixation_interval(self):
        eng = AnalysisEngine()
        recs = feed(eng, [(0.5 + 0.002 * (i % 2), 0.1) for i in range(15)] + [(0.8, 0.1)] * 3)
        fx = [e for r in recs for e in r.events if e["type"] == "fixation"]
        self.assertEqual(len(fx), 1)
        self.assertGreaterEqual(fx[0]["duration_ms"], 150); self.assertAlmostEqual(fx[0]["position_uv"][0], 0.5, delta=0.01)
        self.assertTrue(fx[0]["valid"]); self.assertEqual(fx[0]["threshold_dispersion"], 0.05)

    def test_short_stable_period_is_not_fixation(self):
        d, ev = FixationDetector(0.05, 150), []
        for i, p in enumerate([(0.5, 0)] * 3 + [(0.9, 0)] * 2): ev += d.update(i / 30, 0, p)
        self.assertEqual(ev, [])

    def test_tracking_lost_and_recovered(self):
        eng = AnalysisEngine()
        recs = feed(eng, [(0.5, 0)] * 5 + [None] * 3 + [(0.5, 0)] * 2 + [None] * 12 + [(0.5, 0)] * 3)
        types = [e["type"] for r in recs for e in r.events]
        self.assertEqual(types.count("tracking_lost"), 1); self.assertEqual(types.count("tracking_recovered"), 1)
        self.assertEqual(len(eng.lost_intervals), 1)

    def test_pursuit_is_not_every_motion(self):
        d, ev = PursuitDetector(), []
        for i in range(30): ev += d.update(i / 30, 0, (0.2 + 0.006 * i, 0.1))    # 0.18 u/s smooth, 1 s
        for i in range(30): ev += d.update(1 + i / 30, 0, (0.5 + (0.02 if i % 2 else -0.02), 0.1))   # jitter
        ev += d.update(3, 0, None)
        self.assertEqual(len([e for e in ev if e["type"] == "smooth_pursuit_like"]), 1)

    def test_summary_valid_fraction(self):
        eng = AnalysisEngine(); feed(eng, [(0.5, 0)] * 6 + [None] * 4)
        self.assertAlmostEqual(eng.summary()["left"]["valid_fraction"], 0.6)


if __name__ == "__main__":
    unittest.main()
