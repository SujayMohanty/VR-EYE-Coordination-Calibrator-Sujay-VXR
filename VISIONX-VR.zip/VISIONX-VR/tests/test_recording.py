import csv, json, tempfile, time, unittest
from pathlib import Path
import numpy as np
import helpers  # noqa
from helpers import make_record
from visionx.models.tracking_models import CSV_COLUMNS, make_event
from visionx.recording.exporters import export_session, records_to_csv
from visionx.recording.playback import ReplaySession, ReplayError
from visionx.recording.recorder import SessionRecorder


def record_session(d, n=60, video=False, pause_at=None):
    rec = SessionRecorder(); frame = np.zeros((48, 64, 3), np.uint8)
    path = rec.start(d, "sessA", {"camera": "synthetic"}, save_video=video, frame_size=(64, 48), fps=30)
    for i in range(n):
        if pause_at == i: rec.pause()
        if pause_at is not None and i == pause_at + 5: rec.resume()
        uv = (0.4 + 0.002 * i, 0.0) if i % 10 != 9 else None
        r = make_record(100 + i / 30, uv, uv, frame_id=i, calib="cal_x" if i > 5 else None)
        if i == 20: r.events.append(make_event("blink", r.capture_ts, r.wall_time, eye="left"))
        if i in (30,): r.events.append(make_event("tracking_lost", r.capture_ts, r.wall_time))
        if i in (35,): r.events.append(make_event("tracking_recovered", r.capture_ts, r.wall_time))
        rec.write(r, frame)
    return rec, path, rec.stop()


class TestRecording(unittest.TestCase):
    def test_files_and_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            rec, path, man = record_session(d)
            self.assertEqual(man["status"], "complete"); self.assertEqual(man["counts"]["records"], 60)
            self.assertEqual(man["counts"]["events"], 3); self.assertEqual(man["dropped_records"], 0)
            self.assertFalse(man["privacy"]["raw_video_saved"]); self.assertEqual(man["schema_version"], "1.0")
            rows = list(csv.DictReader(open(path / "records.csv", encoding="utf-8", newline="")))
            self.assertEqual(len(rows), 60); self.assertEqual(list(rows[0]), CSV_COLUMNS)
            self.assertEqual(rows[9]["left_pupil_xy_x"], "")                  # missing stays missing
            self.assertEqual(len((path / "records.jsonl").read_text().splitlines()), 60)
            ts = [float(r["capture_ts"]) for r in rows]; self.assertEqual(ts, sorted(ts))

    def test_pause_drops_records_and_is_documented(self):
        with tempfile.TemporaryDirectory() as d:
            _, path, man = record_session(d, 60, pause_at=20)
            self.assertEqual(man["counts"]["records"], 55); self.assertEqual(len(man["paused_intervals"]), 1)

    def test_state_machine_and_no_session_reuse(self):
        with tempfile.TemporaryDirectory() as d:
            r = SessionRecorder(); p1 = r.start(d, "s", {}); r.stop()
            with self.assertRaises(RuntimeError):
                r.start(d, "s2", {}); r.start(d, "s3", {})
            r.stop(); p2 = SessionRecorder().start(d, "s", {})
            self.assertNotEqual(p1, p2)

    def test_idle_recorder_ignores_writes(self):
        r = SessionRecorder(); r.write(make_record(0, (0.5, 0), None)); self.assertEqual(r.n_records, 0)

    def test_queue_overflow_is_counted_not_silent(self):
        with tempfile.TemporaryDirectory() as d:
            r = SessionRecorder(queue_size=2); r.start(d, "s", {})
            r.thread_lock = None
            for i in range(2000): r.write(make_record(i, (0.5, 0), None))
            m = r.stop(); self.assertEqual(m["counts"]["records"] + m["dropped_records"], 2000)

    def test_replay_summary_seek_step(self):
        with tempfile.TemporaryDirectory() as d:
            _, path, _ = record_session(d)
            rs = ReplaySession(str(path)); s = rs.summary()
            self.assertEqual(s["records"], 60); self.assertEqual(s["valid_samples"], 54); self.assertAlmostEqual(s["valid_percent"], 90.0)
            self.assertEqual(s["blink_count"], 1); self.assertEqual(len(s["tracking_loss_intervals"]), 1)
            self.assertAlmostEqual(s["tracking_loss_intervals"][0]["duration_s"], 5 / 30, places=3)
            self.assertEqual(s["calibration"], ["cal_x"]); self.assertFalse(s["has_video"]); self.assertIsNone(rs.video_frame())
            self.assertEqual(rs.seek(10).frame_id, 10); self.assertEqual(rs.step(-3).frame_id, 7); self.assertEqual(rs.step(-100).frame_id, 0)
            self.assertEqual(rs.seek_time(1.0).frame_id, 30)
            rs.seek(0); rs.play(); passed = rs.advance(0.5)
            self.assertEqual(len(passed), 15); self.assertEqual(rs.index, 15)
            rs.pause(); self.assertEqual(rs.advance(1.0), [])
            self.assertEqual([e["type"] for e in rs.events_between(0.8, 1.3)], ["tracking_lost", "tracking_recovered"])

    def test_replay_with_video_syncs_frames(self):
        with tempfile.TemporaryDirectory() as d:
            _, path, man = record_session(d, 30, video=True)
            if not man["privacy"]["raw_video_saved"]: self.skipTest("mp4v writer unavailable in this OpenCV build")
            rs = ReplaySession(str(path)); self.assertTrue(rs.has_video); fr = rs.video_frame(5)
            self.assertEqual(fr.shape[:2], (48, 64)); rs.close()

    def test_replay_errors(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ReplayError): ReplaySession(d)
            (Path(d) / "records.jsonl").write_text("not json\n")
            with self.assertRaises(ReplayError): ReplaySession(d)

    def test_export_formats_consistent_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            _, path, _ = record_session(d)
            c = export_session(str(path), str(Path(d) / "out.csv"), "csv"); c2 = export_session(str(path), str(Path(d) / "out.csv"), "csv")
            self.assertNotEqual(c, c2)
            rows = list(csv.DictReader(open(c, encoding="utf-8"))); self.assertEqual(len(rows), 60)
            j = json.loads(Path(export_session(str(path), str(Path(d) / "o.json"), "json")).read_text())
            self.assertEqual(len(j["records"]), 60); self.assertEqual(j["schema_version"], "1.0")
            self.assertEqual(float(rows[3]["capture_ts"]), j["records"][3]["capture_ts"])
            sel = export_session(str(path), str(Path(d) / "sel.jsonl"), "jsonl", indices=[1, 2, 3])
            self.assertEqual(len(Path(sel).read_text().splitlines()), 3)
            with self.assertRaises(ValueError): export_session(str(path), str(Path(d) / "x"), "xml")


if __name__ == "__main__":
    unittest.main()
