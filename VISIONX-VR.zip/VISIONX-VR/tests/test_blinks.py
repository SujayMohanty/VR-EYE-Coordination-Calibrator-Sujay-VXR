import unittest
import helpers  # noqa
from visionx.analysis.blink_detector import BlinkDetector


def run(series, dt=1 / 30, **kw):
    d, ev, t = BlinkDetector("left", **kw), [], 0.0
    for v in series:
        ev += d.update(t, 1e9 + t, v); t += dt
    return ev


OPEN = [0.30] * 40


class TestBlink(unittest.TestCase):
    def test_single_blink(self):
        ev = run(OPEN + [0.10, 0.08, 0.12, 0.28] + OPEN)
        self.assertEqual([e["type"] for e in ev], ["blink"])
        self.assertAlmostEqual(ev[0]["duration_ms"], 4 * 33.3, delta=40)

    def test_single_frame_dip_debounced(self):
        self.assertEqual(run(OPEN + [0.10] + OPEN), [])

    def test_two_blinks_with_refractory(self):
        ev = run(OPEN + [0.1] * 3 + [0.3] * 10 + [0.1] * 3 + OPEN)
        self.assertEqual(len(ev), 2)

    def test_long_closure(self):
        ev = run(OPEN + [0.05] * 30 + OPEN)             # ~1 s
        self.assertEqual([e["type"] for e in ev], ["eye_closure"])

    def test_prolonged_closure_notification(self):
        ev = run(OPEN + [0.05] * 60 + OPEN, prolonged_ms=1500)
        self.assertIn("prolonged_closure", [e["type"] for e in ev])

    def test_tracking_loss_while_closed_is_not_a_blink(self):
        ev = run(OPEN + [0.1] * 3 + [None] * 30 + OPEN)
        self.assertEqual(ev, [])

    def test_missing_samples_are_not_treated_as_open_or_closed(self):
        self.assertEqual(run([None] * 50), [])

    def test_adaptive_baseline(self):
        ev = run([0.40] * 60 + [0.22] * 4 + [0.40] * 20)    # absolute 0.17 would miss this
        self.assertEqual(len(ev), 1)


if __name__ == "__main__":
    unittest.main()
