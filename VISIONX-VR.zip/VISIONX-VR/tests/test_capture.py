import json, tempfile, time, unittest, os
from pathlib import Path
import numpy as np
import helpers  # noqa
from synth import draw_face, SyntheticLandmarkTracker
from visionx.capture.capture_manager import *
from visionx.config import Settings
from visionx.render.overlay import OverlayOptions
from visionx.tracking.webcam_provider import WebcamTrackingEngine


def bundle(closed=False):
    s = Settings(); s.set("tracking.head_pose", False)
    tr = SyntheticLandmarkTracker(); tr.present = not closed
    return WebcamTrackingEngine(s, tr, "sess").process(draw_face(tr.pupil_off), time.monotonic(), 7)


def wait(cm, n):
    t0 = time.time()
    while len(cm.history) < n and time.time() - t0 < 5: time.sleep(0.01)
    return cm.history


class TestCapture(unittest.TestCase):
    def test_sample_and_images_written_before_reporting(self):
        with tempfile.TemporaryDirectory() as d:
            seen = []
            def cb(res):                                   # at callback time every file must already exist
                seen.append(all(Path(p).exists() for p in res.files.values()))
            cm = CaptureManager(d, "sess", cb); b = bundle(); o = OverlayOptions()
            arts = build_artifacts(b, ["raw_frame", "annotated_frame", "left_eye_crop", "right_eye_crop", "left_eye_overlay", "processed_left"], o)
            cm.submit("image", b, arts, {"camera": "synthetic"})
            res = wait(cm, 1)[0]
            self.assertEqual(res.status, "ok", res.message); self.assertEqual(seen, [True])
            self.assertEqual(set(res.files), {"raw_frame", "annotated_frame", "left_eye_crop", "right_eye_crop", "left_eye_overlay", "processed_left", "metadata"})
            raw = cv2_read(res.files["raw_frame"]); self.assertEqual(raw.shape, (480, 640, 3))
            self.assertTrue((raw == b.frame).all())                            # raw really is raw
            ann = cv2_read(res.files["annotated_frame"]); self.assertFalse((ann == b.frame).all())   # annotated differs
            doc = json.loads(Path(res.files["metadata"]).read_text())
            self.assertEqual(doc["record"]["frame_id"], 7); self.assertEqual(doc["session_id"], "sess")
            self.assertEqual(cm.counts["samples"], 1); self.assertEqual(cm.counts["eye_crops"], 3)
            self.assertEqual(cm.counts["annotated_frames"], 1); self.assertEqual(cm.counts["raw_frames"], 1)
            self.assertTrue((Path(d) / "captures" / "samples.csv").exists())
            cm.close()

    def test_invalid_eyes_saved_explicitly_not_fabricated(self):
        with tempfile.TemporaryDirectory() as d:
            cm = CaptureManager(d, "sess"); b = bundle(closed=True)
            cm.submit("sample", b, {}, {}); res = wait(cm, 1)[0]
            rec = json.loads(Path(res.files["metadata"]).read_text())["record"]
            self.assertFalse(rec["left"]["valid"]); self.assertIsNone(rec["left"]["pupil_xy"]); self.assertEqual(rec["state"], "no_face")
            cm.close()

    def test_partial_failure_reported(self):
        with tempfile.TemporaryDirectory() as d:
            cm = CaptureManager(d, "sess"); b = bundle(closed=True)
            arts = build_artifacts(b, ["raw_frame", "left_eye_crop", "processed_left"], OverlayOptions())
            cm.submit("image", b, arts, {}); res = wait(cm, 1)[0]
            self.assertIn(res.status, ("partial", "failed")); self.assertIn("left_eye_crop", res.failed)
            self.assertIn("Partial" if res.status == "partial" else "failed", res.message)
            self.assertEqual(cm.counts["eye_crops"], 0); cm.close()

    def test_write_failure_reports_failed_and_counts_nothing(self):
        with tempfile.TemporaryDirectory() as d:
            blocker = Path(d) / "blocker"; blocker.write_text("x")
            cm = CaptureManager(str(blocker), "sess"); b = bundle()
            cm.submit("image", b, build_artifacts(b, ["raw_frame"], OverlayOptions()), {})
            res = wait(cm, 1)[0]
            self.assertEqual(res.status, "failed"); self.assertTrue(res.failed); self.assertEqual(cm.counts["raw_frames"], 0)
            self.assertIsNotNone(cm.last_error); self.assertIsNone(cm.last_success); cm.close()

    def test_never_overwrites(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "a.png"
            p1 = atomic_write_new(p, b"one"); p2 = atomic_write_new(p, b"two")
            self.assertNotEqual(p1, p2); self.assertEqual(p1.read_bytes(), b"one"); self.assertEqual(p2.read_bytes(), b"two")
            self.assertEqual([x.name for x in Path(d).iterdir() if x.name.endswith(".tmp")], [])

    def test_file_limit(self):
        with tempfile.TemporaryDirectory() as d:
            cm = CaptureManager(d, "sess", max_files=2); b = bundle()
            cm.submit("image", b, build_artifacts(b, ["raw_frame", "left_eye_crop", "right_eye_crop"], OverlayOptions()), {}, write_sample=False)
            res = wait(cm, 1)[0]; self.assertEqual(len(res.files), 2); self.assertIn("limit", list(res.failed.values())[0]); cm.close()

    def test_auto_trigger_throttles_and_matches(self):
        t = AutoCaptureTrigger("blink", min_interval_s=2.0)
        r = helpers.make_record(0); r.events = [{"type": "blink"}]
        self.assertEqual(t.should_capture(r, 10.0), "blink")
        self.assertIsNone(t.should_capture(r, 10.5))            # duplicate suppression
        self.assertEqual(t.should_capture(r, 12.5), "blink")
        r.events = [{"type": "saccade"}]; self.assertIsNone(t.should_capture(r, 20.0))
        self.assertIsNone(AutoCaptureTrigger("off").should_capture(r, 1e6))
        p = AutoCaptureTrigger("periodic", 5.0, 1.0)
        self.assertEqual(p.should_capture(r, 100.0), "periodic"); self.assertIsNone(p.should_capture(r, 103.0)); self.assertEqual(p.should_capture(r, 105.5), "periodic")


def cv2_read(p):
    import cv2; return cv2.imread(p)


if __name__ == "__main__":
    unittest.main()
