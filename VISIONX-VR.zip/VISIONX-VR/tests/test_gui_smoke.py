"""Real Qt smoke test (offscreen). Skipped when PySide6 is not installed (it was NOT installed in the
authoring sandbox, so this file has never been executed there)."""
import importlib.util, os, tempfile, threading, time, unittest
import helpers  # noqa

HAVE_QT = importlib.util.find_spec("PySide6") is not None


@unittest.skipUnless(HAVE_QT, "PySide6 not installed")
class TestRealQt(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])
        from app import theme
        cls.app.setStyleSheet(theme.STYLE)

    def make(self):
        import app.session_controller as sc
        from synth import SyntheticLandmarkTracker, draw_face
        from visionx.camera.frame_source import FrameSource
        from visionx.config import Settings
        from app.window_manager import WindowManager

        class Fake(FrameSource):
            name = "synthetic cam"
            def open(self): return True
            def read(self): time.sleep(0.01); return True, draw_face({"left": (3, 1), "right": (3, 1)})
            def release(self): pass
        sc.MediaPipeLandmarkTracker = lambda **k: SyntheticLandmarkTracker()
        sc.CvCameraSource = lambda *a, **k: Fake()
        self.tmp = tempfile.TemporaryDirectory()
        s = Settings(); s.set("capture.directory", self.tmp.name); s.set("tracking.head_pose", False)
        c = sc.SessionController(s); return c, WindowManager(c)

    def spin(self, secs):
        t0 = time.time()
        while time.time() - t0 < secs:
            self.app.processEvents(); time.sleep(0.01)

    def test_two_windows_share_one_session_and_reopen(self):
        c, wm = self.make()
        wm.show_all(True); self.assertTrue(c.start_tracking()); self.spin(1.0)
        self.assertIsNotNone(wm.monitor); m = wm.monitor
        self.assertIsNot(wm.main, m)                                       # distinct top-level windows
        self.assertIs(wm.main.latest, wm.monitor.latest)
        m.close(); self.spin(0.2); self.assertFalse(m.isVisible()); self.assertTrue(c.pipeline.running)
        wm.show_monitor(); self.assertIs(wm.monitor, m); self.assertTrue(m.isVisible())
        self.assertEqual(sum(t.name == "camera-capture" for t in threading.enumerate()), 1)
        wm.main._tick(); m._tick()
        pix = wm.main.cam_view.grab(); self.assertFalse(pix.isNull())
        c.shutdown(); self.spin(0.2)
        self.assertEqual(sum(t.name in ("camera-capture", "tracking-pipeline") for t in threading.enumerate()), 0)

    def test_settings_dialog_roundtrip(self):
        from app.components.dialogs import SettingsDialog
        c, wm = self.make(); d = SettingsDialog(c)
        d.w["overlay.reticle_size"].setValue(2.0); self.assertTrue(d._apply())
        self.assertEqual(c.settings.get("overlay.reticle_size"), 2.0); c.shutdown()


if __name__ == "__main__":
    unittest.main()
