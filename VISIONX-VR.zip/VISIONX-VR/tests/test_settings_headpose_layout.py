import json, math, tempfile, unittest
from pathlib import Path
import numpy as np, cv2
import helpers  # noqa
from visionx.config import Settings, SCHEMA, PRESETS
from visionx.tracking.head_pose import estimate_head_pose, MODEL, IDX
from app.window_layout import Rect, default_layout, ensure_visible


class TestSettings(unittest.TestCase):
    def test_validation(self):
        s = Settings()
        for k, v in [("tracking.confidence_threshold", 5), ("camera.index", -1), ("overlay.color_primary", "blue"),
                     ("tracking.smoothing_method", "magic"), ("camera.mirror", "yes"), ("camera.fps", float("nan")), ("capture.artifacts", ["x"])]:
            with self.assertRaises(ValueError, msg=k): s.set(k, v)
        s.set("camera.fps", "60"); self.assertEqual(s.get("camera.fps"), 60)

    def test_persist_roundtrip_and_bad_values_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "s.json"; s = Settings(); s.set("overlay.reticle_size", 2.0); s.window_state["main"] = [1, 2, 3, 4]; s.save(p)
            doc = json.loads(p.read_text()); doc["values"]["camera.index"] = 999; p.write_text(json.dumps(doc))
            s2 = Settings.load(p); self.assertEqual(s2.get("overlay.reticle_size"), 2.0); self.assertEqual(s2.get("camera.index"), 0)
            self.assertTrue(s2.errors); self.assertEqual(s2.window_state["main"], [1, 2, 3, 4])

    def test_corrupt_file_does_not_crash(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "s.json"; p.write_text("{nope"); self.assertTrue(Settings.load(p).errors)

    def test_defaults_valid_and_presets(self):
        s = Settings()
        for f in SCHEMA: s.set(f.key, f.default)
        for name, vals in PRESETS.items():
            s.apply_preset(name); self.assertEqual(s.get("tracking.preset"), name)
        s.reset(); self.assertEqual(s.get("tracking.preset"), "balanced")

    def test_default_json_matches_code(self):
        p = Path(__file__).resolve().parents[1] / "config" / "default.json"
        if p.exists(): self.assertEqual(json.loads(p.read_text())["values"], Settings().values)


class TestHeadPose(unittest.TestCase):
    def synth(self, yaw, pitch, roll, tz=600):
        """SYNTHETIC: project the generic model with a known rotation, then recover it."""
        fw, fh = 640, 480; K = np.array([[fw, 0, fw / 2], [0, fw, fh / 2], [0, 0, 1.0]])
        # forward direction f = R@(0,0,-1); build R from desired yaw/pitch/roll
        cy, sy, cp, sp = math.cos(math.radians(yaw)), math.sin(math.radians(yaw)), math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
        f = np.array([sy * cp, -sp, -cy * cp]); ez = -f
        ex0 = np.cross([0, 1.0, 0], ez); ex0 /= np.linalg.norm(ex0); ey0 = np.cross(ez, ex0)
        r = math.radians(roll); ex = math.cos(r) * ex0 + math.sin(r) * ey0; ey = np.cross(ez, ex)
        R = np.stack([ex, ey, ez], 1)
        rvec, _ = cv2.Rodrigues(R)
        pts, _ = cv2.projectPoints(MODEL, rvec, np.array([[0], [0], [tz]], float), K, None)
        P = np.zeros((478, 2), np.float32); P[list(IDX)] = pts.reshape(-1, 2); return P, fw, fh

    def test_recovers_known_angles(self):
        for yaw, pitch, roll in [(0, 0, 0), (20, 0, 0), (-25, 10, 5), (10, -15, -10)]:
            P, fw, fh = self.synth(yaw, pitch, roll)
            h = estimate_head_pose(P, fw, fh)
            self.assertIsNotNone(h)
            for k, v in zip(("yaw", "pitch", "roll"), (yaw, pitch, roll)): self.assertAlmostEqual(h[k], v, delta=2.0, msg=(yaw, pitch, roll, h))

    def test_garbage_landmarks_return_none(self):
        P = np.random.default_rng(0).uniform(0, 640, (478, 2)).astype(np.float32)
        self.assertIsNone(estimate_head_pose(P, 640, 480)); self.assertIsNone(estimate_head_pose(P[:10], 640, 480))


class TestLayout(unittest.TestCase):
    def test_side_by_side_on_large_screen(self):
        l = default_layout([Rect(0, 0, 2560, 1440)])
        self.assertEqual(l["monitor"].x, l["main"].x + l["main"].w + 8); self.assertEqual(l["main"].intersects_area(l["monitor"]), 0)

    def test_small_screen_shrinks_without_overlap(self):
        s = Rect(0, 0, 1366, 768); l = default_layout([s])
        for r in l.values(): self.assertTrue(r.x >= 0 and r.x + r.w <= s.w and r.h <= s.h)
        self.assertEqual(l["main"].intersects_area(l["monitor"]), 0)

    def test_second_screen_used_when_first_too_small(self):
        l = default_layout([Rect(0, 0, 1366, 768), Rect(1366, 0, 1920, 1080)])
        self.assertGreaterEqual(l["monitor"].x, 1366)

    def test_saved_geometry_validation(self):
        screens = [Rect(0, 0, 1920, 1080)]
        self.assertIsNone(ensure_visible(Rect(5000, 100, 700, 800), screens))          # unplugged monitor
        self.assertIsNone(ensure_visible(Rect(0, 0, 50, 50), screens))
        r = ensure_visible(Rect(1800, 100, 700, 800), screens); self.assertIsNotNone(r); self.assertLess(r.x, 1900)
        self.assertEqual(ensure_visible(Rect(100, 100, 700, 800), screens), Rect(100, 100, 700, 800))


if __name__ == "__main__":
    unittest.main()
