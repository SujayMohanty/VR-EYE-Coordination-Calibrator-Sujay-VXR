import sys
from pathlib import Path
for p in (Path(__file__).parent, Path(__file__).parent / "tests"):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))
