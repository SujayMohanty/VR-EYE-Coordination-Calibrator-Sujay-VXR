// VISIONX VR — Unity example: native OpenXR eye gaze -> (a) gaze ray interaction, (b) UDP bridge to VISIONX.
// STATUS: UNVERIFIED. Written against Unity OpenXR Plugin + Input System docs; not compiled or run on a headset.
// Setup: Unity 2022.3+, packages: OpenXR Plugin, XR Interaction Toolkit (optional), Input System.
//   Project Settings > XR Plug-in Management > OpenXR > enable "Eye Gaze Interaction Profile".
//   Quest: also add the eye tracking permission (com.oculus.permission.EYE_TRACKING) and request it at runtime.
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;

public class GazeBridge : MonoBehaviour
{
    [Header("Rig (tracking space -> world)")] public Transform trackingSpace;       // XR Origin / camera offset
    [Header("Interaction")] public float maxDistance = 20f; public LayerMask mask = ~0;
    public float dwellSeconds = 0.8f; public float cooldownSeconds = 1.0f; public bool enableDwell = false;
    public InputActionReference confirmAction;                                       // controller fallback
    [Header("Bridge")] public bool sendToVisionx = true; public string host = "127.0.0.1"; public int port = 49152;

    public UnityEvent<GameObject> onGazeEnter, onGazeExit, onSelect;

    InputAction pos, rot, tracked;
    UdpClient udp; int seq; GameObject hover; float hoverSince, cooldownUntil;

    void OnEnable()
    {
        pos = new InputAction("pos", binding: "<EyeGaze>/pose/position");
        rot = new InputAction("rot", binding: "<EyeGaze>/pose/rotation");
        tracked = new InputAction("trk", binding: "<EyeGaze>/pose/isTracked");
        pos.Enable(); rot.Enable(); tracked.Enable();
        if (sendToVisionx) udp = new UdpClient();
        if (confirmAction != null) confirmAction.action.performed += OnConfirm;
    }

    void OnDisable()
    {
        pos.Disable(); rot.Disable(); tracked.Disable(); udp?.Close();
        if (confirmAction != null) confirmAction.action.performed -= OnConfirm;
    }

    void Update()
    {
        // Feature availability: if the device layout is absent the controls never become tracked -> valid=false.
        bool valid = tracked.ReadValue<float>() > 0.5f;
        Vector3 origin = default, dir = default;
        if (valid)
        {
            var p = pos.ReadValue<Vector3>(); var q = rot.ReadValue<Quaternion>();
            var t = trackingSpace != null ? trackingSpace : transform;
            origin = t.TransformPoint(p); dir = (t.rotation * q) * Vector3.forward;   // gaze ray in world space
        }
        Send(valid, origin, dir);
        UpdateInteraction(valid, origin, dir);
    }

    void UpdateInteraction(bool valid, Vector3 o, Vector3 d)
    {
        GameObject hit = null;
        if (valid && Physics.Raycast(o, d, out var h, maxDistance, mask)) hit = h.collider.gameObject;
        if (hit != hover)
        {
            if (hover != null) onGazeExit.Invoke(hover);   // also fires when tracking is lost (valid=false) -> cancels dwell
            hover = hit; hoverSince = Time.time;
            if (hover != null) onGazeEnter.Invoke(hover);
            return;
        }
        if (enableDwell && hover != null && Time.time - hoverSince >= dwellSeconds && Time.time >= cooldownUntil)
        {
            onSelect.Invoke(hover); cooldownUntil = Time.time + cooldownSeconds; hoverSince = Time.time + cooldownSeconds;
        }
    }

    void OnConfirm(InputAction.CallbackContext _)
    {   // alternative: controller press selects the hovered target even when dwell is off
        if (hover != null && Time.time >= cooldownUntil) { onSelect.Invoke(hover); cooldownUntil = Time.time + cooldownSeconds; }
    }

    void Send(bool valid, Vector3 o, Vector3 d)
    {
        if (udp == null) return;
        var sb = new StringBuilder();
        string F(float f) => f.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
        sb.Append("{\"v\":1,\"seq\":").Append(++seq).Append(",\"t\":").Append(F(Time.realtimeSinceStartup))
          .Append(",\"valid\":").Append(valid ? "true" : "false");
        if (valid) sb.Append(",\"origin\":[").Append(F(o.x)).Append(',').Append(F(o.y)).Append(',').Append(F(o.z))
                     .Append("],\"direction\":[").Append(F(d.x)).Append(',').Append(F(d.y)).Append(',').Append(F(d.z)).Append("],\"space\":\"world\"");
        sb.Append('}');
        var bytes = Encoding.UTF8.GetBytes(sb.ToString());
        try { udp.Send(bytes, bytes.Length, host, port); } catch (SocketException) { /* VISIONX not listening: ignore */ }
    }
}
