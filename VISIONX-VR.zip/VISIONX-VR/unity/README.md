# Unity / native VR gaze integration

VISIONX never infers headset gaze from the webcam. Native gaze arrives from a headset app over a local UDP bridge
and is stored as `provider = "native_vr"` (gaze ray in `gaze.origin`/`gaze.direction`, world space).

**Status: `GazeBridge.cs` is UNVERIFIED** — it was written from API documentation and never compiled or run on hardware.
**Verified device/runtime combinations: none.** Potentially compatible: any OpenXR runtime exposing `XR_EXT_eye_gaze_interaction`
(e.g. Quest Pro/3 over OpenXR, Pico 4 Enterprise, Varjo, HP Reverb G2 Omnicept — all untested here).

## Setup
1. Unity 2022.3 LTS or newer; install *OpenXR Plugin* and *Input System*.
2. XR Plug-in Management → OpenXR → enable **Eye Gaze Interaction Profile**.
3. Quest/Android: add the eye-tracking permission to the manifest and request it at runtime; desktop runtimes prompt themselves.
4. Add `GazeBridge` to an object, assign `trackingSpace` (XR Origin / camera offset), optionally a controller `confirmAction`.
5. In VISIONX: VR Integration ▸ Provider ▸ *Native VR via UDP bridge*, then **Start Tracking**. Port default `49152`.

## Behaviour
* `valid=false` whenever `<EyeGaze>/pose/isTracked` is false (feature missing, permission denied, tracking lost); invalid packets carry no coordinates.
* VISIONX marks data stale after `vr.stale_ms` (default 200 ms) and reports `stale` instead of reusing the last ray.
* Dwell selection is off by default; hover exit fires on tracking loss, cancelling dwell. A controller button is the fallback.

## Packet (v1, one JSON datagram)
`{"v":1,"seq":int,"t":float,"valid":bool,"origin":[x,y,z],"direction":[x,y,z],"confidence":0..1?,"space":"world"}`
