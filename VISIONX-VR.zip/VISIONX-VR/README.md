# VISIONX VR

Real-time webcam eye tracking for Windows 10/11 (Python): MediaPipe face/iris landmarks → image-based pupil localisation →
quality gating → smoothing → eye-relative measurements, optional calibrated screen gaze, blink/fixation/saccade-like events,
capture, recording, replay, and a UDP bridge for **native** headset gaze. Everything runs locally; nothing is uploaded.

Two top-level windows share one tracking pipeline: the **Main Dashboard** (live camera, blue pupil reticles, metrics, controls)
and the **Pupil Track & Capture Monitor** (magnified eyes, plots, capture inspector, events, recording, replay).

## Install & run (Windows 10/11)
```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python scripts/download_models.py        # face_landmarker.task -> assets/   (needs internet once)
python scripts/check_environment.py      # dependencies, model, cameras
python -m app.main                       # add --autostart, --no-monitor, or --source clip.mp4
```
Python 3.12 is required in practice (MediaPipe 0.10.x wheels); 3.13 is unsupported. Tests: `python -m unittest discover -s tests -v`
(or `pytest`). Windows camera access: Settings ▸ Privacy ▸ Camera must allow desktop apps.

## Using it
* **Tracking ▸ Start Tracking** (Camera ▸ Select Camera to choose the device). Pupil Monitor: `Ctrl+M`.
* **Blue reticle**: drawn only while a pupil estimate is accepted. *Low confidence* = hollow ring, *lost* = text only. Trails break on invalid samples.
* **Eye panels**: zoom, view mode (raw / landmarks / overlay / processed(derived) / side-by-side), toggles, Freeze view (tracking continues), capture crop.
* **Calibration**: 5/9/13 points, retry/skip/pause/cancel, validation at independent targets, profiles (save/load/delete).
* **Capture Sample / Capture Image** (artifacts chosen in Settings ▸ Capture); success is reported only after files are written. Auto-capture is off by default.
* **Recording**: explicit confirmation each time; numeric data only unless raw video is enabled. Replay: Pupil Monitor ▸ Replay.
* **Native VR**: see `unity/README.md`. **Settings** are validated and persisted in `%APPDATA%\VISIONX\settings.json`.

## Architecture
`visionx/` (Qt-free, unit-tested): `camera/` acquisition thread (latest-frame slot, reconnect) · `tracking/` landmarks, eye geometry, pupil detector,
quality, filters, head pose, gaze model · `analysis/` blink/movement/fixation/saccade · `calibration/` · `capture/` · `recording/` · `render/overlay.py`
(the single renderer for every blue graphic and annotated capture) · `vr/` · `pipeline.py` (worker thread).
`app/` (PySide6): `session_controller` (sole owner of camera/pipeline/recorder/capture), `window_manager`, `main_window`, `pupil_monitor_window`, components.
Consolidation versus the suggested tree: several small modules were merged (e.g. `components/widgets.py`, `dialogs.py`) instead of creating near-empty files.

## Honest limitations
* Pupil localisation is classical image processing on webcam pixels: dark irises, glasses glare, low resolution or poor light give LOW CONFIDENCE/LOST rather than guesses. `tracking.allow_iris_fallback` (off) substitutes the landmark iris centre and labels it `iris_fallback`.
* Pupil size is apparent pixels; there is no mm conversion and no 3D gaze angle from a 2D pupil. Screen gaze needs calibration and is valid only for that user/camera/seating.
* Saccade/fixation/pursuit detection at webcam rates is approximate. Quality scores are heuristics, not probabilities. Head pose uses a generic face model.
* OpenXR: only a capability probe; streaming native gaze needs a headset app (Unity example, unverified).
* No medical, emotional or intent inference is made or implied.
