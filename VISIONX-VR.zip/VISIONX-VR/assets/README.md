Place `face_landmarker.task` here (run `python scripts/download_models.py`).
The model is NOT bundled: it was not obtainable in the authoring sandbox (no network), so its SHA-256 is printed
by the download script on first download instead of being pinned here.
