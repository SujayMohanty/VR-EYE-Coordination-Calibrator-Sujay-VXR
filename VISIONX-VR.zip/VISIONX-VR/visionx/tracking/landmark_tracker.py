"""Face landmark stage (MediaPipe Face Landmarker, tasks API). Separate from pupil localisation."""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

DEFAULT_MODEL = Path(__file__).resolve().parents[2] / "assets" / "face_landmarker.task"


class ModelNotFoundError(RuntimeError):
    pass


@dataclass
class FaceLandmarks:
    points: np.ndarray  # (N, 2) float32 source-frame px, pixel-index convention


class LandmarkTracker(ABC):
    @abstractmethod
    def process(self, frame_bgr: np.ndarray, ts: float) -> Optional[FaceLandmarks]: ...

    def close(self) -> None:
        pass


class MediaPipeLandmarkTracker(LandmarkTracker):
    def __init__(self, model_path: Optional[str] = None, proc_width: int = 640, min_conf: float = 0.5):
        path = Path(model_path or os.environ.get("VISIONX_FACE_MODEL", DEFAULT_MODEL))
        if not path.is_file():
            raise ModelNotFoundError(
                f"Face Landmarker model not found at {path}. Run `python scripts/download_models.py` "
                "or place face_landmarker.task in the assets folder.")
        import mediapipe as mp
        from mediapipe.tasks import python as mp_python
        from mediapipe.tasks.python import vision
        self._mp = mp
        opts = vision.FaceLandmarkerOptions(
            base_options=mp_python.BaseOptions(model_asset_path=str(path)),
            running_mode=vision.RunningMode.VIDEO, num_faces=1,
            min_face_detection_confidence=min_conf, min_face_presence_confidence=min_conf,
            min_tracking_confidence=min_conf, output_face_blendshapes=False)
        self._lm = vision.FaceLandmarker.create_from_options(opts)
        self.proc_width = proc_width
        self._last_ms = -1

    def process(self, frame_bgr, ts):
        h, w = frame_bgr.shape[:2]
        pw = min(self.proc_width, w)
        small = frame_bgr if pw == w else cv2.resize(frame_bgr, (pw, int(round(h * pw / w))),
                                                     interpolation=cv2.INTER_AREA)
        rgb = np.ascontiguousarray(cv2.cvtColor(small, cv2.COLOR_BGR2RGB))
        ms = max(int(ts * 1000), self._last_ms + 1)      # timestamps must strictly increase
        self._last_ms = ms
        res = self._lm.detect_for_video(self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb), ms)
        if not res.face_landmarks:
            return None
        pts = np.array([[l.x * w - 0.5, l.y * h - 0.5] for l in res.face_landmarks[0]], np.float32)
        return FaceLandmarks(pts)

    def close(self):
        try:
            self._lm.close()
        except Exception:
            pass
