"""Image-based pupil localisation inside an eye crop (classical CV, CPU only).

Pipeline: ROI (iris circle ∩ eyelid polygon) -> specular-highlight inpainting -> blur ->
adaptive dark threshold between a low percentile and the ROI body -> morphology ->
contour scoring (circularity, size relative to the iris, centring) -> ellipse fit on the
convex hull. If there is no usable contrast or contour the result is `found=False`;
a centre is never invented. The quality value is a documented heuristic, not a probability.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

import cv2
import numpy as np


@dataclass
class PupilParams:
    target_width: int = 128
    threshold_fraction: float = 0.4
    min_contrast: float = 18.0
    min_area_ratio: float = 0.04
    max_area_ratio: float = 0.75
    min_circularity: float = 0.55
    highlight_level: int = 235


@dataclass
class PupilResult:
    found: bool = False
    center: Optional[Tuple[float, float]] = None   # crop px (pixel-index convention)
    width: Optional[float] = None                  # axis-aligned extent of fitted ellipse, crop px
    height: Optional[float] = None
    diameter: Optional[float] = None               # equivalent diameter sqrt(w_major*w_minor)
    quality: float = 0.0
    reason: Optional[str] = None
    debug: Optional[np.ndarray] = None             # DERIVED processing view (BGR, crop-sized)


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def detect_pupil(crop: np.ndarray, iris_xy: Optional[Tuple[float, float]] = None,
                 iris_r: Optional[float] = None,
                 eyelid_poly: Optional[Sequence[Tuple[float, float]]] = None,
                 params: Optional[PupilParams] = None, want_debug: bool = True) -> PupilResult:
    p = params or PupilParams()
    if crop is None or crop.size == 0:
        return PupilResult(reason="empty_crop")
    h, w = crop.shape[:2]
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop
    gw = max(16, int(p.target_width))
    gh = max(8, int(round(h * gw / w)))
    g = cv2.resize(gray, (gw, gh), interpolation=cv2.INTER_CUBIC if gw > w else cv2.INTER_AREA)
    sx, sy = gw / w, gh / h

    def to_s(pt):  # crop px -> detector px (pixel-index convention)
        return ((pt[0] + 0.5) * sx - 0.5, (pt[1] + 0.5) * sy - 0.5)

    roi = np.zeros((gh, gw), np.uint8)
    ic, ir = None, None
    if iris_xy is not None and iris_r and iris_r > 1:
        ic = to_s(iris_xy)
        ir = float(iris_r) * (sx + sy) / 2
        cv2.circle(roi, (int(round(ic[0])), int(round(ic[1]))), int(round(ir * 1.1)), 255, -1)
    else:
        cv2.ellipse(roi, (gw // 2, gh // 2), (int(gw * 0.3), int(gh * 0.4)), 0, 0, 360, 255, -1)
    if eyelid_poly is not None and len(eyelid_poly) >= 3:
        lid = np.zeros_like(roi)
        poly = np.array([to_s(q) for q in eyelid_poly], np.float32)
        cv2.fillPoly(lid, [np.round(poly).astype(np.int32)], 255)
        lid = cv2.erode(lid, np.ones((3, 3), np.uint8))
        roi = cv2.bitwise_and(roi, lid)
    roi_area = int(cv2.countNonZero(roi))
    if roi_area < 60:
        return PupilResult(reason="roi_too_small", debug=_dbg(crop, None, None, None, w, h, want_debug))

    work = g.copy()
    hl = ((g >= p.highlight_level) & (roi > 0)).astype(np.uint8) * 255
    if hl.any():
        hl = cv2.dilate(hl, np.ones((3, 3), np.uint8))
        work = cv2.inpaint(work, hl, 3, cv2.INPAINT_TELEA)
    blur = cv2.GaussianBlur(work, (0, 0), 1.2)
    vals = blur[roi > 0].astype(np.float32)
    base, ref = float(np.percentile(vals, 4)), float(np.percentile(vals, 55))
    contrast = ref - base
    if contrast < p.min_contrast:
        return PupilResult(reason="low_contrast", debug=_dbg(crop, roi, None, None, w, h, want_debug))
    thr = base + p.threshold_fraction * contrast
    mask = ((blur <= thr) & (roi > 0)).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    ref_area = math.pi * (ir * 1.1) ** 2 if ir else roi_area * 0.5
    best = None
    for c in cnts:
        area = cv2.contourArea(c)
        ratio = area / ref_area
        if ratio < p.min_area_ratio or ratio > p.max_area_ratio or len(c) < 5:
            continue
        hull = cv2.convexHull(c)
        ha, hp = cv2.contourArea(hull), cv2.arcLength(hull, True)
        if hp <= 0:
            continue
        circ = 4 * math.pi * ha / (hp * hp)
        if circ < p.min_circularity:
            continue
        m = cv2.moments(hull)
        if m["m00"] <= 0:
            continue
        cen = (m["m10"] / m["m00"], m["m01"] / m["m00"])
        dist = math.hypot(cen[0] - ic[0], cen[1] - ic[1]) / (ir * 1.1) if ic else 0.0
        score = circ * (ratio ** 0.3) * (1.0 - 0.7 * _clamp(dist))
        if best is None or score > best[0]:
            best = (score, hull, circ, ratio, dist, cen)
    if best is None:
        return PupilResult(reason="no_pupil_contour", debug=_dbg(crop, roi, mask, None, w, h, want_debug))
    _, hull, circ, ratio, dist, cen = best
    (ex, ey), (d1, d2), ang = cv2.fitEllipse(hull)
    major, minor = max(d1, d2), min(d1, d2)
    if minor > 0 and major / minor < 2.5 and math.hypot(ex - cen[0], ey - cen[1]) < 0.25 * major:
        cx, cy = ex, ey
    else:
        cx, cy = cen
    phi = math.radians(ang)
    ew = math.sqrt((d1 * math.cos(phi)) ** 2 + (d2 * math.sin(phi)) ** 2)
    eh = math.sqrt((d1 * math.sin(phi)) ** 2 + (d2 * math.cos(phi)) ** 2)
    size_s = 1.0 if 0.08 <= ratio <= 0.55 else 0.6
    q = (0.30 * _clamp((circ - 0.5) / 0.45) + 0.30 * _clamp(contrast / 60.0)
         + 0.25 * _clamp(1.0 - dist / 0.6) + 0.15 * size_s)
    center = ((cx + 0.5) / sx - 0.5, (cy + 0.5) / sy - 0.5)
    res = PupilResult(True, center, ew / sx, eh / sy, math.sqrt(major * minor) / ((sx + sy) / 2),
                      float(_clamp(q)), None)
    res.debug = _dbg(crop, roi, mask, (cx, cy, hull), w, h, want_debug)
    return res


def _dbg(crop, roi, mask, det, w, h, want):
    """Derived view for the monitor: dimmed crop + ROI outline + dark mask + detected ellipse."""
    if not want:
        return None
    gh = max(8, int(round(h * 128 / w)))
    img = cv2.cvtColor(cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop,
                                  (128, gh)), cv2.COLOR_GRAY2BGR)
    img = (img * 0.55).astype(np.uint8)
    gw = 128
    if roi is not None:
        r = cv2.resize(roi, (gw, gh), interpolation=cv2.INTER_NEAREST) if roi.shape[:2] != (gh, gw) else roi
        cs, _ = cv2.findContours(r, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(img, cs, -1, (140, 110, 60), 1)
    if mask is not None:
        m = cv2.resize(mask, (gw, gh), interpolation=cv2.INTER_NEAREST) if mask.shape[:2] != (gh, gw) else mask
        img[m > 0] = (0.5 * img[m > 0] + 0.5 * np.array([255, 160, 0])).astype(np.uint8)
    if det is not None:
        cx, cy, hull = det
        cv2.polylines(img, [np.round(hull.reshape(-1, 2)).astype(np.int32)], True, (255, 231, 64), 1)
        cv2.drawMarker(img, (int(round(cx)), int(round(cy))), (255, 255, 255), cv2.MARKER_CROSS, 7, 1)
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_NEAREST) if (w, h) != (gw, gh) else img
