"""Eye geometry from the 478-point MediaPipe face mesh.
'left' is the SUBJECT's left eye (landmarks 263/362, iris 473-477), which appears on the
image-right when the frame is not mirrored.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

SIDES = {
    "left": dict(outer=263, inner=362, iris=473, ring=(474, 475, 476, 477),
                 contour=[263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249],
                 ear=(362, 385, 387, 263, 373, 380)),
    "right": dict(outer=33, inner=133, iris=468, ring=(469, 470, 471, 472),
                  contour=[33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7],
                  ear=(33, 160, 158, 133, 153, 144)),
}
FACE_OVAL_HINT = (10, 152, 234, 454)  # top, chin, left/right cheek for the face box


@dataclass
class EyeGeometry:
    side: str
    corner_a: Tuple[float, float]       # image-left corner
    corner_b: Tuple[float, float]       # image-right corner
    box: Tuple[int, int, int, int]
    contour: np.ndarray                 # (n, 2) frame px
    iris_center: Optional[Tuple[float, float]]
    iris_radius: Optional[float]
    openness: float                     # eye aspect ratio
    width_px: float


def eye_aspect_ratio(P: np.ndarray, idx) -> float:
    p1, p2, p3, p4, p5, p6 = (P[i] for i in idx)
    horiz = np.linalg.norm(p1 - p4)
    return float((np.linalg.norm(p2 - p6) + np.linalg.norm(p3 - p5)) / (2 * horiz + 1e-9))


def build_eye_geometry(P: np.ndarray, side: str, fw: int, fh: int, pad: float = 0.35) -> EyeGeometry:
    d = SIDES[side]
    o, i = P[d["outer"]], P[d["inner"]]
    a, b = (o, i) if o[0] <= i[0] else (i, o)
    width = float(np.linalg.norm(b - a))
    c = (a + b) / 2
    hw = width * (0.5 + pad)
    hh = hw * 0.62
    x0, y0 = int(max(0, math.floor(c[0] - hw))), int(max(0, math.floor(c[1] - hh)))
    x1, y1 = int(min(fw, math.ceil(c[0] + hw) + 1)), int(min(fh, math.ceil(c[1] + hh) + 1))
    x1, y1 = max(x1, x0 + 1), max(y1, y0 + 1)
    iris_c = iris_r = None
    if P.shape[0] > d["iris"] + 4:
        ic = P[d["iris"]]
        ring = P[list(d["ring"])]
        iris_c = (float(ic[0]), float(ic[1]))
        iris_r = float(np.mean(np.linalg.norm(ring - ic, axis=1)))
    return EyeGeometry(side, (float(a[0]), float(a[1])), (float(b[0]), float(b[1])), (x0, y0, x1, y1),
                       P[d["contour"]].astype(np.float32), iris_c, iris_r,
                       eye_aspect_ratio(P, d["ear"]), width)
