"""Point filters. Raw observation, filtered estimate and validity are kept separate by callers."""
from __future__ import annotations

from collections import deque
from typing import Optional, Tuple

import numpy as np

Pt = Tuple[float, float]


class PointFilter:
    def __init__(self, strength: float = 0.4, gap_s: float = 0.25):
        self.strength = float(min(1.0, max(0.0, strength)))
        self.gap_s = gap_s
        self.last_ts: Optional[float] = None
        self.reset()

    def reset(self):
        self.last_ts = None

    def update(self, ts: float, pt: Pt) -> Pt:
        if self.last_ts is not None and ts - self.last_ts > self.gap_s:
            self._clear()
        self.last_ts = ts
        return self._step(ts, pt)

    def _clear(self):
        pass

    def _step(self, ts, pt):
        return pt


class NoFilter(PointFilter):
    pass


class EMAFilter(PointFilter):
    def reset(self):
        super().reset()
        self.s: Optional[np.ndarray] = None

    def _clear(self):
        self.s = None

    def _step(self, ts, pt):
        alpha = 1.0 - 0.9 * self.strength   # strength 0 -> alpha 1 (raw), 1 -> alpha 0.1
        x = np.asarray(pt, float)
        self.s = x if self.s is None else alpha * x + (1 - alpha) * self.s
        return (float(self.s[0]), float(self.s[1]))


class WindowFilter(PointFilter):
    def __init__(self, strength=0.4, gap_s=0.25, median=False):
        self.median = median
        super().__init__(strength, gap_s)

    def reset(self):
        super().reset()
        self.buf: deque = deque(maxlen=1 + int(round(self.strength * 8)))

    def _clear(self):
        self.buf.clear()

    def _step(self, ts, pt):
        self.buf.append(pt)
        a = np.asarray(self.buf, float)
        r = np.median(a, 0) if self.median else a.mean(0)
        return (float(r[0]), float(r[1]))


class KalmanFilter(PointFilter):
    """Constant-velocity Kalman filter; higher strength = lower process noise (smoother)."""

    def reset(self):
        super().reset()
        self.x: Optional[np.ndarray] = None
        self.P = np.eye(4) * 100.0
        self.t: Optional[float] = None

    def _clear(self):
        self.x, self.t = None, None
        self.P = np.eye(4) * 100.0

    def _step(self, ts, pt):
        z = np.asarray(pt, float)
        if self.x is None:
            self.x = np.array([z[0], z[1], 0, 0], float)
            self.t = ts
            return pt
        dt = max(1e-3, ts - self.t)
        self.t = ts
        F = np.eye(4)
        F[0, 2] = F[1, 3] = dt
        q = (1.0 - 0.95 * self.strength) * 400.0
        Q = q * np.array([[dt ** 3 / 3, 0, dt ** 2 / 2, 0], [0, dt ** 3 / 3, 0, dt ** 2 / 2],
                          [dt ** 2 / 2, 0, dt, 0], [0, dt ** 2 / 2, 0, dt]])
        H = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], float)
        R = np.eye(2) * 1.0
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + Q
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ (z - H @ self.x)
        self.P = (np.eye(4) - K @ H) @ self.P
        return (float(self.x[0]), float(self.x[1]))


def make_filter(method: str, strength: float) -> PointFilter:
    return {"none": lambda: NoFilter(strength), "ema": lambda: EMAFilter(strength),
            "moving_average": lambda: WindowFilter(strength), "median": lambda: WindowFilter(strength, median=True),
            "kalman": lambda: KalmanFilter(strength)}[method]()
