"""Calibrated webcam gaze: features (eye-relative pupil position [+ head pose]) -> normalized
screen coordinates via a ridge-regularised polynomial. Degree (1 or 2) is chosen by
leave-one-TARGET-out cross-validation, i.e. the simplest model that validates best."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from visionx.models.tracking_models import TrackingRecord

MODEL_VERSION = "1.0"


def eye_features(rec: TrackingRecord, use_head_pose: bool = False) -> Optional[np.ndarray]:
    """Mean eye-relative pupil (u, v) over ACCEPTED eyes (+ yaw/pitch). None if no valid eye."""
    uv = [e.pupil_rel for e in (rec.left, rec.right) if e.valid and e.pupil_rel is not None]
    if not uv:
        return None
    f = list(np.mean(uv, axis=0))
    if use_head_pose:
        if not rec.head_pose:
            return None
        f += [rec.head_pose["yaw"], rec.head_pose["pitch"]]
    return np.asarray(f, float)


def _design(Z: np.ndarray, degree: int) -> np.ndarray:
    cols = [np.ones(len(Z))] + [Z[:, i] for i in range(Z.shape[1])]
    if degree >= 2:
        for i in range(Z.shape[1]):
            for j in range(i, Z.shape[1]):
                cols.append(Z[:, i] * Z[:, j])
    return np.stack(cols, 1)


def _solve(A: np.ndarray, Y: np.ndarray, ridge: float) -> np.ndarray:
    pen = np.eye(A.shape[1]) * ridge
    pen[0, 0] = 0.0
    return np.linalg.solve(A.T @ A + pen, A.T @ Y)


@dataclass
class GazeModel:
    degree: int
    coef: np.ndarray
    mean: np.ndarray
    std: np.ndarray
    use_head_pose: bool = False
    screen_size: Tuple[int, int] = (1920, 1080)
    calibration_id: str = ""
    meta: Dict = field(default_factory=dict)

    def predict(self, feat: np.ndarray) -> Tuple[float, float]:
        z = ((np.asarray(feat, float) - self.mean) / self.std)[None, :]
        y = _design(z, self.degree) @ self.coef
        return float(y[0, 0]), float(y[0, 1])

    def to_dict(self) -> Dict:
        return {"model_version": MODEL_VERSION, "degree": self.degree, "coef": self.coef.tolist(),
                "mean": self.mean.tolist(), "std": self.std.tolist(), "use_head_pose": self.use_head_pose,
                "screen_size": list(self.screen_size), "calibration_id": self.calibration_id, "meta": self.meta}

    @classmethod
    def from_dict(cls, d: Dict) -> "GazeModel":
        if str(d.get("model_version", "")).split(".")[0] != MODEL_VERSION.split(".")[0]:
            raise ValueError(f"unsupported gaze model version {d.get('model_version')}")
        return cls(int(d["degree"]), np.array(d["coef"]), np.array(d["mean"]), np.array(d["std"]),
                   bool(d.get("use_head_pose", False)), tuple(d.get("screen_size", (1920, 1080))),
                   d.get("calibration_id", ""), d.get("meta", {}))


def fit_gaze_model(X: np.ndarray, Y: np.ndarray, groups: Sequence[int], screen_size=(1920, 1080),
                   ridge: float = 1e-3, calibration_id: str = "", use_head_pose: bool = False
                   ) -> Tuple[GazeModel, Dict]:
    """X: (n, d) features, Y: (n, 2) normalized targets, groups: target id per sample.
    Returns the model and validation metrics (leave-one-target-out)."""
    X, Y, g = np.asarray(X, float), np.asarray(Y, float), np.asarray(groups)
    targets = sorted(set(g.tolist()))
    if len(targets) < 3 or len(X) < 6:
        raise ValueError("need at least 3 calibration targets with samples")
    mean, std = X.mean(0), X.std(0)
    std[std < 1e-9] = 1.0
    Z = (X - mean) / std
    results = {}
    for deg in (1, 2):
        nterms = _design(Z[:1], deg).shape[1]
        if len(targets) - 1 < nterms:        # too few targets to validate this degree
            continue
        errs = {}
        for t in targets:
            tr, te = g != t, g == t
            w = _solve(_design(Z[tr], deg), Y[tr], ridge)
            pred = _design(Z[te], deg) @ w
            errs[t] = float(np.mean(np.linalg.norm(pred - Y[te], axis=1)))
        results[deg] = errs
    if not results:
        raise ValueError("too few targets to validate any model degree")
    deg = min(results, key=lambda d: np.mean(list(results[d].values())) + (0.002 if d == 2 else 0.0))
    coef = _solve(_design(Z, deg), Y, ridge)
    model = GazeModel(deg, coef, mean, std, use_head_pose, tuple(screen_size), calibration_id)
    train = np.linalg.norm(_design(Z, deg) @ coef - Y, axis=1)
    sw, sh = screen_size
    cv = np.array(list(results[deg].values()))
    metrics = {"degree": deg, "n_samples": int(len(X)), "n_targets": len(targets),
               "train_rmse_norm": float(np.sqrt(np.mean(train ** 2))),
               "cv_mean_error_norm": float(cv.mean()), "cv_max_error_norm": float(cv.max()),
               "cv_mean_error_px": float(cv.mean() * math.hypot(sw, sh) / math.sqrt(2)),
               "cv_per_target_norm": {int(k): v for k, v in results[deg].items()},
               "degrees_evaluated": {int(k): float(np.mean(list(v.values()))) for k, v in results.items()},
               "method": "leave-one-target-out cross-validation (pessimistic at screen corners)"}
    model.meta = metrics
    return model, metrics
