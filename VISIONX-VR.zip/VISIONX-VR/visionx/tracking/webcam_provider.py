"""Webcam tracking engine: frame -> landmarks -> eye geometry -> pupil -> quality -> filter -> record.
This is the ONLY place pupil positions are estimated; both windows consume its records."""
from __future__ import annotations

import time
from typing import Dict, Optional

import numpy as np

from visionx.models.tracking_models import GazeMeasurement, TrackingRecord, overall_state
from visionx.tracking.base_provider import FrameBundle, TrackingProvider
from visionx.tracking.eye_region import build_eye_geometry
from visionx.tracking.gaze_estimator import GazeModel, eye_features
from visionx.tracking.head_pose import estimate_head_pose
from visionx.tracking.landmark_tracker import LandmarkTracker
from visionx.tracking.pupil_detector import PupilParams, detect_pupil
from visionx.tracking.quality import EyeQuality
from visionx.tracking.smoothing import make_filter
from visionx.utils.coordinate_transforms import crop_to_frame, frame_to_crop, rel_from_corners


class _EyeState:
    def __init__(self, method, strength):
        self.filter = make_filter(method, strength)
        self.quality = EyeQuality()

    def lose(self):
        self.filter.reset()
        self.quality.lose()


class WebcamTrackingEngine(TrackingProvider):
    name = "Webcam (MediaPipe landmarks + image-based pupil detector)"
    provider_type = "webcam"

    def __init__(self, settings, tracker: LandmarkTracker, session_id: str = "", provider_type: str = "webcam"):
        self.s = settings
        self.tracker = tracker
        self.session_id = session_id
        self.provider_type = provider_type
        self.gaze_model: Optional[GazeModel] = None
        self.configure()

    def configure(self):
        s = self.s
        self.params = PupilParams(s.get("pupil.detector_width"), s.get("pupil.threshold_fraction"),
                                  s.get("pupil.min_contrast"), s.get("pupil.min_area_ratio"),
                                  s.get("pupil.max_area_ratio"), s.get("pupil.min_circularity"))
        self.thr = s.get("tracking.confidence_threshold")
        self.eyes: Dict[str, _EyeState] = {k: _EyeState(s.get("tracking.smoothing_method"),
                                                       s.get("tracking.smoothing_strength"))
                                           for k in ("left", "right")}
        self.gaze_filter = make_filter("ema", 0.5)
        if hasattr(self.tracker, "proc_width"):
            self.tracker.proc_width = s.get("tracking.proc_width")

    def set_gaze_model(self, model: Optional[GazeModel]):
        self.gaze_model = model

    def process(self, frame: np.ndarray, capture_ts: float, frame_id: int) -> FrameBundle:
        h, w = frame.shape[:2]
        rec = TrackingRecord(session_id=self.session_id, frame_id=frame_id, capture_ts=capture_ts,
                             wall_time=time.time() - (time.monotonic() - capture_ts), frame_size=(w, h),
                             provider=self.provider_type,
                             calibration_id=self.gaze_model.calibration_id if self.gaze_model else None)
        bundle = FrameBundle(rec, frame)
        lm = self.tracker.process(frame, capture_ts)
        if lm is None:
            for side in ("left", "right"):
                self.eyes[side].lose()
                rec.eye(side).reason = "no_face"
        else:
            P = lm.points
            rec.face_detected = True
            bundle.landmarks = P
            x0, y0 = P.min(0)
            x1, y1 = P.max(0)
            rec.face_box = (float(x0), float(y0), float(x1), float(y1))
            for side in ("left", "right"):
                self._process_eye(side, frame, P, rec, bundle, capture_ts)
            if self.s.get("tracking.head_pose"):
                rec.head_pose = estimate_head_pose(P, w, h)
        rec.state = overall_state(rec)
        self._gaze(rec)
        rec.processing_ts = time.monotonic()
        rec.latency_ms = (rec.processing_ts - capture_ts) * 1000.0
        return bundle

    def _process_eye(self, side, frame, P, rec, bundle, ts):
        st, e = self.eyes[side], rec.eye(side)
        h, w = frame.shape[:2]
        geom = build_eye_geometry(P, side, w, h, self.s.get("tracking.eye_crop_pad"))
        e.corner_a, e.corner_b, e.eye_box = geom.corner_a, geom.corner_b, geom.box
        e.openness, e.iris_xy, e.iris_radius_px = geom.openness, geom.iris_center, geom.iris_radius
        if geom.iris_center:
            e.iris_rel = rel_from_corners(geom.iris_center, geom.corner_a, geom.corner_b)
        x0, y0, x1, y1 = geom.box
        crop = frame[y0:y1, x0:x1]
        det = None
        if crop.shape[1] >= 24 and geom.openness >= 0.14:
            ic = frame_to_crop(geom.iris_center, geom.box) if geom.iris_center else None
            poly = [frame_to_crop(tuple(p), geom.box) for p in geom.contour]
            det = detect_pupil(crop, ic, geom.iris_radius, poly, self.params)
            if det.debug is not None:
                bundle.processed[side] = (det.debug, geom.box)
        cand = cand_uv = None
        if det is not None and det.found:
            cand = crop_to_frame(det.center, geom.box)
            cand_uv = rel_from_corners(cand, geom.corner_a, geom.corner_b)
            e.candidate_xy = cand
        score, why, stab = st.quality.assess(geom, det, cand_uv, crop.shape[1])
        e.quality, e.detector_quality = float(min(1.0, max(0.0, score))), (det.quality if det else None)
        accepted, prov = None, None
        if cand is not None and score >= self.thr:
            accepted, prov = cand, "pupil_detector"
        elif (self.s.get("tracking.allow_iris_fallback") and geom.iris_center and geom.openness >= 0.14
              and crop.shape[1] >= 24):
            accepted, prov = geom.iris_center, "iris_fallback"
            e.quality = float(min(0.6, stab * 0.6))
            e.reason = "pupil_not_found_using_iris" if cand is None else "low_quality_using_iris"
        if accepted is not None:
            fx = st.filter.update(ts, accepted)
            uv = rel_from_corners(fx, geom.corner_a, geom.corner_b)
            st.quality.accepted(uv)
            e.valid, e.status, e.provenance = True, "tracking", prov
            e.pupil_xy, e.pupil_rel, e.last_valid_ts = fx, uv, ts
            if prov == "pupil_detector":
                e.reason = None
                e.pupil_width_px, e.pupil_height_px, e.pupil_diameter_px = det.width, det.height, det.diameter
        else:
            st.lose()
            e.valid = False
            e.reason = why or ("low_quality" if cand is not None else "pupil_not_found")
            e.status = "low_confidence" if cand is not None else "lost"

    def _gaze(self, rec: TrackingRecord):
        g, m = rec.gaze, self.gaze_model
        if m is None:
            g.status, g.valid = "not_calibrated", False
            return
        g.calibration_id = m.calibration_id
        feat = eye_features(rec, m.use_head_pose)
        if feat is None or len(feat) != len(m.mean):
            g.valid, g.status, g.reason = False, "invalid", "no_valid_eye"
            self.gaze_filter.reset()
            return
        x, y = m.predict(feat)
        x, y = self.gaze_filter.update(rec.capture_ts, (x, y))
        g.valid, g.status, g.reason = True, "ok", None
        g.norm_xy, g.screen_xy = (x, y), (x * m.screen_size[0], y * m.screen_size[1])
        g.quality = min(e.quality for e in (rec.left, rec.right) if e.valid)
        g.last_valid_ts = rec.capture_ts

    def close(self):
        self.tracker.close()
