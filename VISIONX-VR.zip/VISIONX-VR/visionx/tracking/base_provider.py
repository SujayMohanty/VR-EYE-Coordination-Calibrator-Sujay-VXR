from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

import numpy as np

from visionx.models.tracking_models import TrackingRecord


@dataclass
class FrameBundle:
    """What the UI receives: the record (single source of truth) plus the pixels it refers to."""
    record: TrackingRecord
    frame: Optional[np.ndarray] = None                 # BGR source frame, never mirrored; do not mutate
    landmarks: Optional[np.ndarray] = None             # (N, 2) frame px, or None
    processed: Dict[str, Tuple[np.ndarray, Tuple[int, int, int, int]]] = field(default_factory=dict)
    mode: str = "live"                                 # live | replay


class TrackingProvider(ABC):
    name = "provider"
    provider_type = "webcam"

    @abstractmethod
    def process(self, frame: np.ndarray, capture_ts: float, frame_id: int) -> FrameBundle: ...

    def close(self) -> None:
        pass
