"""Approximate head pose via solvePnP on a generic 3D face model (y down, z away from camera).
Accuracy depends on the unknown real face shape and camera intrinsics (focal ~= frame width);
treat as approximate. yaw>0: face turned toward image-right; pitch>0: up; roll>0: clockwise."""
from __future__ import annotations

import math
from typing import Dict, Optional

import cv2
import numpy as np

IDX = (1, 152, 33, 263, 61, 291)  # nose tip, chin, image-left eye corner, image-right eye corner, mouth L/R
MODEL = np.array([[0, 0, 0], [0, 63.6, 12.5], [-43.3, -32.7, 26.0], [43.3, -32.7, 26.0],
                  [-28.9, 28.9, 24.1], [28.9, 28.9, 24.1]], np.float64)


def estimate_head_pose(P: np.ndarray, fw: int, fh: int, max_reproj_px: float = 6.0) -> Optional[Dict[str, float]]:
    if P.shape[0] <= max(IDX):
        return None
    img = P[list(IDX)].astype(np.float64)
    K = np.array([[fw, 0, fw / 2], [0, fw, fh / 2], [0, 0, 1]], np.float64)
    ok, rvec, tvec = cv2.solvePnP(MODEL, img, K, None, flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok or tvec[2, 0] <= 0:
        return None
    proj, _ = cv2.projectPoints(MODEL, rvec, tvec, K, None)
    err = float(np.mean(np.linalg.norm(proj.reshape(-1, 2) - img, axis=1)))
    if err > max_reproj_px * max(1.0, fw / 640):
        return None
    R, _ = cv2.Rodrigues(rvec)
    f = R @ np.array([0, 0, -1.0])      # direction the face points (towards the camera when frontal)
    ex = R @ np.array([1.0, 0, 0])
    return {"yaw": math.degrees(math.atan2(f[0], -f[2])),
            "pitch": math.degrees(math.atan2(-f[1], math.hypot(f[0], f[2]))),
            "roll": math.degrees(math.atan2(ex[1], ex[0])),
            "reproj_px": err, "tz": float(tvec[2, 0])}
