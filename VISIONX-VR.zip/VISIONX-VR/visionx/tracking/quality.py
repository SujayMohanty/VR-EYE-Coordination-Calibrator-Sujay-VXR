"""Per-eye quality assessment. The score is a documented HEURISTIC in 0..1:
    score = detector_quality * f_openness * f_stability * f_jump * f_size
It is not a calibrated or statistically validated probability."""
from __future__ import annotations

import math
from typing import Optional, Tuple

from visionx.tracking.eye_region import EyeGeometry
from visionx.tracking.pupil_detector import PupilResult

CLOSED_EAR = 0.14
MIN_CROP_W = 24


class EyeQuality:
    def __init__(self):
        self.reset()

    def reset(self):
        self.prev_iris: Optional[Tuple[float, float]] = None
        self.prev_uv: Optional[Tuple[float, float]] = None
        self.jump_count = 0

    def lose(self):
        """Call when no accepted estimate exists: forget the position history."""
        self.prev_uv = None
        self.jump_count = 0

    def stability(self, geom: EyeGeometry) -> float:
        f = 1.0
        if geom.iris_center is not None and self.prev_iris is not None and geom.width_px > 0:
            jit = math.hypot(geom.iris_center[0] - self.prev_iris[0],
                             geom.iris_center[1] - self.prev_iris[1]) / geom.width_px
            f = 1.0 - 0.5 * min(1.0, max(0.0, (jit - 0.05) / 0.15))
        self.prev_iris = geom.iris_center
        return f

    def assess(self, geom: EyeGeometry, det: Optional[PupilResult], cand_uv, crop_w: int
               ) -> Tuple[float, Optional[str], float]:
        """Returns (score, reason, stability). reason explains a zero/penalised score."""
        stab = self.stability(geom)
        if crop_w < MIN_CROP_W:
            return 0.0, "eye_crop_too_small", stab
        if geom.openness < CLOSED_EAR:
            return 0.0, "eye_closed", stab
        if det is None or not det.found:
            return 0.0, (det.reason if det else None) or "pupil_not_found", stab
        f_open = min(1.0, 0.4 + 0.6 * (geom.openness - CLOSED_EAR) / 0.10)
        f_size = 1.0 if crop_w >= 60 else 0.6 + 0.4 * (crop_w - MIN_CROP_W) / (60 - MIN_CROP_W)
        f_jump, reason = 1.0, None
        if self.prev_uv is not None and cand_uv is not None:
            d = math.hypot(cand_uv[0] - self.prev_uv[0], cand_uv[1] - self.prev_uv[1])
            if d > 0.35:
                self.jump_count += 1
                if self.jump_count <= 3:   # a persisting jump is eventually accepted as real
                    f_jump, reason = 0.3, "implausible_jump"
            else:
                self.jump_count = 0
        return det.quality * f_open * stab * f_jump * f_size, reason, stab

    def accepted(self, uv):
        self.prev_uv = uv
