"""Versioned, validated tracking-record schema shared by every component.

Coordinate conventions (see docs/DATA_SCHEMA.md):
  * *_xy        : source-camera-frame pixels, origin top-left, +x right, +y down,
                  "pixel index" convention (centre of the top-left pixel is (0, 0)).
                  The frame is NEVER mirrored; mirroring is a display option.
  * *_rel       : eye-relative (u, v). u = 0 at the image-left eye corner, 1 at the
                  image-right corner. v = 0 on the corner line, +v towards the lower
                  eyelid (down). Both are in units of eye width (corner distance).
  * timestamps  : capture_ts is time.monotonic() seconds; wall_time is unix seconds.
Missing values are None. A record that is not `valid` never carries stale coordinates.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, fields, asdict
from typing import Any, Dict, List, Optional, Tuple

SCHEMA_VERSION = "1.0"
PROVIDERS = ("webcam", "native_vr", "replay", "test")
EYE_STATUSES = ("tracking", "low_confidence", "lost")
Point = Optional[Tuple[float, float]]


def _tup(v):
    if v is None:
        return None
    return tuple(v) if isinstance(v, (list, tuple)) else v


def _finite(v) -> bool:
    if v is None:
        return True
    if isinstance(v, (list, tuple)):
        return all(_finite(x) for x in v)
    if isinstance(v, bool):
        return True
    if isinstance(v, (int, float)):
        return math.isfinite(v)
    return True


@dataclass
class EyeMeasurement:
    side: str = "left"                      # 'left' = subject's left eye (MediaPipe 263/362/473)
    status: str = "lost"                    # tracking | low_confidence | lost
    valid: bool = False                     # True only for an ACCEPTED pupil estimate
    reason: Optional[str] = None            # rejection / invalidity reason
    provenance: Optional[str] = None        # 'pupil_detector' | 'iris_fallback'
    candidate_xy: Point = None              # raw detector candidate (frame px)
    pupil_xy: Point = None                  # accepted + filtered position (frame px)
    iris_xy: Point = None                   # iris centre from landmarks (frame px)
    iris_radius_px: Optional[float] = None
    pupil_rel: Point = None                 # (u, v) of accepted pupil
    iris_rel: Point = None
    corner_a: Point = None                  # image-left eye corner (frame px)
    corner_b: Point = None                  # image-right eye corner (frame px)
    eye_box: Optional[Tuple[int, int, int, int]] = None  # x0, y0, x1, y1 crop box in frame
    pupil_width_px: Optional[float] = None  # axis-aligned extent of the fitted ellipse
    pupil_height_px: Optional[float] = None
    pupil_diameter_px: Optional[float] = None  # equivalent diameter, apparent, NOT millimetres
    openness: Optional[float] = None        # eye aspect ratio (EAR)
    quality: float = 0.0                    # heuristic quality score 0..1 (not a probability)
    detector_quality: Optional[float] = None
    displacement_uv: Point = None           # last frame-to-frame displacement (eye widths)
    velocity_uv: Point = None               # eye widths / s, None across gaps
    speed_uv: Optional[float] = None
    direction: str = "unknown"              # image-plane / eye-relative direction label
    last_valid_ts: Optional[float] = None


@dataclass
class GazeMeasurement:
    valid: bool = False
    status: str = "not_calibrated"          # not_calibrated | ok | invalid | native
    reason: Optional[str] = None
    norm_xy: Point = None                   # normalized screen coords 0..1 (calibrated webcam)
    screen_xy: Point = None                 # screen pixels (calibrated webcam)
    origin: Optional[Tuple[float, float, float]] = None     # native VR
    direction: Optional[Tuple[float, float, float]] = None  # native VR unit vector
    quality: Optional[float] = None
    calibration_id: Optional[str] = None
    last_valid_ts: Optional[float] = None


@dataclass
class TrackingRecord:
    schema_version: str = SCHEMA_VERSION
    session_id: str = ""
    frame_id: int = 0
    capture_ts: float = 0.0
    wall_time: float = 0.0
    processing_ts: float = 0.0
    latency_ms: Optional[float] = None
    provider: str = "webcam"
    state: str = "no_face"                  # tracking | low_confidence | lost | no_face
    face_detected: bool = False
    face_box: Optional[Tuple[float, float, float, float]] = None
    frame_size: Tuple[int, int] = (0, 0)
    left: EyeMeasurement = field(default_factory=lambda: EyeMeasurement(side="left"))
    right: EyeMeasurement = field(default_factory=lambda: EyeMeasurement(side="right"))
    gaze: GazeMeasurement = field(default_factory=GazeMeasurement)
    head_pose: Optional[Dict[str, float]] = None  # yaw/pitch/roll degrees, approximate
    movement: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    calibration_id: Optional[str] = None
    notes: Optional[str] = None
    video_frame: Optional[int] = None

    def eye(self, side: str) -> EyeMeasurement:
        return self.left if side == "left" else self.right

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TrackingRecord":
        rec = cls()
        for f in fields(cls):
            if f.name not in d:
                continue
            v = d[f.name]
            if f.name in ("left", "right"):
                v = _eye_from_dict(v)
            elif f.name == "gaze":
                v = _gaze_from_dict(v)
            elif f.name in ("face_box", "frame_size"):
                v = _tup(v)
            setattr(rec, f.name, v)
        return rec

    def validate(self) -> "TrackingRecord":
        problems = validate_record(self)
        if problems:
            raise ValueError("; ".join(problems))
        return self


def _eye_from_dict(d: Dict[str, Any]) -> EyeMeasurement:
    e = EyeMeasurement()
    for f in fields(EyeMeasurement):
        if f.name in d:
            v = d[f.name]
            setattr(e, f.name, _tup(v) if isinstance(v, list) else v)
    return e


def _gaze_from_dict(d: Dict[str, Any]) -> GazeMeasurement:
    g = GazeMeasurement()
    for f in fields(GazeMeasurement):
        if f.name in d:
            v = d[f.name]
            setattr(g, f.name, _tup(v) if isinstance(v, list) else v)
    return g


def validate_record(rec: TrackingRecord) -> List[str]:
    """Return a list of schema problems (empty list == valid)."""
    p: List[str] = []
    if rec.provider not in PROVIDERS:
        p.append(f"unknown provider {rec.provider!r}")
    if rec.schema_version.split(".")[0] != SCHEMA_VERSION.split(".")[0]:
        p.append(f"unsupported schema {rec.schema_version}")
    for e in (rec.left, rec.right):
        if e.status not in EYE_STATUSES:
            p.append(f"{e.side}: bad status {e.status!r}")
        if not 0.0 <= e.quality <= 1.0:
            p.append(f"{e.side}: quality {e.quality} outside 0..1")
        for f in fields(EyeMeasurement):
            if not _finite(getattr(e, f.name)):
                p.append(f"{e.side}.{f.name} is not finite")
        if e.valid:
            if e.pupil_xy is None:
                p.append(f"{e.side}: valid but pupil_xy missing")
            if e.status != "tracking":
                p.append(f"{e.side}: valid but status={e.status}")
        elif e.pupil_xy is not None or e.pupil_rel is not None:
            p.append(f"{e.side}: not valid but carries pupil coordinates (stale data)")
    g = rec.gaze
    if g.valid and g.norm_xy is None and g.direction is None:
        p.append("gaze valid but has neither norm_xy nor direction")
    if not g.valid and (g.norm_xy is not None or g.direction is not None):
        p.append("gaze invalid but carries stale coordinates")
    for name in ("capture_ts", "wall_time", "processing_ts"):
        if not math.isfinite(getattr(rec, name)):
            p.append(f"{name} not finite")
    return p


def overall_state(rec: TrackingRecord) -> str:
    if not rec.face_detected:
        return "no_face"
    if rec.left.valid or rec.right.valid:
        return "tracking"
    if rec.left.status == "low_confidence" or rec.right.status == "low_confidence":
        return "low_confidence"
    return "lost"


def make_event(kind: str, ts: float, wall: float, **meta) -> Dict[str, Any]:
    return {"type": kind, "ts": ts, "wall_time": wall, **meta}


def flatten_record(rec: TrackingRecord) -> Dict[str, Any]:
    """Stable flat dict (CSV row). Field names never change within a schema major version."""
    r: Dict[str, Any] = {
        "schema_version": rec.schema_version, "session_id": rec.session_id,
        "frame_id": rec.frame_id, "capture_ts": rec.capture_ts, "wall_time": rec.wall_time,
        "latency_ms": rec.latency_ms, "provider": rec.provider, "state": rec.state,
        "face_detected": rec.face_detected,
        "frame_w": rec.frame_size[0] if rec.frame_size else None,
        "frame_h": rec.frame_size[1] if rec.frame_size else None,
        "calibration_id": rec.calibration_id,
        "head_yaw_deg": (rec.head_pose or {}).get("yaw"),
        "head_pitch_deg": (rec.head_pose or {}).get("pitch"),
        "head_roll_deg": (rec.head_pose or {}).get("roll"),
        "gaze_valid": rec.gaze.valid, "gaze_status": rec.gaze.status,
        "gaze_norm_x": rec.gaze.norm_xy[0] if rec.gaze.norm_xy else None,
        "gaze_norm_y": rec.gaze.norm_xy[1] if rec.gaze.norm_xy else None,
        "gaze_screen_x": rec.gaze.screen_xy[0] if rec.gaze.screen_xy else None,
        "gaze_screen_y": rec.gaze.screen_xy[1] if rec.gaze.screen_xy else None,
        "video_frame": rec.video_frame,
        "events": ";".join(e.get("type", "?") for e in rec.events),
    }
    for e in (rec.left, rec.right):
        s = e.side
        for name in ("status", "valid", "reason", "provenance", "quality", "openness", "direction",
                     "speed_uv", "pupil_width_px", "pupil_height_px", "pupil_diameter_px",
                     "iris_radius_px"):
            r[f"{s}_{name}"] = getattr(e, name)
        for name in ("pupil_xy", "candidate_xy", "iris_xy", "pupil_rel", "iris_rel", "velocity_uv"):
            v = getattr(e, name)
            r[f"{s}_{name}_x"] = v[0] if v else None
            r[f"{s}_{name}_y"] = v[1] if v else None
    return r


CSV_COLUMNS: List[str] = list(flatten_record(TrackingRecord()).keys())
