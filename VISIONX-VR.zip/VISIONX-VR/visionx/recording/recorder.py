"""Session recorder: time-stamped records + events to JSONL/CSV (+ optional raw video, opt-in),
written on a background thread with a bounded queue so slow disks never block the UI."""
from __future__ import annotations

import csv
import dataclasses
import json
import logging
import os
import queue
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import cv2

from visionx.models.tracking_models import CSV_COLUMNS, SCHEMA_VERSION, TrackingRecord, flatten_record

log = logging.getLogger("visionx.recorder")


class SessionRecorder:
    STATES = ("idle", "recording", "paused")

    def __init__(self, queue_size: int = 20000):
        self.state = "idle"
        self.dir: Optional[Path] = None
        self.q: "queue.Queue" = queue.Queue(maxsize=queue_size)
        self.thread: Optional[threading.Thread] = None
        self.last_error: Optional[str] = None
        self.dropped = 0
        self.n_records = self.n_events = self.n_frames = 0
        self.start_wall = 0.0
        self.paused_intervals: List[Dict[str, float]] = []
        self._pause_start: Optional[float] = None
        self.manifest: Dict[str, Any] = {}
        self._video: Optional[cv2.VideoWriter] = None
        self._video_expected = False

    @property
    def pending(self) -> int:
        return self.q.qsize()

    @property
    def duration_s(self) -> float:
        if self.state == "idle":
            return 0.0
        return time.time() - self.start_wall

    def start(self, root: str, session_id: str, meta: Dict[str, Any], save_csv=True, save_jsonl=True,
              save_video=False, frame_size=None, fps=30.0) -> Path:
        if self.state != "idle":
            raise RuntimeError("already recording")
        base = Path(root) / session_id
        d, n = base, 1
        while d.exists():                       # never reuse/overwrite a session folder
            d = Path(f"{base}_{n}")
            n += 1
        d.mkdir(parents=True)
        self.dir = d
        self.last_error, self.dropped = None, 0
        self.n_records = self.n_events = self.n_frames = 0
        self.paused_intervals, self._pause_start = [], None
        self.start_wall = time.time()
        self.flags = dict(csv=save_csv, jsonl=save_jsonl, video=bool(save_video))
        self._files = {"records_jsonl": d / "records.jsonl" if save_jsonl else None,
                       "records_csv": d / "records.csv" if save_csv else None,
                       "events_jsonl": d / "events.jsonl", "video": d / "video.mp4" if save_video else None}
        self.manifest = {"schema_version": SCHEMA_VERSION, "session_id": session_id, "started_wall_time": self.start_wall,
                         "status": "recording", "meta": meta,
                         "files": {k: (v.name if v else None) for k, v in self._files.items()},
                         "privacy": {"raw_video_saved": bool(save_video), "images_saved": False,
                                     "note": "Numeric tracking data only unless raw video was enabled."}}
        self._video = None
        if save_video and frame_size:
            vw = cv2.VideoWriter(str(self._files["video"]), cv2.VideoWriter_fourcc(*"mp4v"), float(fps), tuple(frame_size))
            if vw.isOpened():
                self._video = vw
            else:
                self.last_error = "video writer could not be opened; recording numeric data only"
                self.manifest["privacy"]["raw_video_saved"] = False
        self._write_manifest()
        self.state = "recording"
        self.thread = threading.Thread(target=self._run, name="recorder-writer", daemon=True)
        self.thread.start()
        return d

    def pause(self):
        if self.state == "recording":
            self.state, self._pause_start = "paused", time.time()

    def resume(self):
        if self.state == "paused":
            self.paused_intervals.append({"start": self._pause_start, "end": time.time()})
            self.state, self._pause_start = "recording", None

    def write(self, rec: TrackingRecord, frame=None):
        """Called for every processed record. Ignored (by design) while paused or idle."""
        if self.state != "recording":
            return
        r = rec
        if self._video is not None and frame is not None:
            r = dataclasses.replace(rec, video_frame=self.n_frames)
            self._put(("frame", frame))
            self.n_frames += 1
        self._put(("rec", r.to_dict(), flatten_record(r)))
        for e in rec.events:
            self._put(("evt", e))

    def write_event(self, ev: Dict[str, Any]):
        if self.state != "idle":
            self._put(("evt", ev))

    def _put(self, item):
        try:
            self.q.put_nowait(item)
        except queue.Full:
            self.dropped += 1                  # counted and reported, never silent

    def _run(self):
        d = self.dir
        jf = open(self._files["records_jsonl"], "a", encoding="utf-8") if self._files["records_jsonl"] else None
        cf = open(self._files["records_csv"], "a", newline="", encoding="utf-8") if self._files["records_csv"] else None
        ef = open(self._files["events_jsonl"], "a", encoding="utf-8")
        cw = csv.DictWriter(cf, fieldnames=CSV_COLUMNS) if cf else None
        if cw:
            cw.writeheader()
        last_flush = time.monotonic()
        try:
            while True:
                try:
                    item = self.q.get(timeout=0.25)
                except queue.Empty:
                    item = ("tick",)
                if item is None:
                    break
                try:
                    k = item[0]
                    if k == "rec":
                        self.n_records += 1
                        if jf:
                            jf.write(json.dumps(item[1], default=str) + "\n")
                        if cw:
                            cw.writerow(item[2])
                    elif k == "evt":
                        self.n_events += 1
                        ef.write(json.dumps(item[1], default=str) + "\n")
                    elif k == "frame" and self._video is not None:
                        self._video.write(item[1])
                except Exception as e:
                    self.last_error = f"write failed: {type(e).__name__}: {e}"
                    log.error(self.last_error)
                if time.monotonic() - last_flush > 1.0:
                    for f in (jf, cf, ef):
                        if f:
                            f.flush()
                    last_flush = time.monotonic()
        finally:
            for f in (jf, cf, ef):
                if f:
                    try:
                        f.flush()
                        os.fsync(f.fileno())
                        f.close()
                    except Exception as e:
                        self.last_error = f"close failed: {e}"
            if self._video is not None:
                self._video.release()

    def stop(self) -> Dict[str, Any]:
        if self.state == "idle":
            return self.manifest
        if self.state == "paused":
            self.resume()
        self.state = "idle"
        self.q.put(None)                        # sentinel after all queued items
        if self.thread:
            self.thread.join(30)
        self.manifest.update({"status": "complete" if not self.last_error else "complete_with_errors",
                              "ended_wall_time": time.time(), "duration_s": time.time() - self.start_wall,
                              "counts": {"records": self.n_records, "events": self.n_events, "video_frames": self.n_frames},
                              "dropped_records": self.dropped, "paused_intervals": self.paused_intervals,
                              "last_error": self.last_error})
        self._write_manifest()
        return self.manifest

    def _write_manifest(self):
        p = self.dir / "manifest.json"
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.manifest, indent=2, default=str), encoding="utf-8")
        os.replace(tmp, p)
