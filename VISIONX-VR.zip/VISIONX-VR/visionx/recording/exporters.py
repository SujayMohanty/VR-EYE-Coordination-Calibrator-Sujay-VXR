from __future__ import annotations

import csv
import io
import json
from pathlib import Path
from typing import Iterable, List, Optional

from visionx.capture.capture_manager import atomic_write_new
from visionx.models.tracking_models import CSV_COLUMNS, SCHEMA_VERSION, TrackingRecord, flatten_record
from visionx.recording.playback import ReplaySession


def records_to_csv(records: Iterable[TrackingRecord], path: str) -> Path:
    buf = io.StringIO(newline="")
    w = csv.DictWriter(buf, fieldnames=CSV_COLUMNS)
    w.writeheader()
    for r in records:
        w.writerow(flatten_record(r))
    return atomic_write_new(Path(path), buf.getvalue().encode("utf-8"))


def records_to_json(records: Iterable[TrackingRecord], path: str, jsonl: bool = False) -> Path:
    recs = [r.to_dict() for r in records]
    if jsonl:
        data = "".join(json.dumps(r, default=str) + "\n" for r in recs)
    else:
        data = json.dumps({"schema_version": SCHEMA_VERSION, "records": recs}, indent=1, default=str)
    return atomic_write_new(Path(path), data.encode("utf-8"))


def export_session(session_dir: str, out_path: str, fmt: str = "csv", indices: Optional[List[int]] = None) -> Path:
    """Export a recorded session (all or selected sample indices). Never overwrites an existing file."""
    rs = ReplaySession(session_dir)
    try:
        recs = rs.records if indices is None else [rs.records[i] for i in indices]
        if fmt == "csv":
            return records_to_csv(recs, out_path)
        if fmt == "json":
            return records_to_json(recs, out_path)
        if fmt == "jsonl":
            return records_to_json(recs, out_path, jsonl=True)
        raise ValueError(f"unknown export format {fmt!r}")
    finally:
        rs.close()
