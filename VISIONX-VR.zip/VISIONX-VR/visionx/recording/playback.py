"""Replay of recorded sessions (records.jsonl). Numeric replay never pretends video exists."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import cv2
import numpy as np

from visionx.models.tracking_models import TrackingRecord


class ReplayError(Exception):
    pass


def count_captures(root: str, session_id: str) -> int:
    d = Path(root) / "captures"
    return len(list(d.glob(f"cap_{session_id}_*.json"))) if d.exists() else 0


class ReplaySession:
    def __init__(self, directory: str):
        self.dir = Path(directory)
        mp = self.dir / "manifest.json"
        self.manifest: Dict[str, Any] = json.loads(mp.read_text("utf-8")) if mp.exists() else {}
        rp = self.dir / "records.jsonl"
        if not rp.exists():
            raise ReplayError("records.jsonl not found. Only sessions recorded with JSONL can be replayed "
                              "(CSV-only sessions can be exported, not replayed).")
        self.records: List[TrackingRecord] = []
        bad = 0
        for line in rp.read_text("utf-8").splitlines():
            if not line.strip():
                continue
            try:
                self.records.append(TrackingRecord.from_dict(json.loads(line)))
            except (json.JSONDecodeError, TypeError, ValueError):
                bad += 1
        self.bad_lines = bad
        if not self.records:
            raise ReplayError("session contains no readable records")
        self.events: List[Dict[str, Any]] = []
        ep = self.dir / "events.jsonl"
        if ep.exists():
            for line in ep.read_text("utf-8").splitlines():
                try:
                    self.events.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        self.t0 = self.records[0].capture_ts
        self.index = 0
        self.playing = False
        self._pos = 0.0
        self._cap: Optional[cv2.VideoCapture] = None
        vp = self.dir / "video.mp4"
        self.has_video = False
        if vp.exists():
            cap = cv2.VideoCapture(str(vp))
            n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            if cap.isOpened() and n >= len(self.records) - 1 and all(r.video_frame is not None for r in self.records):
                self._cap, self.has_video = cap, True
            else:
                cap.release()

    def __len__(self):
        return len(self.records)

    @property
    def current(self) -> TrackingRecord:
        return self.records[self.index]

    @property
    def duration_s(self) -> float:
        return self.records[-1].capture_ts - self.t0

    def seek(self, i: int) -> TrackingRecord:
        self.index = max(0, min(len(self.records) - 1, int(i)))
        self._pos = self.records[self.index].capture_ts - self.t0
        return self.current

    def step(self, n: int = 1) -> TrackingRecord:
        return self.seek(self.index + n)

    def seek_time(self, t: float) -> TrackingRecord:
        ts = [r.capture_ts - self.t0 for r in self.records]
        return self.seek(int(np.searchsorted(ts, t)))

    def play(self):
        self.playing = True

    def pause(self):
        self.playing = False

    def stop(self):
        self.playing, self.index, self._pos = False, 0, 0.0

    def advance(self, dt: float) -> List[TrackingRecord]:
        """Advance playback by dt real seconds; returns the records passed (for event replay)."""
        if not self.playing:
            return []
        self._pos += dt
        out = []
        while self.index + 1 < len(self.records) and self.records[self.index + 1].capture_ts - self.t0 <= self._pos:
            self.index += 1
            out.append(self.records[self.index])
        if self.index >= len(self.records) - 1:
            self.playing = False
        return out

    def video_frame(self, i: Optional[int] = None) -> Optional[np.ndarray]:
        if not self.has_video:
            return None
        r = self.records[self.index if i is None else i]
        self._cap.set(cv2.CAP_PROP_POS_FRAMES, r.video_frame)
        ok, fr = self._cap.read()
        return fr if ok else None

    def events_between(self, t_a: float, t_b: float) -> List[Dict[str, Any]]:
        return [e for e in self.events if t_a <= e.get("ts", 0) - self.t0 <= t_b]

    def close(self):
        if self._cap:
            self._cap.release()
            self._cap = None

    def summary(self) -> Dict[str, Any]:
        n = len(self.records)
        valid = sum(1 for r in self.records if r.left.valid or r.right.valid)
        counts: Dict[str, int] = {}
        for e in self.events:
            counts[e["type"]] = counts.get(e["type"], 0) + 1
        lost, start = [], None
        for e in sorted((e for e in self.events if e["type"] in ("tracking_lost", "tracking_recovered")),
                        key=lambda e: e["ts"]):
            if e["type"] == "tracking_lost":
                start = e["ts"]
            elif start is not None:
                lost.append({"start_s": start - self.t0, "end_s": e["ts"] - self.t0, "duration_s": e["ts"] - start})
                start = None
        lat = [r.latency_ms for r in self.records if r.latency_ms is not None]
        cal = sorted({r.calibration_id for r in self.records if r.calibration_id})
        sid = self.manifest.get("session_id") or self.records[0].session_id
        return {"session_id": sid, "duration_s": self.duration_s, "records": n, "valid_samples": valid,
                "valid_percent": 100.0 * valid / n, "blink_count": counts.get("blink", 0),
                "tracking_loss_intervals": lost, "event_counts": counts,
                "calibration": cal or ["NOT CALIBRATED"], "mean_latency_ms": float(np.mean(lat)) if lat else None,
                "has_video": self.has_video, "unreadable_lines": self.bad_lines,
                "captures": count_captures(str(self.dir.parent), sid)}
