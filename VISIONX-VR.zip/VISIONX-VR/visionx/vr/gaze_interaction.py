"""Optional gaze interaction: hover enter/exit, dwell selection, cooldown, cancellation rules."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Target:
    id: str
    rect: Tuple[float, float, float, float]   # x0, y0, x1, y1 in normalized screen coords


class GazeInteractionEngine:
    def __init__(self, dwell_ms: float = 800, cooldown_ms: float = 1000, min_quality: float = 0.0,
                 blink_select: bool = False):
        self.dwell_s, self.cooldown_s, self.min_q, self.blink_select = dwell_ms / 1000, cooldown_ms / 1000, min_quality, blink_select
        self.targets: Dict[str, Target] = {}
        self.hover: Optional[str] = None
        self.hover_since = 0.0
        self.cooldown_until: Dict[str, float] = {}
        self.provider = ""
        self.log: List[Dict[str, Any]] = []

    def add_target(self, t: Target):
        self.targets[t.id] = t

    def _ev(self, kind, t, **kw):
        e = {"type": kind, "ts": t, **kw}
        self.log.append(e)
        return e

    def _hit(self, xy) -> Optional[str]:
        for t in self.targets.values():
            if t.rect[0] <= xy[0] <= t.rect[2] and t.rect[1] <= xy[1] <= t.rect[3]:
                return t.id
        return None

    def _leave(self, t, reason, out):
        if self.hover is not None:
            if t - self.hover_since < self.dwell_s:
                out.append(self._ev("dwell_cancel", t, target=self.hover, reason=reason))
            out.append(self._ev("gaze_exit", t, target=self.hover))
        self.hover = None

    def update(self, t: float, valid: bool, xy: Optional[Tuple[float, float]], quality: Optional[float] = None,
               paused: bool = False, provider: str = "") -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        if provider != self.provider:
            self._leave(t, "provider_changed", out)
            self.provider = provider
        if paused:
            self._leave(t, "paused", out)
            return out
        if not valid or xy is None or (quality is not None and quality < self.min_q):
            self._leave(t, "invalid_gaze", out)
            return out
        hit = self._hit(xy)
        if hit != self.hover:
            self._leave(t, "target_changed" if hit else "left_target", out)
            if hit:
                self.hover, self.hover_since = hit, t
                out.append(self._ev("gaze_enter", t, target=hit))
            return out
        if self.hover and t - self.hover_since >= self.dwell_s and t >= self.cooldown_until.get(self.hover, 0):
            out.append(self._ev("select", t, target=self.hover, method="dwell"))
            self.cooldown_until[self.hover] = t + self.cooldown_s
            self.hover_since = t + self.cooldown_s    # no repeat activation while still looking
        return out

    def confirm(self, t: float, method: str = "confirm") -> Optional[Dict[str, Any]]:
        """Controller/keyboard/mouse confirmation of the currently hovered target."""
        if self.hover and t >= self.cooldown_until.get(self.hover, 0):
            self.cooldown_until[self.hover] = t + self.cooldown_s
            return self._ev("select", t, target=self.hover, method=method)
        return None

    def on_blink(self, t: float) -> Optional[Dict[str, Any]]:
        return self.confirm(t, "blink") if self.blink_select else None
