"""Local gaze bridge: newline-free JSON datagrams over UDP (loopback by default).
Packet (v1): {"v":1,"seq":int,"t":float,"valid":bool,"origin":[x,y,z],"direction":[x,y,z],
              "confidence":0..1,"space":"world|head|local"}  t = sender clock seconds (informational)."""
from __future__ import annotations

import json
import math
import socket
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

MAX_PACKET = 4096


class PacketError(ValueError):
    pass


@dataclass
class GazePacket:
    seq: int
    t: float
    valid: bool
    origin: Optional[Tuple[float, float, float]]
    direction: Optional[Tuple[float, float, float]]
    confidence: Optional[float]
    space: str = "world"
    arrival: float = 0.0


def _vec3(v, name):
    if v is None:
        return None
    if not (isinstance(v, (list, tuple)) and len(v) == 3 and all(isinstance(x, (int, float)) and math.isfinite(x) for x in v)):
        raise PacketError(f"{name} must be 3 finite numbers")
    return (float(v[0]), float(v[1]), float(v[2]))


def encode_packet(seq: int, t: float, valid: bool, origin=None, direction=None, confidence=None, space="world") -> bytes:
    return json.dumps({"v": 1, "seq": seq, "t": t, "valid": valid, "origin": origin, "direction": direction,
                       "confidence": confidence, "space": space}).encode()


def decode_packet(data: bytes) -> GazePacket:
    if len(data) > MAX_PACKET:
        raise PacketError("packet too large")
    try:
        d = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise PacketError(f"bad json: {e}") from None
    if not isinstance(d, dict) or d.get("v") != 1:
        raise PacketError("unsupported packet version")
    valid = d.get("valid")
    if not isinstance(valid, bool):
        raise PacketError("'valid' must be bool")
    origin, direction = _vec3(d.get("origin"), "origin"), _vec3(d.get("direction"), "direction")
    if valid:
        if direction is None:
            raise PacketError("valid packet needs direction")
        n = math.sqrt(sum(x * x for x in direction))
        if n < 1e-6:
            raise PacketError("zero-length direction")
        direction = tuple(x / n for x in direction)
    else:
        origin = direction = None                       # invalid gaze carries no coordinates
    conf = d.get("confidence")
    if conf is not None and not (isinstance(conf, (int, float)) and 0 <= conf <= 1):
        raise PacketError("confidence outside 0..1")
    seq, t = d.get("seq"), d.get("t")
    if not isinstance(seq, int) or not isinstance(t, (int, float)) or not math.isfinite(t):
        raise PacketError("bad seq/t")
    return GazePacket(seq, float(t), valid, origin, direction, conf, str(d.get("space", "world")))


class UdpGazeReceiver:
    def __init__(self, port: int, host: str = "127.0.0.1"):
        self.host, self.port = host, port
        self.sock: Optional[socket.socket] = None
        self.thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._latest: Optional[GazePacket] = None
        self.received = self.rejected = 0
        self.last_error: Optional[str] = None

    def start(self) -> int:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind((self.host, self.port))
        s.settimeout(0.1)
        self.sock, self.port = s, s.getsockname()[1]
        self._stop.clear()
        self.thread = threading.Thread(target=self._run, name="gaze-udp", daemon=True)
        self.thread.start()
        return self.port

    def _run(self):
        while not self._stop.is_set():
            try:
                data, _ = self.sock.recvfrom(MAX_PACKET + 1)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                p = decode_packet(data)
                p.arrival = time.monotonic()
                with self._lock:
                    self._latest = p
                self.received += 1
            except PacketError as e:
                self.rejected += 1
                self.last_error = str(e)

    def latest(self) -> Optional[GazePacket]:
        with self._lock:
            return self._latest

    def stop(self):
        self._stop.set()
        if self.thread:
            self.thread.join(1.0)
        if self.sock:
            self.sock.close()
            self.sock = None


class UdpGazeSender:
    def __init__(self, port: int, host: str = "127.0.0.1"):
        self.addr, self.sock, self.seq = (host, port), socket.socket(socket.AF_INET, socket.SOCK_DGRAM), 0

    def send(self, valid: bool, origin=None, direction=None, confidence=None, space="world"):
        self.seq += 1
        self.sock.sendto(encode_packet(self.seq, time.monotonic(), valid, origin, direction, confidence, space), self.addr)

    def close(self):
        self.sock.close()
