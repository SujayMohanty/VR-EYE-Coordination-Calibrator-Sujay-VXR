"""OpenXR capability probe + provider facade.

HONESTY NOTE: this module can only report what the installed runtime *advertises*
(XR_EXT_eye_gaze_interaction). Streaming gaze poses requires an active XR session with a graphics
binding, which a desktop Python tool cannot provide. Native gaze therefore reaches VISIONX through
the local UDP bridge (see unity/GazeBridge.cs). A connected headset is never treated as 'tracking'."""
from __future__ import annotations

from typing import Optional

from visionx.models.tracking_models import TrackingRecord
from visionx.vr.base_provider import GazeProvider, ProviderStatus

EXT = "XR_EXT_eye_gaze_interaction"


def probe_openxr() -> ProviderStatus:
    try:
        import xr  # pyopenxr (optional dependency)
    except Exception as e:
        return ProviderStatus(False, False, None, False, False,
                              f"pyopenxr not installed or failed to import ({type(e).__name__}); OpenXR probe unavailable.")
    try:
        exts = list(xr.enumerate_instance_extension_properties())
        names = [getattr(x, "extension_name", x) for x in exts]
        names = [n.decode() if isinstance(n, bytes) else str(n) for n in names]
    except Exception as e:
        return ProviderStatus(False, False, None, False, False, f"No OpenXR runtime responded: {e}")
    have = EXT in names
    return ProviderStatus(True, have, None, False, False,
                          (f"Runtime detected; {EXT} {'advertised' if have else 'NOT advertised'}. Permission is only "
                           "requested/known inside an XR session. No gaze data is being received by this process."))


class OpenXRProvider(GazeProvider):
    name = "OpenXR (capability probe only)"

    def __init__(self):
        self._status = ProviderStatus()

    def start(self) -> ProviderStatus:
        self._status = probe_openxr()
        return self._status

    def poll(self) -> Optional[TrackingRecord]:
        return None   # never fabricate gaze

    def status(self) -> ProviderStatus:
        return self._status
