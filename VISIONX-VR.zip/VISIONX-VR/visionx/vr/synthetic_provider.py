from __future__ import annotations

import math
import time
from typing import Optional

from visionx.models.tracking_models import GazeMeasurement, TrackingRecord
from visionx.vr.base_provider import GazeProvider, ProviderStatus


class SyntheticGazeProvider(GazeProvider):
    """TEST ONLY. Produces scripted gaze. Records carry provider='test' so it can never be mistaken
    for genuine eye tracking."""
    name = "TEST PROVIDER (synthetic - NOT real eye tracking)"
    provider_type = "test"

    def __init__(self):
        self.n = 0

    def start(self):
        return ProviderStatus(False, False, None, True, False, "synthetic test provider")

    def status(self):
        return ProviderStatus(False, False, None, True, True, "synthetic test provider")

    def poll(self) -> Optional[TrackingRecord]:
        self.n += 1
        t = time.monotonic()
        a = self.n * 0.05
        r = TrackingRecord(provider="test", frame_id=self.n, capture_ts=t, wall_time=time.time(), notes="SYNTHETIC")
        r.gaze = GazeMeasurement(True, "native", None, None, None, (0, 0, 0), (math.sin(a) * 0.2, 0.0, -1.0), 1.0, None, t)
        r.state = "tracking"
        return r
