from __future__ import annotations

import time
from typing import Optional

from visionx.models.tracking_models import GazeMeasurement, TrackingRecord
from visionx.vr.base_provider import GazeProvider, ProviderStatus
from visionx.vr.transport import UdpGazeReceiver


class UdpBridgeProvider(GazeProvider):
    """Native headset gaze delivered by an external app (e.g. Unity) over loopback UDP."""
    name = "Native VR gaze (UDP bridge)"
    provider_type = "native_vr"

    def __init__(self, port: int = 49152, stale_ms: int = 200, session_id: str = ""):
        self.rx = UdpGazeReceiver(port)
        self.stale_s, self.session_id = stale_ms / 1000.0, session_id
        self._seen_seq = -1
        self._frame = 0
        self._stale_reported = True
        self._st = ProviderStatus()

    def start(self) -> ProviderStatus:
        try:
            port = self.rx.start()
            self._st = ProviderStatus(None, None, None, True, False, f"Listening on 127.0.0.1:{port}; waiting for packets.")
        except OSError as e:
            self._st = ProviderStatus(None, None, None, False, False, f"Cannot bind UDP port: {e}")
        return self._st

    def status(self) -> ProviderStatus:
        return self._st

    def poll(self) -> Optional[TrackingRecord]:
        p, now = self.rx.latest(), time.monotonic()
        if p is None:
            return None
        rec = TrackingRecord(session_id=self.session_id, provider="native_vr", capture_ts=p.arrival, wall_time=time.time(),
                             processing_ts=now, face_detected=False)
        age = now - p.arrival
        if age > self.stale_s:                      # stale data is never reused as current gaze
            if self._stale_reported:
                return None
            self._stale_reported = True
            rec.gaze = GazeMeasurement(False, "invalid", "stale")
            rec.capture_ts, rec.state = now, "lost"
            self._st.valid_gaze_received = False
            self._frame += 1
            rec.frame_id = self._frame
            return rec
        if p.seq == self._seen_seq:
            return None
        self._seen_seq, self._stale_reported = p.seq, False
        self._frame += 1
        rec.frame_id = self._frame
        if p.valid:
            rec.gaze = GazeMeasurement(True, "native", None, None, None, p.origin, p.direction, p.confidence, None, p.arrival)
            rec.state = "tracking"
            self._st.valid_gaze_received = True
        else:
            rec.gaze = GazeMeasurement(False, "invalid", "headset_reports_invalid")
            rec.state = "lost"
            self._st.valid_gaze_received = False
        return rec

    def stop(self):
        self.rx.stop()
