from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional

from visionx.models.tracking_models import TrackingRecord


@dataclass
class ProviderStatus:
    """Each stage is reported separately. None = cannot be determined from here."""
    runtime_detected: Optional[bool] = False
    feature_available: Optional[bool] = False
    permission_granted: Optional[bool] = None
    initialized: bool = False
    valid_gaze_received: bool = False
    detail: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class GazeProvider(ABC):
    name = "provider"
    provider_type = "native_vr"   # or "test"

    @abstractmethod
    def start(self) -> ProviderStatus: ...

    @abstractmethod
    def poll(self) -> Optional[TrackingRecord]:
        """Return a NEW record if one is available, else None."""

    @abstractmethod
    def status(self) -> ProviderStatus: ...

    def stop(self) -> None:
        pass
