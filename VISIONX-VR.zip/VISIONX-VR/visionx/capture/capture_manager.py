"""Capture engine. Writes happen on a background thread; a capture is reported ONLY after its files
were actually written (atomically, never overwriting). Partial failures are reported per artifact."""
from __future__ import annotations

import csv
import json
import logging
import os
import queue
import shutil
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import cv2
import numpy as np

from visionx.models.tracking_models import CSV_COLUMNS, flatten_record
from visionx.render.overlay import OverlayOptions, render_annotated_frame, render_eye
from visionx.tracking.base_provider import FrameBundle

log = logging.getLogger("visionx.capture")
LOW_DISK_BYTES = 500 * 1024 * 1024


def atomic_write_new(path: Path, data: bytes) -> Path:
    """Write via temp file + hard link so an existing file is never silently replaced.
    If `path` exists a numeric suffix is chosen. Returns the final path."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.parent / f".{path.name}.{uuid.uuid4().hex[:8]}.tmp"
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    try:
        for n in range(0, 1000):
            final = path if n == 0 else path.with_name(f"{path.stem}_{n}{path.suffix}")
            try:
                os.link(tmp, final)
                return final
            except FileExistsError:
                continue
            except OSError:  # filesystem without hard links
                if final.exists():
                    continue
                os.replace(tmp, final)
                return final
        raise FileExistsError(f"could not find a free name for {path}")
    finally:
        if tmp.exists():
            tmp.unlink()


def encode_image(img: np.ndarray, ext: str = ".png") -> bytes:
    ok, buf = cv2.imencode(ext, img)
    if not ok:
        raise ValueError(f"could not encode image as {ext}")
    return buf.tobytes()


def build_artifacts(bundle: FrameBundle, names: List[str], opts: OverlayOptions, trails=None
                    ) -> Dict[str, Any]:
    """name -> ndarray, or an Exception-string ('!reason') when it cannot be produced."""
    out: Dict[str, Any] = {}
    fr = bundle.frame
    for n in names:
        try:
            if fr is None:
                raise ValueError("no frame available")
            if n == "raw_frame":
                out[n] = fr.copy()
            elif n == "annotated_frame":
                out[n] = render_annotated_frame(bundle, opts, trails)
            elif n.endswith(("_eye_crop", "_eye_overlay")) or n.startswith("processed_"):
                side = "left" if n.startswith(("left", "processed_left")) else "right"
                e = bundle.record.eye(side)
                if e.eye_box is None:
                    raise ValueError(f"{side} eye region unavailable")
                x0, y0, x1, y1 = e.eye_box
                if n.endswith("_eye_crop"):
                    out[n] = fr[y0:y1, x0:x1].copy()
                elif n.endswith("_eye_overlay"):
                    s = 4
                    o = OverlayOptions(**{**opts.__dict__, "mirror": False})
                    out[n] = render_eye(bundle, side, ((x1 - x0) * s, (y1 - y0) * s), o, "overlay", 1.0, trails)
                else:
                    pr = bundle.processed.get(side)
                    if pr is None:
                        raise ValueError("processed view unavailable (eye closed / not analysed)")
                    out[n] = pr[0].copy()
            else:
                raise ValueError("unknown artifact")
        except Exception as ex:
            out[n] = f"!{ex}"
    return out


@dataclass
class CaptureResult:
    capture_id: str
    kind: str                     # sample | image | auto
    timestamp: float
    session_id: str
    frame_id: int
    status: str                   # ok | partial | failed
    files: Dict[str, str] = field(default_factory=dict)
    failed: Dict[str, str] = field(default_factory=dict)
    record: Dict[str, Any] = field(default_factory=dict)
    summary: Dict[str, Any] = field(default_factory=dict)
    message: str = ""


@dataclass
class _Job:
    capture_id: str
    kind: str
    record: Dict[str, Any]
    flat: Dict[str, Any]
    images: Dict[str, Any]
    meta: Dict[str, Any]
    timestamp: float
    write_sample: bool


class CaptureManager:
    def __init__(self, root: str, session_id: str, on_result: Optional[Callable[[CaptureResult], None]] = None,
                 max_files: int = 2000, image_ext: str = ".png"):
        self.root = Path(root) / "captures"
        self.session_id, self.on_result, self.max_files, self.ext = session_id, on_result, max_files, image_ext
        self.counter = 0
        self.files_written = 0
        self.counts = {"samples": 0, "eye_crops": 0, "annotated_frames": 0, "raw_frames": 0, "processed": 0}
        self.last_success: Optional[float] = None
        self.last_error: Optional[str] = None
        self.history: List[CaptureResult] = []
        self._q: "queue.Queue[Optional[_Job]]" = queue.Queue()
        self._pending = 0
        self._lock = threading.Lock()
        self._t = threading.Thread(target=self._run, name="capture-writer", daemon=True)
        self._t.start()

    @property
    def pending(self) -> int:
        return self._pending

    def disk_free(self) -> Optional[int]:
        try:
            Path(self.root).mkdir(parents=True, exist_ok=True)
            return shutil.disk_usage(self.root).free
        except OSError:
            return None

    def submit(self, kind: str, bundle: FrameBundle, images: Dict[str, Any], meta: Dict[str, Any],
               write_sample: bool = True) -> str:
        with self._lock:
            self.counter += 1
            cid = f"cap_{self.session_id}_{self.counter:05d}"
            self._pending += 1
        rec = bundle.record
        self._q.put(_Job(cid, kind, rec.to_dict(), flatten_record(rec), images, meta, time.time(), write_sample))
        return cid

    def _run(self):
        while True:
            job = self._q.get()
            if job is None:
                return
            try:
                res = self._write(job)
            except Exception as e:  # never let the writer thread die
                log.exception("capture write crashed")
                res = CaptureResult(job.capture_id, job.kind, job.timestamp, self.session_id, job.record["frame_id"],
                                    "failed", failed={"*": str(e)}, record=job.record, message=f"Capture failed: {e}")
            with self._lock:
                self._pending -= 1
                self.history.append(res)
                self.history = self.history[-200:]
                if res.status != "failed":
                    self.last_success = res.timestamp
                else:
                    self.last_error = res.message
            if self.on_result:
                try:
                    self.on_result(res)
                except Exception:
                    log.exception("on_result failed")

    def _write(self, job: _Job) -> CaptureResult:
        files, failed = {}, {}
        res = CaptureResult(job.capture_id, job.kind, job.timestamp, self.session_id, job.record["frame_id"], "ok",
                            record=job.record, summary=_summary(job.record))
        free = self.disk_free()
        if free is not None and free < LOW_DISK_BYTES:
            log.warning("low disk space: %d MB", free // 2**20)
        for name, img in job.images.items():
            if self.files_written >= self.max_files:
                failed[name] = "file limit reached (capture.max_files)"
                continue
            if isinstance(img, str):
                failed[name] = img.lstrip("!")
                continue
            try:
                p = atomic_write_new(self.root / f"{job.capture_id}_{name}{self.ext}", encode_image(img, self.ext))
                files[name] = str(p)
                self.files_written += 1
                if name.endswith("_crop") or name.endswith("_overlay"):
                    self.counts["eye_crops"] += 1
                elif name == "annotated_frame":
                    self.counts["annotated_frames"] += 1
                elif name == "raw_frame":
                    self.counts["raw_frames"] += 1
                else:
                    self.counts["processed"] += 1
            except Exception as e:
                failed[name] = f"{type(e).__name__}: {e}"
        meta_ok = True
        if job.write_sample:
            doc = {"capture_id": job.capture_id, "kind": job.kind, "session_id": self.session_id,
                   "saved_wall_time": job.timestamp, "files": files, "failed_artifacts": failed,
                   "meta": job.meta, "record": job.record,
                   "note": "Invalid eye states are stored explicitly; no measurement was fabricated."}
            try:
                p = atomic_write_new(self.root / f"{job.capture_id}.json", json.dumps(doc, indent=2, default=str).encode())
                files["metadata"] = str(p)
                self._append_csv(job)
                self.counts["samples"] += 1
            except Exception as e:
                failed["metadata"] = f"{type(e).__name__}: {e}"
                meta_ok = False
        res.files, res.failed = files, failed
        wrote = len(files)
        res.status = "failed" if wrote == 0 else ("partial" if failed or not meta_ok else "ok")
        res.message = (f"Saved {wrote} file(s) for {job.capture_id}" if res.status == "ok" else
                       f"Partial save ({wrote} saved, {len(failed)} failed): " + "; ".join(f"{k}: {v}" for k, v in failed.items())
                       if res.status == "partial" else "Capture failed: " + "; ".join(f"{k}: {v}" for k, v in failed.items()))
        if res.status != "ok":
            self.last_error = res.message
        return res

    def _append_csv(self, job: _Job):
        p = self.root / "samples.csv"
        new = not p.exists()
        row = dict(job.flat)
        row["capture_id"] = job.capture_id
        with open(p, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["capture_id"] + CSV_COLUMNS)
            if new:
                w.writeheader()
            w.writerow(row)
            f.flush()
            os.fsync(f.fileno())

    def flush(self, timeout: float = 10.0) -> bool:
        t0 = time.monotonic()
        while self._pending > 0 and time.monotonic() - t0 < timeout:
            time.sleep(0.01)
        return self._pending == 0

    def close(self, timeout: float = 5.0):
        self.flush(timeout)
        self._q.put(None)
        self._t.join(timeout)


def _summary(rec: Dict[str, Any]) -> Dict[str, Any]:
    return {"state": rec.get("state"), "left_valid": rec["left"]["valid"], "right_valid": rec["right"]["valid"],
            "left_pupil_xy": rec["left"]["pupil_xy"], "right_pupil_xy": rec["right"]["pupil_xy"],
            "left_iris_xy": rec["left"]["iris_xy"], "right_iris_xy": rec["right"]["iris_xy"],
            "quality": [rec["left"]["quality"], rec["right"]["quality"]],
            "calibration": rec.get("calibration_id") or "NOT CALIBRATED",
            "events": [e["type"] for e in rec.get("events", [])], "provider": rec.get("provider")}


class AutoCaptureTrigger:
    """Throttled automatic capture: periodic / blink / fixation / saccade / recovery, with duplicate suppression."""

    def __init__(self, mode="off", interval_s=5.0, min_interval_s=1.0):
        self.mode, self.interval_s, self.min_interval_s = mode, interval_s, min_interval_s
        self.last = -1e9

    def should_capture(self, rec, now: float) -> Optional[str]:
        if self.mode == "off" or now - self.last < self.min_interval_s:
            return None
        hit = None
        if self.mode == "periodic":
            hit = "periodic" if now - self.last >= self.interval_s else None
        else:
            hit = next((e["type"] for e in rec.events if self._match(e["type"])), None)
        if hit:
            self.last = now
        return hit

    def _match(self, t):
        return {"blink": "blink", "fixation": "fixation", "saccade": "saccade", "recovery": "tracking_recovered"}.get(self.mode) == t
