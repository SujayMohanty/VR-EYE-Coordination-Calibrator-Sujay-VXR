"""Schema-driven, validated settings. Drives both persistence and the Settings dialog."""
from __future__ import annotations

import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence


@dataclass
class Field:
    key: str
    label: str
    kind: str                      # bool int float str choice color path multi
    default: Any
    group: str = "General"
    min: Optional[float] = None
    max: Optional[float] = None
    choices: Optional[Sequence[str]] = None
    help: str = ""


ARTIFACTS = ["raw_frame", "annotated_frame", "left_eye_crop", "right_eye_crop",
             "left_eye_overlay", "right_eye_overlay", "processed_left", "processed_right"]

SCHEMA: List[Field] = [
    # camera
    Field("camera.index", "Camera index", "int", 0, "Camera", 0, 32),
    Field("camera.width", "Preferred width", "int", 1280, "Camera", 160, 7680),
    Field("camera.height", "Preferred height", "int", 720, "Camera", 120, 4320),
    Field("camera.fps", "Preferred frame rate", "int", 30, "Camera", 1, 240),
    Field("camera.mirror", "Mirrored preview", "bool", True, "Camera",
          help="Display only. Stored coordinates are never mirrored."),
    Field("camera.brightness", "Brightness (-1 = leave unchanged)", "float", -1.0, "Camera", -1, 255,
          help="Only applied if the camera driver supports it."),
    # tracking
    Field("tracking.provider", "Tracking provider", "choice", "webcam", "Tracking",
          choices=["webcam", "udp_bridge", "openxr"]),
    Field("tracking.preset", "Performance preset", "choice", "balanced", "Tracking",
          choices=["performance", "balanced", "precision"]),
    Field("tracking.proc_width", "Landmark processing width (px)", "int", 640, "Tracking", 160, 1920),
    Field("tracking.confidence_threshold", "Confidence threshold", "float", 0.45, "Tracking", 0.05, 0.95),
    Field("tracking.smoothing_method", "Smoothing", "choice", "ema", "Tracking",
          choices=["none", "ema", "moving_average", "median", "kalman"]),
    Field("tracking.smoothing_strength", "Smoothing strength", "float", 0.4, "Tracking", 0.0, 1.0),
    Field("tracking.eye_crop_pad", "Eye crop padding", "float", 0.35, "Tracking", 0.1, 1.0),
    Field("tracking.allow_iris_fallback", "Use iris centre when pupil not found", "bool", False, "Tracking",
          help="Accepted positions are then labelled provenance=iris_fallback."),
    Field("tracking.head_pose", "Estimate head pose", "bool", True, "Tracking"),
    Field("pupil.detector_width", "Pupil detector working width", "int", 128, "Pupil detector", 48, 320),
    Field("pupil.threshold_fraction", "Dark threshold fraction", "float", 0.4, "Pupil detector", 0.1, 0.9),
    Field("pupil.min_contrast", "Minimum contrast (grey levels)", "float", 18.0, "Pupil detector", 2, 100),
    Field("pupil.min_area_ratio", "Min pupil/iris area ratio", "float", 0.04, "Pupil detector", 0.005, 0.5),
    Field("pupil.max_area_ratio", "Max pupil/iris area ratio", "float", 0.75, "Pupil detector", 0.2, 1.2),
    Field("pupil.min_circularity", "Min circularity", "float", 0.55, "Pupil detector", 0.1, 0.98),
    # overlay
    Field("overlay.face_box", "Face box", "bool", True, "Overlay"),
    Field("overlay.landmarks", "Facial landmarks", "bool", False, "Overlay"),
    Field("overlay.eye_outline", "Eye outlines", "bool", True, "Overlay"),
    Field("overlay.reticle", "Blue pupil reticle", "bool", True, "Overlay"),
    Field("overlay.iris", "Iris marker", "bool", True, "Overlay"),
    Field("overlay.trail", "Movement trail", "bool", True, "Overlay"),
    Field("overlay.gaze", "Gaze indicator", "bool", True, "Overlay"),
    Field("overlay.coords", "Coordinates", "bool", True, "Overlay"),
    Field("overlay.head_pose", "Head-pose axes", "bool", False, "Overlay"),
    Field("overlay.trail_left", "Left trail", "bool", True, "Overlay"),
    Field("overlay.trail_right", "Right trail", "bool", True, "Overlay"),
    Field("overlay.trail_length", "Trail length (samples)", "int", 40, "Overlay", 2, 400),
    Field("overlay.reticle_size", "Reticle size", "float", 1.0, "Overlay", 0.4, 3.0),
    Field("overlay.reticle_brightness", "Reticle brightness", "float", 1.0, "Overlay", 0.2, 1.0),
    Field("overlay.color_primary", "Primary colour", "color", "#00B7FF", "Overlay"),
    Field("overlay.color_secondary", "Secondary colour", "color", "#40E7FF", "Overlay"),
    Field("overlay.diagnostic", "Diagnostic mode (show candidates)", "bool", False, "Overlay"),
    # monitor
    Field("monitor.auto_open", "Open Pupil Monitor on launch", "bool", True, "Windows"),
    Field("monitor.view_mode", "Eye view mode", "choice", "overlay", "Windows",
          choices=["raw", "landmarks", "overlay", "processed", "side_by_side"]),
    Field("monitor.plot_window_s", "Plot time window (s)", "float", 10.0, "Windows", 2, 120),
    Field("monitor.update_hz", "Display update rate (Hz)", "int", 30, "Windows", 5, 60),
    # capture / recording
    Field("capture.directory", "Output directory", "path", "recordings", "Capture"),
    Field("capture.artifacts", "Capture Image artifacts", "multi",
          ["raw_frame", "annotated_frame", "left_eye_crop", "right_eye_crop"], "Capture", choices=ARTIFACTS),
    Field("capture.auto_mode", "Automatic capture trigger", "choice", "off", "Capture",
          choices=["off", "periodic", "blink", "fixation", "saccade", "recovery"]),
    Field("capture.auto_interval_s", "Periodic interval (s)", "float", 5.0, "Capture", 0.5, 3600),
    Field("capture.auto_images", "Automatic captures also save images", "bool", False, "Capture"),
    Field("capture.min_interval_s", "Minimum seconds between auto captures", "float", 1.0, "Capture", 0.1, 600),
    Field("capture.max_files", "Maximum files per session", "int", 2000, "Capture", 10, 1000000),
    Field("recording.save_csv", "Record CSV", "bool", True, "Recording"),
    Field("recording.save_jsonl", "Record JSONL", "bool", True, "Recording"),
    Field("recording.save_video", "Record raw video (privacy: saves your face)", "bool", False, "Recording"),
    # calibration
    Field("calibration.points", "Calibration points", "choice", "9", "Calibration", choices=["5", "9", "13"]),
    Field("calibration.samples_per_point", "Samples per point", "int", 20, "Calibration", 5, 200),
    Field("calibration.settle_ms", "Settle time per point (ms)", "int", 700, "Calibration", 0, 5000),
    Field("calibration.use_head_pose", "Include head pose features", "bool", False, "Calibration"),
    # events
    Field("events.blink_abs_close", "Blink: closed EAR (no baseline)", "float", 0.17, "Events", 0.05, 0.4),
    Field("events.blink_close_ratio", "Blink: close ratio of baseline", "float", 0.65, "Events", 0.3, 0.95),
    Field("events.blink_open_ratio", "Blink: reopen ratio of baseline", "float", 0.8, "Events", 0.4, 1.0),
    Field("events.blink_min_ms", "Blink: min duration (ms)", "float", 40.0, "Events", 10, 500),
    Field("events.blink_max_ms", "Blink: max duration (ms)", "float", 600.0, "Events", 100, 3000),
    Field("events.prolonged_closure_ms", "Prolonged closure (ms)", "float", 1500.0, "Events", 300, 10000),
    Field("events.direction_threshold", "Direction speed threshold (eye widths/s)", "float", 0.35, "Events", 0.02, 5),
    Field("events.fixation_dispersion", "Fixation dispersion (eye widths)", "float", 0.05, "Events", 0.005, 0.5),
    Field("events.fixation_min_ms", "Fixation min duration (ms)", "float", 150.0, "Events", 50, 2000),
    Field("events.saccade_velocity", "Saccade velocity (eye widths/s)", "float", 1.5, "Events", 0.2, 20),
    Field("events.saccade_min_amplitude", "Saccade min amplitude (eye widths)", "float", 0.05, "Events", 0.005, 1),
    Field("events.saccade_min_ms", "Saccade min duration (ms)", "float", 30.0, "Events", 5, 300),
    Field("events.blink_select", "Blink selection for VR interaction", "bool", False, "Events"),
    # VR
    Field("vr.udp_port", "UDP bridge port", "int", 49152, "VR", 1024, 65535),
    Field("vr.stale_ms", "Native gaze stale after (ms)", "int", 200, "VR", 20, 5000),
    Field("vr.dwell_ms", "Dwell selection (ms)", "int", 800, "VR", 100, 5000),
]
BY_KEY = {f.key: f for f in SCHEMA}

PRESETS = {
    "performance": {"tracking.proc_width": 480, "pupil.detector_width": 96, "tracking.smoothing_method": "ema",
                    "monitor.update_hz": 20, "overlay.trail_length": 20},
    "balanced": {"tracking.proc_width": 640, "pupil.detector_width": 128, "tracking.smoothing_method": "ema",
                 "monitor.update_hz": 30, "overlay.trail_length": 40},
    "precision": {"tracking.proc_width": 960, "pupil.detector_width": 192, "tracking.smoothing_method": "kalman",
                  "monitor.update_hz": 30, "overlay.trail_length": 60},
}


def user_config_path() -> Path:
    base = os.environ.get("APPDATA") if sys.platform.startswith("win") else None
    root = Path(base) / "VISIONX" if base else Path.home() / ".config" / "visionx"
    return root / "settings.json"


def _coerce(f: Field, v: Any) -> Any:
    if f.kind == "bool":
        if isinstance(v, bool):
            return v
        raise ValueError(f"{f.key}: expected true/false")
    if f.kind in ("int", "float"):
        if isinstance(v, bool) or not isinstance(v, (int, float, str)):
            raise ValueError(f"{f.key}: expected a number")
        try:
            x = int(float(v)) if f.kind == "int" else float(v)
        except ValueError:
            raise ValueError(f"{f.key}: '{v}' is not a number") from None
        if x != x or x in (float("inf"), float("-inf")):
            raise ValueError(f"{f.key}: not finite")
        if f.min is not None and x < f.min or f.max is not None and x > f.max:
            raise ValueError(f"{f.key}: {x} outside [{f.min}, {f.max}]")
        return x
    if f.kind == "choice":
        if str(v) not in [str(c) for c in f.choices or []]:
            raise ValueError(f"{f.key}: '{v}' not one of {list(f.choices or [])}")
        return str(v)
    if f.kind == "color":
        if not isinstance(v, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", v):
            raise ValueError(f"{f.key}: expected #RRGGBB")
        return v.upper()
    if f.kind == "path":
        if not isinstance(v, str) or not v.strip():
            raise ValueError(f"{f.key}: empty path")
        return v
    if f.kind == "multi":
        if not isinstance(v, (list, tuple)) or any(x not in (f.choices or []) for x in v):
            raise ValueError(f"{f.key}: invalid selection")
        return list(v)
    return v


class Settings:
    def __init__(self, values: Optional[Dict[str, Any]] = None):
        self.values: Dict[str, Any] = {f.key: (list(f.default) if isinstance(f.default, list) else f.default)
                                       for f in SCHEMA}
        self.window_state: Dict[str, Any] = {}
        if values:
            self.update(values)

    def get(self, key: str) -> Any:
        return self.values[key]

    def set(self, key: str, value: Any) -> None:
        if key not in BY_KEY:
            raise KeyError(key)
        self.values[key] = _coerce(BY_KEY[key], value)

    def update(self, d: Dict[str, Any]) -> List[str]:
        """Apply many values; invalid/unknown ones are skipped and reported."""
        errors = []
        for k, v in d.items():
            try:
                self.set(k, v)
            except (KeyError, ValueError) as e:
                errors.append(str(e))
        return errors

    def apply_preset(self, name: str) -> None:
        self.update(PRESETS[name])
        self.values["tracking.preset"] = name

    def reset(self) -> None:
        self.__init__()

    def to_dict(self) -> Dict[str, Any]:
        return {"values": dict(self.values), "window_state": self.window_state}

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "Settings":
        s = cls()
        s.errors = []  # type: ignore[attr-defined]
        for p in (Path(__file__).resolve().parents[1] / "config" / "default.json", path or user_config_path()):
            try:
                data = json.loads(Path(p).read_text(encoding="utf-8"))
                s.errors += s.update(data.get("values", {}))  # type: ignore[attr-defined]
                s.window_state.update(data.get("window_state", {}))
            except FileNotFoundError:
                continue
            except (json.JSONDecodeError, OSError) as e:
                s.errors.append(f"{p}: {e}")  # type: ignore[attr-defined]
        return s

    def save(self, path: Optional[Path] = None) -> Path:
        p = Path(path or user_config_path())
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        os.replace(tmp, p)
        return p
