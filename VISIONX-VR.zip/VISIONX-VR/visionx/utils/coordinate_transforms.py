"""Explicit coordinate transforms. All coordinates use the "pixel index" convention
(centre of the top-left pixel is (0, 0)), matching cv2 drawing and cv2.resize sampling.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np

Pt = Tuple[float, float]


@dataclass(frozen=True)
class ViewTransform:
    """Source image -> aspect-preserving letterboxed (optionally mirrored, zoomed) view."""
    src_w: int
    src_h: int
    dst_w: int
    dst_h: int
    mirror: bool
    scale: float
    off_x: float
    off_y: float

    @classmethod
    def fit(cls, src_w: int, src_h: int, dst_w: int, dst_h: int, mirror: bool = False,
            zoom: float = 1.0) -> "ViewTransform":
        src_w, src_h = max(1, int(src_w)), max(1, int(src_h))
        dst_w, dst_h = max(1, int(dst_w)), max(1, int(dst_h))
        s = min(dst_w / src_w, dst_h / src_h) * max(zoom, 1e-3)
        return cls(src_w, src_h, dst_w, dst_h, mirror, s,
                   (dst_w - src_w * s) / 2.0, (dst_h - src_h * s) / 2.0)

    def to_view(self, x: float, y: float) -> Pt:
        if self.mirror:
            x = (self.src_w - 1) - x
        return ((x + 0.5) * self.scale - 0.5 + self.off_x,
                (y + 0.5) * self.scale - 0.5 + self.off_y)

    def to_source(self, vx: float, vy: float) -> Pt:
        x = (vx - self.off_x + 0.5) / self.scale - 0.5
        y = (vy - self.off_y + 0.5) / self.scale - 0.5
        if self.mirror:
            x = (self.src_w - 1) - x
        return (x, y)

    def to_view_arr(self, pts: np.ndarray) -> np.ndarray:
        """Vectorised to_view for an (N, 2) array."""
        a = np.asarray(pts, np.float64).copy()
        if self.mirror:
            a[:, 0] = (self.src_w - 1) - a[:, 0]
        a = (a + 0.5) * self.scale - 0.5
        a[:, 0] += self.off_x
        a[:, 1] += self.off_y
        return a

    def length(self, px: float) -> float:
        return px * self.scale

    def render(self, src: np.ndarray, bg: Tuple[int, int, int] = (31, 17, 8)) -> np.ndarray:
        """Warp `src` into the view with exactly the mapping used by to_view()."""
        img = cv2.flip(src, 1) if self.mirror else src
        if img.ndim == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        m = np.array([[self.scale, 0.0, self.off_x + 0.5 * self.scale - 0.5],
                      [0.0, self.scale, self.off_y + 0.5 * self.scale - 0.5]], dtype=np.float64)
        interp = cv2.INTER_AREA if self.scale < 1 else cv2.INTER_CUBIC
        return cv2.warpAffine(img, m, (self.dst_w, self.dst_h), flags=interp,
                              borderMode=cv2.BORDER_CONSTANT, borderValue=bg)


def crop_to_frame(pt: Pt, box: Tuple[int, int, int, int]) -> Pt:
    return (pt[0] + box[0], pt[1] + box[1])


def frame_to_crop(pt: Pt, box: Tuple[int, int, int, int]) -> Pt:
    return (pt[0] - box[0], pt[1] - box[1])


def _axes(a: Pt, b: Pt):
    ax, ay = b[0] - a[0], b[1] - a[1]
    L = float(np.hypot(ax, ay))
    if L < 1e-6:
        return None
    ex = (ax / L, ay / L)
    ey = (-ex[1], ex[0])  # points "down" when ex points right
    return L, ex, ey


def rel_from_corners(pt: Pt, corner_a: Pt, corner_b: Pt) -> Optional[Pt]:
    """Frame px -> eye-relative (u, v) in units of eye width."""
    ax = _axes(corner_a, corner_b)
    if ax is None:
        return None
    L, ex, ey = ax
    dx, dy = pt[0] - corner_a[0], pt[1] - corner_a[1]
    return ((dx * ex[0] + dy * ex[1]) / L, (dx * ey[0] + dy * ey[1]) / L)


def rel_to_frame(uv: Pt, corner_a: Pt, corner_b: Pt) -> Optional[Pt]:
    ax = _axes(corner_a, corner_b)
    if ax is None:
        return None
    L, ex, ey = ax
    return (corner_a[0] + L * (uv[0] * ex[0] + uv[1] * ey[0]),
            corner_a[1] + L * (uv[0] * ex[1] + uv[1] * ey[1]))
