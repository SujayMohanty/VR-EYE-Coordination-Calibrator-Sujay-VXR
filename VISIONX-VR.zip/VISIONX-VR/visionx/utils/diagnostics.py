from __future__ import annotations

import importlib.metadata as md
import platform
import sys
from typing import Any, Dict

from visionx.tracking.landmark_tracker import DEFAULT_MODEL

PACKAGES = ["numpy", "opencv-python", "mediapipe", "PySide6", "scipy", "pyopenxr"]


def collect_environment() -> Dict[str, Any]:
    vers = {}
    for p in PACKAGES:
        try:
            vers[p] = md.version(p)
        except md.PackageNotFoundError:
            vers[p] = None
    return {"os": platform.platform(), "python": sys.version.split()[0], "packages": vers,
            "face_model_path": str(DEFAULT_MODEL), "face_model_present": DEFAULT_MODEL.is_file()}
