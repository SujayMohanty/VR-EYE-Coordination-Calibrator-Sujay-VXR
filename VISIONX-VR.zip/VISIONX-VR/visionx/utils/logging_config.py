from __future__ import annotations

import logging
import logging.handlers
import time
from collections import deque
from pathlib import Path
from typing import Deque, Optional, Tuple


class RateLimitFilter(logging.Filter):
    """Suppress identical messages repeating within `period` seconds (keeps logs readable when a
    condition persists, e.g. 'no face detected' on every frame). Suppressed counts are reported."""

    def __init__(self, period: float = 5.0):
        super().__init__()
        self.period = period
        self.seen = {}

    def filter(self, record):
        key = (record.name, record.levelno, str(record.msg))
        now = time.monotonic()
        last, n = self.seen.get(key, (-1e9, 0))
        if now - last < self.period:
            self.seen[key] = (last, n + 1)
            return False
        if n:
            record.msg = f"{record.msg} (+{n} similar suppressed)"
        self.seen[key] = (now, 0)
        return True


class RecentErrors(logging.Handler):
    def __init__(self, maxlen=50):
        super().__init__(level=logging.WARNING)
        self.items: Deque[Tuple[float, str, str]] = deque(maxlen=maxlen)

    def emit(self, record):
        self.items.append((record.created, record.levelname, record.getMessage()))


RECENT = RecentErrors()


def setup_logging(log_dir: Optional[str] = None, level=logging.INFO):
    root = logging.getLogger("visionx")
    root.setLevel(level)
    if getattr(root, "_vx_configured", False):
        return RECENT
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    sh.addFilter(RateLimitFilter())
    root.addHandler(sh)
    root.addHandler(RECENT)
    if log_dir:
        try:
            Path(log_dir).mkdir(parents=True, exist_ok=True)
            fh = logging.handlers.RotatingFileHandler(Path(log_dir) / "visionx.log", maxBytes=2_000_000, backupCount=3,
                                                      encoding="utf-8")
            fh.setFormatter(fmt)
            fh.addFilter(RateLimitFilter())
            root.addHandler(fh)
        except OSError:
            root.warning("could not open log file in %s", log_dir)
    root._vx_configured = True  # type: ignore[attr-defined]
    return RECENT
