from __future__ import annotations

from collections import deque
from typing import Deque, List, Optional, Tuple

import numpy as np

Pt = Tuple[float, float]


class TrailBuffer:
    """Short rendering history only (bounded). Full-session data lives in the recorder."""

    def __init__(self, maxlen: int = 40, gap_s: float = 0.25):
        self.gap_s = gap_s
        self.q: Deque[Optional[Tuple[float, float, float]]] = deque(maxlen=maxlen)

    def set_maxlen(self, n: int):
        if n != self.q.maxlen:
            self.q = deque(self.q, maxlen=n)

    def clear(self):
        self.q.clear()

    def push(self, ts: float, pt: Optional[Pt]):
        last = next((x for x in reversed(self.q) if x is not None), None)
        if pt is None:
            if self.q and self.q[-1] is not None:
                self.q.append(None)               # visual break on invalid sample
            return
        if last is not None and self.q and self.q[-1] is not None and ts - last[0] > self.gap_s:
            self.q.append(None)
        self.q.append((ts, pt[0], pt[1]))

    def polylines(self) -> List[np.ndarray]:
        lines, cur = [], []
        for x in self.q:
            if x is None:
                if len(cur) > 1:
                    lines.append(np.array(cur, np.float64))
                cur = []
            else:
                cur.append((x[1], x[2]))
        if len(cur) > 1:
            lines.append(np.array(cur, np.float64))
        return lines


class TrailSet:
    """Per-eye trails in two spaces: frame px (main view) and eye-relative (u, v) (eye panels)."""

    def __init__(self, maxlen=40):
        self.px = {s: TrailBuffer(maxlen) for s in ("left", "right")}
        self.uv = {s: TrailBuffer(maxlen) for s in ("left", "right")}

    def set_maxlen(self, n):
        for d in (self.px, self.uv):
            for t in d.values():
                t.set_maxlen(n)

    def clear(self, side: Optional[str] = None):
        for s in ([side] if side else ["left", "right"]):
            self.px[s].clear()
            self.uv[s].clear()

    def update(self, rec):
        for s in ("left", "right"):
            e = rec.eye(s)
            ok = e.valid and e.pupil_xy is not None
            self.px[s].push(rec.capture_ts, e.pupil_xy if ok else None)
            self.uv[s].push(rec.capture_ts, e.pupil_rel if ok else None)
