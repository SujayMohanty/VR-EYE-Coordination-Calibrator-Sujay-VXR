"""The ONE renderer for tracking graphics. The main camera panel, the eye panels and the annotated
captures all draw through here from the same TrackingRecord, so the reticle position, the numeric
coordinates and the saved image can never disagree."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from visionx.models.tracking_models import EyeMeasurement, TrackingRecord
from visionx.render.trails import TrailSet
from visionx.tracking.base_provider import FrameBundle
from visionx.tracking.eye_region import SIDES
from visionx.utils.coordinate_transforms import ViewTransform, rel_to_frame

NAVY_BGR = (31, 17, 8)
MUTED_BGR = (181, 152, 129)       # #8198B5
STATE_COLORS = {                    # BGR
    "TRACKING": (255, 183, 0), "LOW CONFIDENCE": (0, 190, 255), "LOST": (70, 70, 235),
    "NO FACE": (70, 70, 235), "CALIBRATING": (230, 120, 190), "PAUSED": (170, 170, 170),
    "REPLAY": (200, 200, 60), "NATIVE VR": (240, 100, 240), "STOPPED": (120, 120, 120)}
FONT = cv2.FONT_HERSHEY_SIMPLEX


def hexbgr(h: str) -> Tuple[int, int, int]:
    h = h.lstrip("#")
    return (int(h[4:6], 16), int(h[2:4], 16), int(h[0:2], 16))


@dataclass
class OverlayOptions:
    face_box: bool = True
    landmarks: bool = False
    eye_outline: bool = True
    reticle: bool = True
    iris: bool = True
    trail: bool = True
    gaze: bool = True
    coords: bool = True
    head_pose: bool = False
    trail_left: bool = True
    trail_right: bool = True
    reticle_size: float = 1.0
    reticle_brightness: float = 1.0
    primary: str = "#00B7FF"
    secondary: str = "#40E7FF"
    diagnostic: bool = False
    mirror: bool = False

    @classmethod
    def from_settings(cls, s) -> "OverlayOptions":
        return cls(**{k: s.get(f"overlay.{k2}") for k, k2 in
                      [("face_box", "face_box"), ("landmarks", "landmarks"), ("eye_outline", "eye_outline"),
                       ("reticle", "reticle"), ("iris", "iris"), ("trail", "trail"), ("gaze", "gaze"),
                       ("coords", "coords"), ("head_pose", "head_pose"), ("trail_left", "trail_left"),
                       ("trail_right", "trail_right"), ("reticle_size", "reticle_size"),
                       ("reticle_brightness", "reticle_brightness"), ("primary", "color_primary"),
                       ("secondary", "color_secondary"), ("diagnostic", "diagnostic")]},
                   mirror=s.get("camera.mirror"))


# ------------------------------------------------------------------ primitives
def _k(c, k):
    return (int(c[0] * k), int(c[1] * k), int(c[2] * k))


def put_text(img, text, org, scale=0.45, color=(255, 255, 255), th=1, bg=True):
    x, y = int(org[0]), int(org[1])
    if bg:                                           # dark translucent pill keeps labels readable on any image
        (tw, tht), base = cv2.getTextSize(text, FONT, scale, th)
        x0, y0, x1, y1 = max(0, x - 3), max(0, y - tht - 3), min(img.shape[1], x + tw + 3), min(img.shape[0], y + base + 2)
        if x1 > x0 and y1 > y0:
            roi = img[y0:y1, x0:x1]
            roi[:] = (roi * 0.35 + np.array(NAVY_BGR) * 0.65).astype(np.uint8)
    cv2.putText(img, text, (x, y), FONT, scale, color, th, cv2.LINE_AA)


def _p(pt):  # subpixel (shift=4)
    return (int(round(pt[0] * 16)), int(round(pt[1] * 16)))


def _circle(img, c, r, color, th=1, fill=False):
    cv2.circle(img, _p(c), int(round(r * 16)), color, -1 if fill else th, cv2.LINE_AA, 4)


def _line(img, a, b, color, th=1):
    cv2.line(img, _p(a), _p(b), color, th, cv2.LINE_AA, 4)


def _glow(img, c, r, color, strength=0.8):
    R = int(r * 2.6) + 4
    x, y = int(c[0]), int(c[1])
    x0, y0, x1, y1 = max(0, x - R), max(0, y - R), min(img.shape[1], x + R + 1), min(img.shape[0], y + R + 1)
    if x1 <= x0 or y1 <= y0:
        return
    roi = img[y0:y1, x0:x1]
    layer = np.zeros_like(roi)
    cv2.circle(layer, (int(round(c[0] - x0)), int(round(c[1] - y0))), int(r * 1.1), color,
               max(2, int(r * 0.5)), cv2.LINE_AA)
    layer = cv2.GaussianBlur(layer, (0, 0), r * 0.45 + 1)
    cv2.add(roi, (layer * strength).astype(np.uint8), dst=roi)


def draw_reticle(img, c, r, opts: OverlayOptions, quality=1.0, label: Optional[str] = None,
                 vec: Optional[Tuple[float, float]] = None, hollow=False):
    """Electric-blue tracking reticle centred EXACTLY at c (view px)."""
    k = opts.reticle_brightness * (0.55 if hollow else 1.0)
    prim, sec = _k(hexbgr(opts.primary), k), _k(hexbgr(opts.secondary), k)
    r = max(5.0, r)
    if not hollow:
        _glow(img, c, r, prim, 0.7 * opts.reticle_brightness)
    _circle(img, c, r, prim, 2 if not hollow else 1)
    _circle(img, c, r * 1.6, _k(prim, 0.65), 1)
    for ang in (0, 90, 180, 270):                      # crosshair with open centre
        a = math.radians(ang)
        d = (math.cos(a), math.sin(a))
        _line(img, (c[0] + d[0] * r * 0.3, c[1] + d[1] * r * 0.3), (c[0] + d[0] * r * 1.3, c[1] + d[1] * r * 1.3), sec, 1)
    for i in range(12):                                # radial guide marks
        a = math.radians(i * 30 + 15)
        d = (math.cos(a), math.sin(a))
        _line(img, (c[0] + d[0] * r * 1.6, c[1] + d[1] * r * 1.6), (c[0] + d[0] * r * 1.85, c[1] + d[1] * r * 1.85),
              _k(prim, 0.8), 1)
    if not hollow:
        _circle(img, c, max(1.8, r * 0.16), sec, fill=True)
        q = max(0.0, min(1.0, quality))               # confidence arc
        if q > 0.01:
            cv2.ellipse(img, (int(round(c[0])), int(round(c[1]))), (int(r * 1.6) + 3, int(r * 1.6) + 3), -90, 0,
                        360 * q, sec, 2, cv2.LINE_AA)
    if vec is not None and not hollow:
        n = math.hypot(*vec)
        if n > 1e-6:
            L = min(3.0 * r, max(1.2 * r, n))
            e = (c[0] + vec[0] / n * L, c[1] + vec[1] / n * L)
            cv2.arrowedLine(img, _p(c), _p(e), sec, 2, cv2.LINE_AA, 4, 0.3)
    if label:
        put_text(img, label, (c[0] + r * 1.9, c[1] - r * 1.5), 0.4, sec)


def _eye_width_px(e: EyeMeasurement) -> float:
    if e.corner_a and e.corner_b:
        return math.hypot(e.corner_b[0] - e.corner_a[0], e.corner_b[1] - e.corner_a[1])
    return 40.0


def state_label(rec: Optional[TrackingRecord], override: Optional[str] = None) -> str:
    if override:
        return override
    if rec is None:
        return "STOPPED"
    return {"tracking": "TRACKING", "low_confidence": "LOW CONFIDENCE", "lost": "LOST",
            "no_face": "NO FACE"}.get(rec.state, "LOST")


def draw_status_chip(img, text, pos=(10, 10)):
    col = STATE_COLORS.get(text, MUTED_BGR)
    (tw, th), _ = cv2.getTextSize(text, FONT, 0.5, 1)
    x, y = pos
    overlay = img.copy()
    cv2.rectangle(overlay, (x, y), (x + tw + 28, y + th + 12), NAVY_BGR, -1)
    cv2.addWeighted(overlay, 0.75, img, 0.25, 0, img)
    cv2.circle(img, (x + 12, y + (th + 12) // 2), 4, col, -1, cv2.LINE_AA)
    cv2.putText(img, text, (x + 22, y + th + 5), FONT, 0.5, col, 1, cv2.LINE_AA)


def _reticle_radius(e: EyeMeasurement, scale: float, opts: OverlayOptions) -> float:
    base = (e.iris_radius_px or _eye_width_px(e) * 0.14) * 0.5 * scale
    return max(6.0, min(60.0, base)) * opts.reticle_size


def coord_label(e: EyeMeasurement) -> str:
    """Numeric text. Uses the SAME accepted coordinate the reticle is drawn at."""
    x, y = e.pupil_xy
    return f"{'L' if e.side == 'left' else 'R'} ({x:.1f}, {y:.1f})"


def _draw_eye_marks(img, e: EyeMeasurement, mp, scale, opts, rec_label_pos, mirror):
    """Reticle / low-confidence / lost marks for one eye. mp maps source px -> view px."""
    side = "L" if e.side == "left" else "R"
    if e.valid and e.pupil_xy is not None and opts.reticle:
        vec = None
        if e.velocity_uv and e.speed_uv and e.direction not in ("unknown", "stable"):
            vx, vy = e.velocity_uv
            vec = ((-vx if mirror else vx) * _eye_width_px(e) * scale * 0.25, vy * _eye_width_px(e) * scale * 0.25)
        lab = coord_label(e) + (" [iris]" if e.provenance == "iris_fallback" else "") if opts.coords else None
        draw_reticle(img, mp(e.pupil_xy), _reticle_radius(e, scale, opts), opts, e.quality, lab, vec)
    elif e.status == "low_confidence" and e.candidate_xy is not None and opts.reticle:
        c = mp(e.candidate_xy)
        draw_reticle(img, c, _reticle_radius(e, scale, opts) * 0.8, opts, 0.0, None, None, hollow=True)
        put_text(img, f"{side} LOW {e.quality:.2f} ({e.reason or ''})", (c[0] + 12, c[1] + 22), 0.38, (0, 190, 255))
    elif not e.valid and rec_label_pos is not None:
        put_text(img, f"{side}: LOST ({e.reason or 'n/a'})", rec_label_pos, 0.4, STATE_COLORS["LOST"])
    if opts.diagnostic and e.candidate_xy is not None:
        cv2.drawMarker(img, tuple(int(round(v)) for v in mp(e.candidate_xy)), (0, 140, 255), cv2.MARKER_TILTED_CROSS, 9, 1)


def draw_trails(img, polylines_view: List[np.ndarray], color):
    for pl in polylines_view:
        n = len(pl)
        for i in range(1, n):
            f = i / n
            cv2.line(img, tuple(int(round(v)) for v in pl[i - 1]), tuple(int(round(v)) for v in pl[i]),
                     _k(color, 0.25 + 0.75 * f), 1 if f < 0.6 else 2, cv2.LINE_AA)


def _gaze_inset(img, rec: TrackingRecord):
    h, w = img.shape[:2]
    iw, ih = 128, 72
    x0, y0 = w - iw - 10, h - ih - 10
    if x0 < 0 or y0 < 0:
        return
    sub = img[y0:y0 + ih, x0:x0 + iw]
    sub[:] = (sub * 0.35 + np.array(NAVY_BGR) * 0.65).astype(np.uint8)
    cv2.rectangle(img, (x0, y0), (x0 + iw, y0 + ih), MUTED_BGR, 1)
    g = rec.gaze
    if g.valid and g.norm_xy:
        gx = min(max(g.norm_xy[0], 0.0), 1.0)
        gy = min(max(g.norm_xy[1], 0.0), 1.0)
        cv2.circle(img, (int(x0 + gx * iw), int(y0 + gy * ih)), 4, (255, 231, 64), -1, cv2.LINE_AA)
        put_text(img, "gaze (calibrated)", (x0 + 4, y0 - 4), 0.35, MUTED_BGR)
    else:
        put_text(img, "NOT CALIBRATED" if g.status == "not_calibrated" else f"GAZE {g.status.upper()}",
                 (x0 + 8, y0 + ih // 2 + 4), 0.38, MUTED_BGR)


def draw_main_overlay(canvas, bundle: FrameBundle, vt: ViewTransform, opts: OverlayOptions,
                      trails: Optional[TrailSet] = None, status: Optional[str] = None):
    rec = bundle.record
    mp = lambda p: vt.to_view(p[0], p[1])
    if rec.face_box and opts.face_box:
        a, b = mp(rec.face_box[:2]), mp(rec.face_box[2:])
        cv2.rectangle(canvas, (int(min(a[0], b[0])), int(min(a[1], b[1]))), (int(max(a[0], b[0])), int(max(a[1], b[1]))),
                      _k(MUTED_BGR, 0.9), 1, cv2.LINE_AA)
    if bundle.landmarks is not None and opts.landmarks:
        pts = vt.to_view_arr(bundle.landmarks)
        for x, y in pts:
            if 0 <= x < canvas.shape[1] and 0 <= y < canvas.shape[0]:
                canvas[int(y), int(x)] = (200, 200, 200)
    for side in ("left", "right"):
        e = rec.eye(side)
        if bundle.landmarks is not None and opts.eye_outline:
            poly = vt.to_view_arr(bundle.landmarks[SIDES[side]["contour"]])
            cv2.polylines(canvas, [np.round(poly).astype(np.int32)], True, _k(hexbgr(opts.primary), 0.6), 1, cv2.LINE_AA)
        if opts.iris and e.iris_xy and e.iris_radius_px:
            _circle(canvas, mp(e.iris_xy), e.iris_radius_px * vt.scale, _k(MUTED_BGR, 1.0), 1)
        if opts.trail and trails is not None and getattr(opts, f"trail_{side}"):
            draw_trails(canvas, [vt.to_view_arr(pl) for pl in trails.px[side].polylines()], hexbgr(opts.primary))
        lp = None
        if e.eye_box:
            q = mp((e.eye_box[0], e.eye_box[1]))
            lp = (min(max(q[0], 4), canvas.shape[1] - 120), max(q[1] - 6, 14))
        _draw_eye_marks(canvas, e, mp, vt.scale, opts, lp, vt.mirror)
    if opts.head_pose and rec.head_pose and bundle.landmarks is not None:
        hp = rec.head_pose
        yaw, pitch = math.radians(hp["yaw"]), math.radians(hp["pitch"])
        d = (math.sin(yaw) * math.cos(pitch), -math.sin(pitch))
        nose = mp(bundle.landmarks[1])
        end = (nose[0] + d[0] * 90, nose[1] + d[1] * 90)
        cv2.arrowedLine(canvas, tuple(int(v) for v in nose), tuple(int(v) for v in end), (80, 220, 120), 2, cv2.LINE_AA, 0, 0.25)
        put_text(canvas, f"yaw {hp['yaw']:+.0f} pitch {hp['pitch']:+.0f} roll {hp['roll']:+.0f} (approx)",
                 (10, canvas.shape[0] - 12), 0.4, (80, 220, 120))
    if opts.gaze:
        _gaze_inset(canvas, rec)
    draw_status_chip(canvas, state_label(rec, status))


def placeholder(w: int, h: int, text: str) -> np.ndarray:
    img = np.zeros((max(h, 8), max(w, 8), 3), np.uint8)
    img[:] = NAVY_BGR
    (tw, th), _ = cv2.getTextSize(text, FONT, 0.5, 1)
    cv2.putText(img, text, (max(4, (w - tw) // 2), h // 2), FONT, 0.5, MUTED_BGR, 1, cv2.LINE_AA)
    return img


def render_main(bundle: Optional[FrameBundle], size: Tuple[int, int], opts: OverlayOptions,
                trails: Optional[TrailSet] = None, status: Optional[str] = None, message: str = "No camera frame") -> np.ndarray:
    w, h = size
    if bundle is None or bundle.frame is None:
        img = placeholder(w, h, message)
        if status:
            draw_status_chip(img, status)
        return img
    fh, fw = bundle.frame.shape[:2]
    vt = ViewTransform.fit(fw, fh, w, h, opts.mirror)
    canvas = vt.render(bundle.frame)
    draw_main_overlay(canvas, bundle, vt, opts, trails, status)
    return canvas


def render_annotated_frame(bundle: FrameBundle, opts: OverlayOptions, trails: Optional[TrailSet] = None) -> np.ndarray:
    """Full-resolution annotated frame in SOURCE orientation (never mirrored)."""
    fh, fw = bundle.frame.shape[:2]
    o = OverlayOptions(**{**opts.__dict__, "mirror": False})
    vt = ViewTransform.fit(fw, fh, fw, fh, False)
    canvas = bundle.frame.copy()
    draw_main_overlay(canvas, bundle, vt, o, trails, None)
    return canvas


# ------------------------------------------------------------------ eye panel
VIEW_MODES = ("raw", "landmarks", "overlay", "processed", "side_by_side")


def render_eye(bundle: Optional[FrameBundle], side: str, size: Tuple[int, int], opts: OverlayOptions,
               mode: str = "overlay", zoom: float = 1.0, trails: Optional[TrailSet] = None,
               frozen: bool = False) -> np.ndarray:
    w, h = size
    tag = "L EYE" if side == "left" else "R EYE"
    if bundle is None or bundle.frame is None or bundle.record.eye(side).eye_box is None:
        why = "no face" if bundle is not None and not bundle.record.face_detected else "no eye region"
        return placeholder(w, h, f"{tag}: {why.upper()}")
    if mode == "side_by_side":
        a = render_eye(bundle, side, (w // 2, h), opts, "overlay", zoom, trails, frozen)
        b = render_eye(bundle, side, (w - w // 2, h), opts, "processed", zoom, trails, frozen)
        return np.hstack([a, b])
    rec, e = bundle.record, bundle.record.eye(side)
    x0, y0, x1, y1 = e.eye_box
    crop = bundle.frame[y0:y1, x0:x1]
    ch, cw = crop.shape[:2]
    vt = ViewTransform.fit(cw, ch, w, h, opts.mirror, zoom)
    mp = lambda p: vt.to_view(p[0] - x0, p[1] - y0)
    if mode == "processed":
        pr = bundle.processed.get(side)
        if pr is None or pr[0].shape[:2] != crop.shape[:2]:
            img = placeholder(w, h, f"{tag}: PROCESSED VIEW UNAVAILABLE")
        else:
            img = vt.render(pr[0])
            put_text(img, "PROCESSED (derived) - not the camera image", (8, h - 10), 0.38, MUTED_BGR)
            if e.valid and e.pupil_xy:
                _circle(img, mp(e.pupil_xy), 3, (255, 255, 255), 1)
        put_text(img, tag, (8, 18), 0.5, (235, 235, 235))
        return img
    img = vt.render(crop)
    if (mode == "landmarks" or (mode == "overlay" and opts.eye_outline)) and bundle.landmarks is not None:
        poly = vt.to_view_arr(bundle.landmarks[SIDES[side]["contour"]])
        cv2.polylines(img, [np.round(poly).astype(np.int32)], True, _k(hexbgr(opts.primary), 0.7), 1, cv2.LINE_AA)
        if e.iris_xy and e.iris_radius_px:
            _circle(img, mp(e.iris_xy), e.iris_radius_px * vt.scale, MUTED_BGR, 1)
            _circle(img, mp(e.iris_xy), 2, MUTED_BGR, fill=True)
    if mode == "overlay":
        if opts.trail and trails is not None and getattr(opts, f"trail_{side}") and e.corner_a and e.corner_b:
            pls = []
            for pl in trails.uv[side].polylines():
                pts = [rel_to_frame((u, v), e.corner_a, e.corner_b) for u, v in pl]
                pls.append(np.array([[mp(p)[0], mp(p)[1]] for p in pts]))
            draw_trails(img, pls, hexbgr(opts.primary))
        _draw_eye_marks(img, e, mp, vt.scale, opts, (8, h - 30), vt.mirror)
    put_text(img, tag + ("  [FROZEN VIEW]" if frozen else ""), (8, 18), 0.5, (235, 235, 235))
    op = f"open {e.openness:.2f}" if e.openness is not None else "open n/a"
    put_text(img, f"{e.status.upper()}  q={e.quality:.2f}  {op}", (8, h - 10), 0.4, STATE_COLORS.get(
        {"tracking": "TRACKING", "low_confidence": "LOW CONFIDENCE"}.get(e.status, "LOST"), MUTED_BGR))
    return img
