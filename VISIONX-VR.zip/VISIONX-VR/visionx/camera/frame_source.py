"""Frame sources. A source only opens/reads/releases; threading lives in CameraCapture."""
from __future__ import annotations

import sys
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple

import cv2
import numpy as np


class FrameSource(ABC):
    is_file = False
    name = "source"

    @abstractmethod
    def open(self) -> bool: ...

    @abstractmethod
    def read(self) -> Tuple[bool, Optional[np.ndarray]]: ...

    @abstractmethod
    def release(self) -> None: ...

    def properties(self) -> Dict[str, Any]:
        return {}


class CvCameraSource(FrameSource):
    def __init__(self, index=0, width=1280, height=720, fps=30, brightness=-1.0):
        self.index, self.width, self.height, self.fps, self.brightness = index, width, height, fps, brightness
        self.name = f"Camera {index}"
        self.cap: Optional[cv2.VideoCapture] = None
        self.backend = ""
        self.applied: Dict[str, bool] = {}

    def open(self) -> bool:
        backends = [(cv2.CAP_DSHOW, "DirectShow"), (cv2.CAP_ANY, "default")] if sys.platform.startswith("win") \
            else [(cv2.CAP_ANY, "default")]
        for api, label in backends:
            cap = cv2.VideoCapture(self.index, api)
            if cap.isOpened():
                self.cap, self.backend = cap, label
                self.applied = {
                    "width": cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width),
                    "height": cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height),
                    "fps": cap.set(cv2.CAP_PROP_FPS, self.fps)}
                if self.brightness >= 0:
                    self.applied["brightness"] = cap.set(cv2.CAP_PROP_BRIGHTNESS, self.brightness)
                return True
            cap.release()
        return False

    def read(self):
        if self.cap is None:
            return False, None
        return self.cap.read()

    def release(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None

    def properties(self):
        if self.cap is None:
            return {}
        return {"width": int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)), "height": int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                "driver_fps": self.cap.get(cv2.CAP_PROP_FPS), "backend": self.backend, "applied": self.applied}


class VideoFileSource(FrameSource):
    """Development/replay source (`--source clip.mp4`): paced at the file's frame rate and looped."""
    is_file = True

    def __init__(self, path: str):
        self.path, self.name = path, path
        self.cap: Optional[cv2.VideoCapture] = None
        self._next = 0.0
        self._dt = 1 / 30

    def open(self):
        self.cap = cv2.VideoCapture(self.path)
        if not self.cap.isOpened():
            return False
        fps = self.cap.get(cv2.CAP_PROP_FPS)
        self._dt = 1.0 / fps if fps and fps > 1 else 1 / 30
        self._next = time.monotonic()
        return True

    def read(self):
        if self.cap is None:
            return False, None
        now = time.monotonic()
        if now < self._next:
            time.sleep(self._next - now)
        self._next = max(self._next + self._dt, time.monotonic() - self._dt)
        ok, fr = self.cap.read()
        if not ok:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, fr = self.cap.read()
        return ok, fr

    def release(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None

    def properties(self):
        if self.cap is None:
            return {}
        return {"width": int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)), "height": int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                "driver_fps": 1 / self._dt, "backend": "file"}
