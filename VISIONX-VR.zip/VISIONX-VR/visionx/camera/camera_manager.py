"""Single-owner camera acquisition thread with a latest-frame slot (no unbounded backlog),
failure recovery/reconnect and honest state reporting."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

import cv2
import numpy as np

from visionx.camera.frame_source import CvCameraSource, FrameSource

log = logging.getLogger("visionx.camera")


@dataclass
class Packet:
    frame_id: int
    ts: float            # time.monotonic() at grab
    frame: np.ndarray


class CameraCapture:
    STATES = ("closed", "opening", "streaming", "reconnecting", "error")

    def __init__(self, factory: Callable[[], FrameSource], max_failures: int = 30, retry_s: float = 1.0,
                 on_state: Optional[Callable[[str, str], None]] = None):
        self.factory, self.max_failures, self.retry_s, self.on_state = factory, max_failures, retry_s, on_state
        self._cond = threading.Condition()
        self._latest: Optional[Packet] = None
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.state, self.detail = "closed", ""
        self.frame_id = 0
        self.fps = 0.0
        self.last_frame_time: Optional[float] = None
        self.props: Dict[str, Any] = {}
        self.name = ""
        self.reconnects = 0

    def _set(self, state: str, detail: str = ""):
        if state != self.state or detail != self.detail:
            self.state, self.detail = state, detail
            log.info("camera state -> %s %s", state, detail)
            if self.on_state:
                try:
                    self.on_state(state, detail)
                except Exception:
                    log.exception("on_state callback failed")

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="camera-capture", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 3.0):
        self._stop.set()
        with self._cond:
            self._cond.notify_all()
        if self._thread:
            self._thread.join(timeout)
            if self._thread.is_alive():
                log.warning("camera thread did not stop within %.1fs", timeout)
        self._thread = None
        self._set("closed")

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def get_latest(self, after_id: int = -1, timeout: float = 0.2) -> Optional[Packet]:
        with self._cond:
            if self._latest is None or self._latest.frame_id <= after_id:
                self._cond.wait(timeout)
            p = self._latest
            return p if p is not None and p.frame_id > after_id else None

    def info(self) -> Dict[str, Any]:
        return {"name": self.name, "state": self.state, "detail": self.detail, "capture_fps": self.fps,
                "last_frame_age_s": None if self.last_frame_time is None else time.monotonic() - self.last_frame_time,
                "reconnects": self.reconnects, **self.props}

    def _run(self):
        src: Optional[FrameSource] = None
        fails = 0
        last_t = None
        while not self._stop.is_set():
            if src is None:
                self._set("opening" if self.reconnects == 0 and self.state != "reconnecting" else "reconnecting")
                try:
                    src = self.factory()
                    ok = src.open()
                except Exception as e:  # driver errors must not kill the thread
                    log.exception("camera open raised")
                    ok, src = False, None
                    self._set("error", f"open failed: {e}")
                if not ok:
                    if src is not None:
                        src.release()
                    src = None
                    if self.state != "error":
                        self._set("error", "Camera unavailable: it may be in use by another application, "
                                           "disconnected, or blocked by Windows camera privacy settings.")
                    self._stop.wait(self.retry_s)
                    continue
                self.name, self.props, fails, last_t = src.name, src.properties(), 0, None
            try:
                ok, frame = src.read()
            except Exception:
                log.exception("camera read raised")
                ok, frame = False, None
            if not ok or frame is None:
                fails += 1
                if fails >= self.max_failures:
                    log.warning("camera: %d consecutive read failures, reconnecting", fails)
                    src.release()
                    src, self.reconnects = None, self.reconnects + 1
                    self._set("reconnecting", "frame reads failing; trying to reopen")
                else:
                    time.sleep(0.01)
                continue
            fails = 0
            now = time.monotonic()
            if last_t is not None and now > last_t:
                inst = 1.0 / (now - last_t)
                self.fps = inst if self.fps == 0 else 0.9 * self.fps + 0.1 * inst
            last_t = now
            self.last_frame_time = now
            self.frame_id += 1
            self._set("streaming")
            with self._cond:
                self._latest = Packet(self.frame_id, now, frame)
                self._cond.notify_all()
        if src is not None:
            src.release()


def probe_cameras(max_index: int = 5, skip: Tuple[int, ...] = ()) -> List[Dict[str, Any]]:
    """Quick probe of camera indices. Indices in `skip` (already owned by this app) are not opened."""
    out = []
    for i in range(max_index + 1):
        if i in skip:
            out.append({"index": i, "available": True, "in_use_by_app": True, "width": None, "height": None})
            continue
        src = CvCameraSource(i, 640, 480, 30)
        try:
            if src.open():
                ok, fr = src.read()
                p = src.properties()
                out.append({"index": i, "available": bool(ok), "in_use_by_app": False,
                            "width": p.get("width"), "height": p.get("height")})
            else:
                continue
        finally:
            src.release()
    return out
