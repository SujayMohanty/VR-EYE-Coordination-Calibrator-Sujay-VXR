"""Tracking pipeline thread: latest camera frame -> engine -> analysis -> callback.
Qt-free so it is unit-testable; the Qt SessionController bridges the callback to signals."""
from __future__ import annotations

import logging
import threading
import time
from typing import Callable, Optional

from visionx.analysis.analysis_engine import AnalysisEngine
from visionx.camera.camera_manager import CameraCapture
from visionx.tracking.base_provider import FrameBundle, TrackingProvider

log = logging.getLogger("visionx.pipeline")


class TrackingPipeline:
    def __init__(self, camera: CameraCapture, engine: TrackingProvider, analysis: AnalysisEngine,
                 on_bundle: Callable[[FrameBundle], None]):
        self.camera, self.engine, self.analysis, self.on_bundle = camera, engine, analysis, on_bundle
        self.lock = threading.RLock()          # guards engine/analysis reconfiguration
        self._stop = threading.Event()
        self._paused = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.frames_processed = self.frames_dropped = self.errors = 0
        self.proc_fps = 0.0
        self.latency_ms: Optional[float] = None
        self.last_error: Optional[str] = None

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="tracking-pipeline", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> bool:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout)
            alive = self._thread.is_alive()
            if not alive:
                self._thread = None
            return not alive
        return True

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def pause(self):
        self._paused.set()

    def resume(self):
        self._paused.clear()
        with self.lock:
            self.analysis.reset_tracking_state()

    @property
    def paused(self) -> bool:
        return self._paused.is_set()

    def _run(self):
        last, t_prev = -1, None
        while not self._stop.is_set():
            pkt = self.camera.get_latest(last, 0.2)
            if pkt is None:
                continue
            if last >= 0:
                self.frames_dropped += max(0, pkt.frame_id - last - 1)   # backlog is dropped, never queued
            last = pkt.frame_id
            if self._paused.is_set():
                continue
            try:
                with self.lock:
                    bundle = self.engine.process(pkt.frame, pkt.ts, pkt.frame_id)
                    self.analysis.update(bundle.record)
                self.frames_processed += 1
                now = time.monotonic()
                if t_prev is not None and now > t_prev:
                    inst = 1.0 / (now - t_prev)
                    self.proc_fps = inst if self.proc_fps == 0 else 0.9 * self.proc_fps + 0.1 * inst
                t_prev = now
                lat = bundle.record.latency_ms
                if lat is not None:
                    self.latency_ms = lat if self.latency_ms is None else 0.9 * self.latency_ms + 0.1 * lat
                self.on_bundle(bundle)
            except Exception as e:
                self.errors += 1
                self.last_error = f"{type(e).__name__}: {e}"
                log.exception("frame processing failed")
