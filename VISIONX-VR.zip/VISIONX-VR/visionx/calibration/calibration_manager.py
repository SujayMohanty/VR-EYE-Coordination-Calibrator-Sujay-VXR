"""Calibration workflow (state machine, UI-independent) + profile storage.
Modes: 'calibrate' collects samples per target then fits a model; 'validate' collects fresh
observations at independent targets and reports prediction error of an existing model."""
from __future__ import annotations

import json
import math
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from visionx.models.tracking_models import TrackingRecord
from visionx.tracking.gaze_estimator import GazeModel, eye_features, fit_gaze_model

GRIDS = {
    5: [(0.5, 0.5), (0.1, 0.1), (0.9, 0.1), (0.1, 0.9), (0.9, 0.9)],
    9: [(0.5, 0.5), (0.1, 0.1), (0.5, 0.1), (0.9, 0.1), (0.1, 0.5), (0.9, 0.5), (0.1, 0.9), (0.5, 0.9), (0.9, 0.9)],
}
GRIDS[13] = GRIDS[9] + [(0.3, 0.3), (0.7, 0.3), (0.3, 0.7), (0.7, 0.7)]
VALIDATION_TARGETS = [(0.5, 0.5), (0.25, 0.25), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75)]


class CalibrationManager:
    def __init__(self, n_points: int = 9, samples_per_point: int = 20, settle_ms: int = 700,
                 min_quality: float = 0.5, use_head_pose: bool = False, screen_size=(1920, 1080),
                 mode: str = "calibrate", model: Optional[GazeModel] = None, timeout_s: float = 12.0):
        if mode == "validate" and model is None:
            raise ValueError("validation needs a model")
        self.mode, self.model_in = mode, model
        self.targets: List[Tuple[float, float]] = list(VALIDATION_TARGETS if mode == "validate" else GRIDS[int(n_points)])
        self.need, self.settle_s, self.min_q = samples_per_point, settle_ms / 1000.0, min_quality
        self.use_head_pose = use_head_pose if model is None else model.use_head_pose
        self.screen_size, self.timeout_s = tuple(screen_size), timeout_s
        self.state = "idle"
        self.idx = 0
        self.skipped: List[int] = []
        self.samples: Dict[int, List[np.ndarray]] = {}
        self.rejected: Dict[int, int] = {}
        self.model: Optional[GazeModel] = None
        self.metrics: Dict[str, Any] = {}
        self.error: Optional[str] = None
        self._settle_until = 0.0
        self._target_start = 0.0
        self._paused_at = 0.0

    # ------------------------------------------------------------- controls
    def start(self, now: float):
        self.samples, self.rejected, self.skipped, self.idx = {}, {}, [], 0
        self.state, self.model, self.metrics, self.error = "running", None, {}, None
        self._begin_target(now)

    restart = start

    def _begin_target(self, now):
        self._settle_until = now + self.settle_s
        self._target_start = now
        self.samples.setdefault(self.idx, [])
        self.rejected.setdefault(self.idx, 0)

    def pause(self, now: float):
        if self.state == "running":
            self.state, self._paused_at = "paused", now

    def resume(self, now: float):
        if self.state == "paused":
            self.state = "running"
            self._settle_until = now + self.settle_s
            self._target_start += now - self._paused_at

    def cancel(self):
        if self.state in ("running", "paused"):
            self.state = "cancelled"

    def retry_current(self, now: float):
        if self.state in ("running", "paused"):
            self.samples[self.idx], self.rejected[self.idx] = [], 0
            self.state = "running"
            self._begin_target(now)

    def skip_current(self, now: float):
        if self.state == "running":
            self.skipped.append(self.idx)
            self._advance(now)

    # ------------------------------------------------------------- data flow
    @property
    def current_target(self) -> Optional[Tuple[float, float]]:
        return self.targets[self.idx] if self.state in ("running", "paused") and self.idx < len(self.targets) else None

    @property
    def needs_attention(self) -> bool:
        return self.state == "running" and len(self.samples.get(self.idx, [])) < self.need and \
            self._now_ref - self._target_start > self.timeout_s

    _now_ref = 0.0

    def feed(self, rec: TrackingRecord, now: float) -> None:
        self._now_ref = now
        if self.state != "running" or now < self._settle_until:
            return
        f = eye_features(rec, self.use_head_pose)
        ok = (f is not None and rec.state == "tracking"
              and all(e.quality >= self.min_q for e in (rec.left, rec.right) if e.valid))
        if not ok:
            self.rejected[self.idx] = self.rejected.get(self.idx, 0) + 1
            return
        self.samples[self.idx].append(f)
        if len(self.samples[self.idx]) >= self.need:
            self._advance(now)

    def _advance(self, now):
        self.idx += 1
        if self.idx >= len(self.targets):
            self._finish()
        else:
            self._begin_target(now)

    def _finish(self):
        used = [i for i in range(len(self.targets)) if i not in self.skipped and len(self.samples.get(i, [])) >= 5]
        try:
            if self.mode == "validate":
                self._validate(used)
            else:
                X = np.vstack([s for i in used for s in self.samples[i]])
                Y = np.vstack([np.tile(self.targets[i], (len(self.samples[i]), 1)) for i in used])
                g = [i for i in used for _ in self.samples[i]]
                cid = time.strftime("cal_%Y%m%d_%H%M%S")
                self.model, self.metrics = fit_gaze_model(X, Y, g, self.screen_size, calibration_id=cid,
                                                          use_head_pose=self.use_head_pose)
                self.metrics["targets_used"] = used
                self.metrics["targets_skipped"] = self.skipped
                self.metrics["samples_per_target"] = {i: len(self.samples[i]) for i in used}
                self.metrics["rejected_per_target"] = dict(self.rejected)
            self.state = "done"
        except ValueError as e:
            self.state, self.error = "failed", str(e)

    def _validate(self, used):
        if len(used) < 2:
            raise ValueError("too few validation targets collected")
        errs = {}
        for i in used:
            pred = np.array([self.model_in.predict(f) for f in self.samples[i]])
            m = pred.mean(0)
            errs[i] = {"accuracy_norm": float(np.linalg.norm(m - np.array(self.targets[i]))),
                       "precision_norm": float(np.sqrt(np.mean(np.sum((pred - m) ** 2, 1))))}
        acc = np.array([v["accuracy_norm"] for v in errs.values()])
        diag = math.hypot(*self.screen_size) / math.sqrt(2)
        self.metrics = {"mean_accuracy_norm": float(acc.mean()), "max_accuracy_norm": float(acc.max()),
                        "mean_accuracy_px": float(acc.mean() * diag), "per_target": errs,
                        "note": "Independent validation targets; accuracy = |mean prediction - target|."}

    def status(self) -> Dict[str, Any]:
        return {"mode": self.mode, "state": self.state, "target_index": self.idx, "target_count": len(self.targets),
                "target": self.current_target, "collected": len(self.samples.get(self.idx, [])), "needed": self.need,
                "rejected": self.rejected.get(self.idx, 0), "needs_attention": self.needs_attention,
                "skipped": list(self.skipped), "error": self.error, "metrics": self.metrics}


# --------------------------------------------------------------- profiles
def _profile_path(directory: str, name: str) -> Path:
    safe = "".join(c for c in name if c.isalnum() or c in "-_ ").strip().replace(" ", "_")
    if not safe:
        raise ValueError("invalid profile name")
    return Path(directory) / f"{safe}.json"


def save_profile(directory: str, name: str, model: GazeModel, camera: Dict[str, Any], extra: Optional[Dict] = None) -> Path:
    p = _profile_path(directory, name)
    p.parent.mkdir(parents=True, exist_ok=True)
    doc = {"profile_name": name, "created": time.time(), "model": model.to_dict(), "camera": camera,
           "feature_normalization": {"mean": model.mean.tolist(), "std": model.std.tolist()},
           "data_quality": model.meta, "kind": "webcam_screen_calibration",
           "warning": "Valid only for this user/camera/seating. NOT a native VR headset calibration.", **(extra or {})}
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    os.replace(tmp, p)
    return p


def load_profile(directory: str, name: str) -> Tuple[GazeModel, Dict[str, Any]]:
    doc = json.loads(_profile_path(directory, name).read_text("utf-8"))
    return GazeModel.from_dict(doc["model"]), doc


def list_profiles(directory: str) -> List[str]:
    d = Path(directory)
    return sorted(json.loads(p.read_text("utf-8")).get("profile_name", p.stem) for p in d.glob("*.json")) if d.exists() else []


def delete_profile(directory: str, name: str) -> bool:
    p = _profile_path(directory, name)
    if p.exists():
        p.unlink()
        return True
    return False
