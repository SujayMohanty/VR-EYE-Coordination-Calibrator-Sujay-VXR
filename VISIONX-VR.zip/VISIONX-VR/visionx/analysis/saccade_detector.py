"""Saccade-like transition and (optional) smooth-pursuit-like detectors on the eye-relative signal.
Webcam sampling (~30 Hz, noisy) is NOT sufficient for research-grade saccade metrics; events are
labelled 'saccade' with `quality='webcam_approximate'`."""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple

from visionx.analysis.movement_metrics import LABELS
from visionx.models.tracking_models import make_event


class SaccadeDetector:
    def __init__(self, velocity=1.5, min_amplitude=0.05, min_ms=30.0, max_gap_s=0.2):
        self.vel, self.min_amp, self.min_ms, self.max_gap_s = velocity, min_amplitude, min_ms, max_gap_s
        self.reset()

    def reset(self):
        self.prev: Optional[Tuple[float, float, float]] = None
        self.active = False
        self.start: Optional[Tuple[float, float, float]] = None
        self.last_fast: Optional[Tuple[float, float, float]] = None
        self.peak = 0.0

    def update(self, ts: float, wall: float, pt: Optional[Tuple[float, float]]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        if pt is None:                       # invalid sample aborts: never infer motion across a gap
            self.reset()
            return out
        cur = (ts, pt[0], pt[1])
        if self.prev is None or ts - self.prev[0] > self.max_gap_s or ts <= self.prev[0]:
            self.reset()
            self.prev = cur
            return out
        dt = ts - self.prev[0]
        speed = math.hypot(cur[1] - self.prev[1], cur[2] - self.prev[2]) / dt
        if speed >= self.vel:
            if not self.active:
                self.active, self.start, self.peak = True, self.prev, 0.0
            self.last_fast, self.peak = cur, max(self.peak, speed)
        elif self.active:
            ev = self._finish(wall)
            if ev:
                out.append(ev)
            self.active = False
        self.prev = cur
        return out

    def _finish(self, wall):
        s, e = self.start, self.last_fast
        dur = (e[0] - s[0]) * 1000
        dx, dy = e[1] - s[1], e[2] - s[2]
        amp = math.hypot(dx, dy)
        if dur < self.min_ms or amp < self.min_amp:
            return None
        ang = math.degrees(math.atan2(dy, dx))
        return make_event("saccade", e[0], wall, start_ts=s[0], end_ts=e[0], duration_ms=dur,
                          amplitude_uv=amp, peak_velocity_uv=self.peak, direction=LABELS[int(round(ang / 45)) % 8],
                          start_uv=(s[1], s[2]), end_uv=(e[1], e[2]), quality="webcam_approximate",
                          coordinates="eye-relative (u,v) eye widths")


class PursuitDetector:
    """Sustained, directionally consistent, sub-saccadic motion. Off by default."""

    def __init__(self, lo=0.15, hi=1.5, min_ms=400.0, consistency=0.85, max_gap_s=0.2):
        self.lo, self.hi, self.min_ms, self.cons, self.max_gap_s = lo, hi, min_ms, consistency, max_gap_s
        self.reset()

    def reset(self):
        self.prev = None
        self.seg: List[Tuple[float, float, float]] = []
        self.path = 0.0

    def update(self, ts, wall, pt) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        if pt is None or (self.prev and ts - self.prev[0] > self.max_gap_s):
            out += self._close(wall)
            self.prev = None
            if pt is None:
                return out
        cur = (ts, pt[0], pt[1])
        if self.prev is not None:
            dt = ts - self.prev[0]
            step = math.hypot(cur[1] - self.prev[1], cur[2] - self.prev[2])
            if self.lo <= step / dt < self.hi:
                if not self.seg:
                    self.seg = [self.prev]
                self.seg.append(cur)
                self.path += step
            else:
                out += self._close(wall)
        self.prev = cur
        return out

    def _close(self, wall):
        seg, path = self.seg, self.path
        self.seg, self.path = [], 0.0
        if len(seg) < 3 or (seg[-1][0] - seg[0][0]) * 1000 < self.min_ms or path <= 0:
            return []
        net = math.hypot(seg[-1][1] - seg[0][1], seg[-1][2] - seg[0][2])
        if net / path < self.cons:
            return []
        return [make_event("smooth_pursuit_like", seg[-1][0], wall, start_ts=seg[0][0], end_ts=seg[-1][0],
                           duration_ms=(seg[-1][0] - seg[0][0]) * 1000, path_uv=path, net_uv=net,
                           quality="webcam_approximate")]
