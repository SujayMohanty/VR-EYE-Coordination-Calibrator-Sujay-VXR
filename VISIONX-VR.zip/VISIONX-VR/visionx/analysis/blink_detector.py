"""Blink / eye-closure detection from eye aspect ratio (EAR) with hysteresis, an adaptive
baseline, debounce and refractory period. Durations are accurate to about +/- one frame."""
from __future__ import annotations

from collections import deque
from statistics import median
from typing import Any, Dict, List, Optional

from visionx.models.tracking_models import make_event


class BlinkDetector:
    def __init__(self, side: str, abs_close=0.17, close_ratio=0.65, open_ratio=0.8, min_ms=40.0,
                 max_ms=600.0, prolonged_ms=1500.0, refractory_s=0.08, abort_gap_s=0.4):
        self.side = side
        self.abs_close, self.close_ratio, self.open_ratio = abs_close, close_ratio, open_ratio
        self.min_ms, self.max_ms, self.prolonged_ms = min_ms, max_ms, prolonged_ms
        self.refractory_s, self.abort_gap_s = refractory_s, abort_gap_s
        self.reset()

    def reset(self):
        self.closed = False
        self.start: Optional[float] = None
        self.last_end = -1e9
        self.last_seen: Optional[float] = None
        self.prolonged_sent = False
        self.base: deque = deque(maxlen=150)

    def thresholds(self):
        if len(self.base) >= 20:
            b = median(self.base)
            return b * self.close_ratio, b * self.open_ratio
        return self.abs_close, self.abs_close * 1.25

    def update(self, ts: float, wall: float, ear: Optional[float]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        if ear is None:                       # no measurement: never treat as open or closed
            if self.closed and self.last_seen is not None and ts - self.last_seen > self.abort_gap_s:
                self.closed, self.start = False, None   # recovery after tracking loss: discard
            return out
        self.last_seen = ts
        close_thr, open_thr = self.thresholds()
        if not self.closed:
            if ear < close_thr and ts - self.last_end >= self.refractory_s:
                self.closed, self.start, self.prolonged_sent = True, ts, False
            elif ear > open_thr:
                self.base.append(ear)
            return out
        dur_ms = (ts - self.start) * 1000.0
        if dur_ms >= self.prolonged_ms and not self.prolonged_sent:
            self.prolonged_sent = True
            out.append(make_event("prolonged_closure", ts, wall, eye=self.side, start_ts=self.start,
                                  duration_ms=dur_ms))
        if ear > open_thr:
            self.closed, self.last_end = False, ts
            meta = dict(eye=self.side, start_ts=self.start, end_ts=ts, duration_ms=dur_ms,
                        close_thr=close_thr, open_thr=open_thr)
            if self.min_ms <= dur_ms <= self.max_ms:
                out.append(make_event("blink", ts, wall, **meta))
            elif dur_ms > self.max_ms:
                out.append(make_event("eye_closure", ts, wall, **meta))
        return out
