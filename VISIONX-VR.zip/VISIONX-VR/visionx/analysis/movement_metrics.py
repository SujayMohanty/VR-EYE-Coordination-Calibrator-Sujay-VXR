"""Per-eye movement in eye-relative (u, v) coordinates (units: eye widths).
Direction labels are IMAGE-PLANE / eye-relative: 'left' = pupil moving toward image-left in the
(unmirrored) camera frame; they are not real-world gaze directions."""
from __future__ import annotations

import math
from typing import Dict, Optional

from visionx.models.tracking_models import EyeMeasurement

LABELS = ["right", "down-right", "down", "down-left", "left", "up-left", "up", "up-right"]


class EyeMovement:
    def __init__(self, dir_thr=0.35, max_gap_s=0.2):
        self.dir_thr, self.max_gap_s = dir_thr, max_gap_s
        self.reset()

    def reset(self):
        self.prev = None            # (ts, u, v)
        self.vel = None             # smoothed velocity
        self.moving = False
        self.bin: Optional[int] = None
        self.path = 0.0
        self.n_valid = self.n_total = 0
        self.speed_sum = 0.0
        self.speed_n = 0

    def update(self, ts: float, e: EyeMeasurement) -> None:
        self.n_total += 1
        if not (e.valid and e.pupil_rel is not None):
            # invalid interval: break the series; NEVER report zero movement for missing data
            self.prev, self.vel, self.moving, self.bin = None, None, False, None
            e.displacement_uv = e.velocity_uv = e.speed_uv = None
            e.direction = "unknown"
            return
        self.n_valid += 1
        u, v = e.pupil_rel
        e.last_valid_ts = ts
        if self.prev is None or ts - self.prev[0] > self.max_gap_s or ts <= self.prev[0]:
            self.prev = (ts, u, v)
            self.vel = None
            e.displacement_uv = e.velocity_uv = e.speed_uv = None
            e.direction = "unknown"
            return
        dt = ts - self.prev[0]
        du, dv = u - self.prev[1], v - self.prev[2]
        raw = (du / dt, dv / dt)
        self.vel = raw if self.vel is None else (0.5 * raw[0] + 0.5 * self.vel[0], 0.5 * raw[1] + 0.5 * self.vel[1])
        self.prev = (ts, u, v)
        speed = math.hypot(*self.vel)
        self.path += math.hypot(du, dv)
        self.speed_sum += speed
        self.speed_n += 1
        e.displacement_uv, e.velocity_uv, e.speed_uv = (du, dv), self.vel, speed
        # hysteresis: enter moving above thr, leave below 0.6*thr
        self.moving = speed > self.dir_thr or (self.moving and speed > 0.6 * self.dir_thr)
        if not self.moving:
            self.bin = None
            e.direction = "stable"
            return
        ang = math.degrees(math.atan2(self.vel[1], self.vel[0]))
        new = int(round(ang / 45.0)) % 8
        if self.bin is None:
            self.bin = new
        elif new != self.bin:
            centre = self.bin * 45.0
            diff = abs((ang - centre + 180) % 360 - 180)
            if diff > 22.5 + 8.0:                  # angular hysteresis
                self.bin = new
        e.direction = LABELS[self.bin]

    def summary(self) -> Dict:
        return {"valid_samples": self.n_valid, "total_samples": self.n_total,
                "valid_fraction": self.n_valid / self.n_total if self.n_total else None,
                "path_length_uv": self.path,
                "mean_speed_uv": self.speed_sum / self.speed_n if self.speed_n else None}
