"""Streaming I-DT fixation-like interval detector (dispersion + duration)."""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from visionx.models.tracking_models import make_event


def _disp(buf) -> float:
    xs, ys = [b[1] for b in buf], [b[2] for b in buf]
    return (max(xs) - min(xs)) + (max(ys) - min(ys))


class FixationDetector:
    def __init__(self, dispersion=0.05, min_ms=150.0, max_gap_s=0.2):
        self.D, self.min_ms, self.max_gap_s = dispersion, min_ms, max_gap_s
        self.reset()

    def reset(self):
        self.buf: List[Tuple[float, float, float]] = []
        self.in_fix = False

    def _emit(self, buf, wall) -> Optional[Dict[str, Any]]:
        dur = (buf[-1][0] - buf[0][0]) * 1000
        if dur < self.min_ms:
            return None
        n = len(buf)
        return make_event("fixation", buf[-1][0], wall, start_ts=buf[0][0], end_ts=buf[-1][0], duration_ms=dur,
                          position_uv=(sum(b[1] for b in buf) / n, sum(b[2] for b in buf) / n), n_samples=n,
                          dispersion_uv=_disp(buf), threshold_dispersion=self.D, threshold_min_ms=self.min_ms,
                          valid=True, coordinates="eye-relative (u,v) eye widths")

    def update(self, ts: float, wall: float, pt: Optional[Tuple[float, float]]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        if pt is None or (self.buf and ts - self.buf[-1][0] > self.max_gap_s):
            if self.in_fix and self.buf:
                ev = self._emit(self.buf, wall)
                if ev:
                    out.append(ev)
            self.reset()
            if pt is None:
                return out
        self.buf.append((ts, pt[0], pt[1]))
        if _disp(self.buf) <= self.D:
            if (self.buf[-1][0] - self.buf[0][0]) * 1000 >= self.min_ms:
                self.in_fix = True
            return out
        if self.in_fix:
            ev = self._emit(self.buf[:-1], wall)
            if ev:
                out.append(ev)
            self.buf, self.in_fix = [self.buf[-1]], False
        else:
            while len(self.buf) > 1 and _disp(self.buf) > self.D:
                self.buf.pop(0)
        return out
