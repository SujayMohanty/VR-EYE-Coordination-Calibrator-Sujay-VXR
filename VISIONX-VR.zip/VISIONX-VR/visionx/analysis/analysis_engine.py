"""Consumes time-stamped records, annotates them in place with per-eye movement, a movement
summary and detected events, and keeps session statistics."""
from __future__ import annotations

from collections import Counter
from typing import Any, Dict, List, Optional

from visionx.analysis.blink_detector import BlinkDetector
from visionx.analysis.fixation_detector import FixationDetector
from visionx.analysis.movement_metrics import EyeMovement
from visionx.analysis.saccade_detector import PursuitDetector, SaccadeDetector
from visionx.models.tracking_models import TrackingRecord, make_event


class AnalysisEngine:
    def __init__(self, settings=None, enable_pursuit: bool = False):
        g = (lambda k, d: settings.get(k) if settings is not None else d)
        self.cfg = dict(
            abs_close=g("events.blink_abs_close", 0.17), close_ratio=g("events.blink_close_ratio", 0.65),
            open_ratio=g("events.blink_open_ratio", 0.8), min_ms=g("events.blink_min_ms", 40.0),
            max_ms=g("events.blink_max_ms", 600.0), prolonged_ms=g("events.prolonged_closure_ms", 1500.0))
        self.enable_pursuit = enable_pursuit
        self.blink = {s: BlinkDetector(s, **self.cfg) for s in ("left", "right")}
        self.move = {s: EyeMovement(g("events.direction_threshold", 0.35)) for s in ("left", "right")}
        self.fix = FixationDetector(g("events.fixation_dispersion", 0.05), g("events.fixation_min_ms", 150.0))
        self.sac = SaccadeDetector(g("events.saccade_velocity", 1.5), g("events.saccade_min_amplitude", 0.05),
                                   g("events.saccade_min_ms", 30.0))
        self.pur = PursuitDetector()
        self.counts: Counter = Counter()
        self.lost_intervals: List[Dict[str, float]] = []
        self.reset_tracking_state()

    def reset_tracking_state(self):
        self.ever_valid = False
        self.lost = False
        self.invalid_run = 0
        self.last_valid_ts: Optional[float] = None
        self.lost_since: Optional[float] = None

    def reset(self):
        for d in list(self.blink.values()) + list(self.move.values()) + [self.fix, self.sac, self.pur]:
            d.reset()
        self.counts.clear()
        self.lost_intervals.clear()
        self.reset_tracking_state()

    def update(self, rec: TrackingRecord) -> TrackingRecord:
        ts, wall = rec.capture_ts, rec.wall_time
        ev: List[Dict[str, Any]] = []
        for s in ("left", "right"):
            e = rec.eye(s)
            ev += self.blink[s].update(ts, wall, e.openness if rec.face_detected else None)
            self.move[s].update(ts, e)
        uvs = [e.pupil_rel for e in (rec.left, rec.right) if e.valid and e.pupil_rel]
        sig = (sum(u for u, _ in uvs) / len(uvs), sum(v for _, v in uvs) / len(uvs)) if uvs else None
        ev += self.fix.update(ts, wall, sig)
        ev += self.sac.update(ts, wall, sig)
        if self.enable_pursuit:
            ev += self.pur.update(ts, wall, sig)
        # tracking lost / recovered (with hysteresis so a blink is not "loss")
        if sig is not None:
            if self.lost:
                dur = ts - (self.lost_since or ts)
                self.lost_intervals.append({"start": self.lost_since or ts, "end": ts, "duration_s": dur})
                ev.append(make_event("tracking_recovered", ts, wall, lost_duration_s=dur))
            self.lost, self.ever_valid, self.invalid_run, self.last_valid_ts = False, True, 0, ts
        else:
            self.invalid_run += 1
            if (self.ever_valid and not self.lost and self.invalid_run >= 5
                    and ts - (self.last_valid_ts or ts) >= 0.25):
                self.lost, self.lost_since = True, self.last_valid_ts
                ev.append(make_event("tracking_lost", ts, wall, reason=rec.left.reason or rec.right.reason))
        for e in ev:
            self.counts[e["type"]] += 1
        rec.events.extend(ev)
        rec.movement = {"left": self.move["left"].summary(), "right": self.move["right"].summary(),
                        "coordinates": "eye-relative (u,v) in eye widths; direction is image-plane"}
        return rec

    def summary(self) -> Dict[str, Any]:
        return {"event_counts": dict(self.counts), "tracking_loss_intervals": list(self.lost_intervals),
                "left": self.move["left"].summary(), "right": self.move["right"].summary()}
