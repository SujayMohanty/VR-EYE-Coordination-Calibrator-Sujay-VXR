"""Download the MediaPipe Face Landmarker model to assets/. Prints SHA-256 for your records."""
import hashlib, sys, urllib.request
from pathlib import Path

URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
DEST = Path(__file__).resolve().parents[1] / "assets" / "face_landmarker.task"


def main() -> int:
    if DEST.exists():
        print(f"Already present: {DEST} ({DEST.stat().st_size} bytes)"); return 0
    DEST.parent.mkdir(parents=True, exist_ok=True)
    tmp = DEST.with_suffix(".part")
    try:
        urllib.request.urlretrieve(URL, tmp)
    except Exception as e:
        print(f"Download failed: {e}\nDownload manually from:\n  {URL}\nand save as:\n  {DEST}"); return 1
    data = tmp.read_bytes()
    if len(data) < 1_000_000:
        tmp.unlink(); print("Downloaded file is suspiciously small; aborting."); return 1
    tmp.replace(DEST)
    print(f"Saved {DEST} ({len(data)} bytes)\nSHA-256: {hashlib.sha256(data).hexdigest()}"); return 0


if __name__ == "__main__":
    sys.exit(main())
