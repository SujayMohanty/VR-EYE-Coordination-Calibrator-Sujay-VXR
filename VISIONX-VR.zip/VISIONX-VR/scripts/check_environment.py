"""Environment check: dependencies, model file, cameras. Exit code 0 only if webcam tracking can run."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from visionx.utils.diagnostics import collect_environment  # noqa: E402


def main() -> int:
    env = collect_environment(); ok = True
    print(f"OS     : {env['os']}\nPython : {env['python']}")
    if sys.version_info[:2] > (3, 12) or sys.version_info[:2] < (3, 10):
        print("  ! Python 3.10-3.12 is required for the MediaPipe wheels (3.12 recommended)"); ok = False
    for k, v in env["packages"].items():
        req = k != "pyopenxr"
        print(f"  {k:14s}: {v or ('MISSING' if req else 'not installed (optional)')}")
        ok &= bool(v) or not req
    print(f"Face model: {env['face_model_path']} -> {'present' if env['face_model_present'] else 'MISSING (python scripts/download_models.py)'}")
    ok &= env["face_model_present"]
    try:
        from visionx.camera.camera_manager import probe_cameras
        cams = probe_cameras(5)
        for c in cams:
            print(f"  camera {c['index']}: {c['width']}x{c['height']} readable={c['available']}")
        if not cams:
            print("  ! no camera could be opened (busy / unplugged / Windows privacy settings)"); ok = False
    except Exception as e:
        print(f"  camera probe failed: {e}"); ok = False
    print("\nRESULT:", "READY" if ok else "NOT READY"); return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
