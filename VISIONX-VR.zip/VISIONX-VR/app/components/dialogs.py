from __future__ import annotations

import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

from PySide6.QtCore import QPointF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QCheckBox, QColorDialog, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFileDialog,
                               QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton,
                               QScrollArea, QSpinBox, QTabWidget, QVBoxLayout, QWidget)

from app import theme
from visionx.config import BY_KEY, PRESETS, SCHEMA


class SettingsDialog(QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.c, self.s = controller, controller.settings
        self.setWindowTitle("VISIONX VR — Settings"); self.resize(620, 640)
        self.w: Dict[str, Any] = {}
        tabs = QTabWidget(); groups: Dict[str, QFormLayout] = {}
        for f in SCHEMA:
            if f.group not in groups:
                page = QWidget(); groups[f.group] = QFormLayout(page)
                sc = QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(page); tabs.addTab(sc, f.group)
            wd = self._make(f); self.w[f.key] = wd
            if f.help: wd.setToolTip(f.help)
            groups[f.group].addRow(f.label, wd)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Apply |
                              QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.RestoreDefaults)
        bb.accepted.connect(self._ok); bb.rejected.connect(self.reject)
        bb.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self._apply)
        bb.button(QDialogButtonBox.StandardButton.RestoreDefaults).clicked.connect(self._defaults)
        self.preset = QComboBox(); self.preset.addItems(list(PRESETS)); self.preset.setCurrentText(self.s.get("tracking.preset"))
        pb = QPushButton("Apply preset"); pb.clicked.connect(self._preset)
        top = QHBoxLayout(); top.addWidget(QLabel("Performance preset:")); top.addWidget(self.preset); top.addWidget(pb); top.addStretch()
        lay = QVBoxLayout(self); lay.addLayout(top); lay.addWidget(tabs); lay.addWidget(bb)

    def _make(self, f):
        v = self.s.get(f.key)
        if f.kind == "bool":
            w = QCheckBox(); w.setChecked(v)
        elif f.kind == "int":
            w = QSpinBox(); w.setRange(int(f.min), int(f.max)); w.setValue(v)
        elif f.kind == "float":
            w = QDoubleSpinBox(); w.setDecimals(3); w.setRange(f.min, f.max); w.setSingleStep(0.05); w.setValue(v)
        elif f.kind == "choice":
            w = QComboBox(); w.addItems([str(c) for c in f.choices]); w.setCurrentText(str(v))
        elif f.kind == "color":
            w = QPushButton(v); w.setProperty("hex", v); w.setStyleSheet(f"background:{v}; color:black;")
            w.clicked.connect(lambda _=False, b=w: self._pick(b))
        elif f.kind == "path":
            w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0); le = QLineEdit(v); b = QPushButton("…")
            b.clicked.connect(lambda: le.setText(QFileDialog.getExistingDirectory(self, "Output directory", le.text()) or le.text()))
            h.addWidget(le); h.addWidget(b); w.le = le
        else:  # multi
            w = QWidget(); h = QVBoxLayout(w); h.setContentsMargins(0, 0, 0, 0); w.boxes = {}
            for c in f.choices:
                cb = QCheckBox(c); cb.setChecked(c in v); h.addWidget(cb); w.boxes[c] = cb
        return w

    def _pick(self, b):
        c = QColorDialog.getColor(QColor(b.property("hex")), self)
        if c.isValid():
            b.setProperty("hex", c.name().upper()); b.setText(c.name().upper()); b.setStyleSheet(f"background:{c.name()}; color:black;")

    def _read(self) -> Dict[str, Any]:
        out = {}
        for k, w in self.w.items():
            f = BY_KEY[k]
            out[k] = (w.isChecked() if f.kind == "bool" else w.value() if f.kind in ("int", "float") else
                      w.currentText() if f.kind == "choice" else w.property("hex") if f.kind == "color" else
                      w.le.text() if f.kind == "path" else [c for c, b in w.boxes.items() if b.isChecked()])
        return out

    def _apply(self) -> bool:
        errs = self.s.update(self._read())
        if errs:
            QMessageBox.warning(self, "Invalid settings", "\n".join(errs)); return False
        try:
            self.s.save()
        except OSError as e:
            QMessageBox.warning(self, "Could not save settings", str(e))
        self.c.apply_settings(); return True

    def _ok(self):
        if self._apply():
            self.accept()

    def _preset(self):
        self.s.apply_preset(self.preset.currentText()); self.c.apply_settings(); self._reload()

    def _defaults(self):
        self.s.reset(); self._reload(); self.c.apply_settings()

    def _reload(self):
        for k, w in self.w.items():
            f, v = BY_KEY[k], self.s.get(k)
            if f.kind == "bool": w.setChecked(v)
            elif f.kind in ("int", "float"): w.setValue(v)
            elif f.kind == "choice": w.setCurrentText(str(v))
            elif f.kind == "color": w.setProperty("hex", v); w.setText(v); w.setStyleSheet(f"background:{v}; color:black;")
            elif f.kind == "path": w.le.setText(v)
            else:
                for c, b in w.boxes.items(): b.setChecked(c in v)


class DiagnosticsDialog(QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.c = controller; self.setWindowTitle("VISIONX VR — Diagnostics"); self.resize(760, 560)
        self.txt = QPlainTextEdit(); self.txt.setReadOnly(True); self.txt.setStyleSheet("font-family:Consolas,monospace;")
        lay = QVBoxLayout(self); lay.addWidget(self.txt)
        self.t = QTimer(self); self.t.timeout.connect(self.refresh); self.t.start(1000); self.refresh()

    def refresh(self):
        if self.isVisible():
            sb = self.txt.verticalScrollBar(); pos = sb.value()
            self.txt.setPlainText(self.c.diagnostics_text()); sb.setValue(pos)


class CalibrationWindow(QWidget):
    """Full-screen target display. Keys: Esc cancel · Space pause/resume · R retry · S skip."""

    def __init__(self, controller, manager, screen=None, on_close=None):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.c, self.m, self.on_close = controller, manager, on_close
        self.setStyleSheet(f"background:{theme.NAVY};"); self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        if screen: self.setScreen(screen); self.move(screen.geometry().topLeft())
        self.t = QTimer(self); self.t.timeout.connect(self._tick); self.t.start(33); self.phase = 0.0
        self.showFullScreen(); self.setFocus()

    def keyPressEvent(self, e):
        k, now = e.key(), time.monotonic()
        if k == Qt.Key.Key_Escape: self.m.cancel()
        elif k == Qt.Key.Key_Space: (self.m.resume if self.m.state == "paused" else self.m.pause)(now)
        elif k == Qt.Key.Key_R: self.m.retry_current(now)
        elif k == Qt.Key.Key_S: self.m.skip_current(now)

    def _tick(self):
        self.phase += 0.1; self.update()
        if self.m.state in ("done", "failed", "cancelled"):
            self.t.stop(); self.close()

    def closeEvent(self, e):
        self.t.stop()
        if self.m.state in ("running", "paused"): self.m.cancel()
        if self.on_close: self.on_close(self.m)
        super().closeEvent(e)

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing); W, H = self.width(), self.height()
        st = self.m.status(); p.fillRect(self.rect(), QColor(theme.NAVY))
        f = QFont(); f.setPointSize(12); p.setFont(f)
        tgt = st["target"]
        if tgt:
            c = QPointF(tgt[0] * W, tgt[1] * H); r = 16 + 5 * math.sin(self.phase)
            frac = st["collected"] / max(1, st["needed"])
            p.setPen(QPen(QColor(theme.BORDER), 3)); p.drawEllipse(c, 34, 34)
            p.setPen(QPen(QColor(theme.CYAN), 4)); p.drawArc(int(c.x() - 34), int(c.y() - 34), 68, 68, 90 * 16, int(-360 * 16 * frac))
            p.setBrush(QColor(theme.BLUE)); p.setPen(Qt.PenStyle.NoPen); p.drawEllipse(c, r, r)
            p.setBrush(QColor("white")); p.drawEllipse(c, 3, 3)
        verb = "Validation" if st["mode"] == "validate" else "Calibration"
        msg = f"{verb}: target {st['target_index'] + 1}/{st['target_count']}   samples {st['collected']}/{st['needed']}   rejected {st['rejected']}"
        if st["state"] == "paused": msg += "   [PAUSED]"
        p.setPen(QColor(theme.MUTED)); p.drawText(20, H - 50, msg)
        p.drawText(20, H - 24, "Look at the dot and keep your head still.   Esc cancel · Space pause · R retry · S skip")
        if st["needs_attention"]:
            p.setPen(QColor(theme.WARN)); p.drawText(20, 40, "Not collecting valid samples at this target — press R to retry or S to skip. Check lighting / eye visibility.")


class CaptureDetailDialog(QDialog):
    """Shows the ACTUAL stored files of a capture (images read from disk) and its record."""

    def __init__(self, res, parent=None):
        super().__init__(parent); self.setWindowTitle(f"Capture {res.capture_id}"); self.resize(900, 640)
        tabs = QTabWidget(); lay = QVBoxLayout(self); lay.addWidget(QLabel(f"{res.message}   [{res.status.upper()}]")); lay.addWidget(tabs)
        for name, path in res.files.items():
            if name == "metadata":
                continue
            lbl = QLabel(); pm = QPixmap(path)
            if pm.isNull():
                lbl.setText(f"Could not read {path}")
            else:
                lbl.setPixmap(pm.scaled(860, 520, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter); sc = QScrollArea(); sc.setWidget(lbl); sc.setWidgetResizable(True); tabs.addTab(sc, name)
        txt = QPlainTextEdit(); txt.setReadOnly(True)
        meta = res.files.get("metadata")
        try:
            txt.setPlainText(Path(meta).read_text("utf-8") if meta else json.dumps(res.record, indent=2, default=str))
        except OSError as e:
            txt.setPlainText(f"metadata unreadable: {e}")
        tabs.addTab(txt, "Record / metadata")
        if res.failed:
            f = QPlainTextEdit(json.dumps(res.failed, indent=2)); f.setReadOnly(True); tabs.addTab(f, "Failed artifacts")
        info = QLabel("Files:\n" + "\n".join(f"{k}: {v}" for k, v in res.files.items())); info.setProperty("mono", True)
        info.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse); lay.addWidget(info)


class SummaryDialog(QDialog):
    def __init__(self, title: str, text: str, parent=None):
        super().__init__(parent); self.setWindowTitle(title); self.resize(560, 460)
        t = QPlainTextEdit(text); t.setReadOnly(True); t.setStyleSheet("font-family:Consolas,monospace;")
        b = QDialogButtonBox(QDialogButtonBox.StandardButton.Close); b.rejected.connect(self.reject); b.accepted.connect(self.accept)
        l = QVBoxLayout(self); l.addWidget(t); l.addWidget(b)


def format_summary(d: Dict[str, Any]) -> str:
    def v(x):
        return "N/A" if x is None else (f"{x:.3f}" if isinstance(x, float) else str(x))
    L = []
    for k, x in d.items():
        if isinstance(x, dict) and len(x) < 12:
            L.append(f"{k}:"); L += [f"    {a}: {v(b)}" for a, b in x.items()]
        elif isinstance(x, list) and x and isinstance(x[0], dict):
            L.append(f"{k}:"); L += [f"    {', '.join(f'{a}={v(b)}' for a, b in i.items())}" for i in x]
        else:
            L.append(f"{k}: {v(x)}")
    return "\n".join(L)
