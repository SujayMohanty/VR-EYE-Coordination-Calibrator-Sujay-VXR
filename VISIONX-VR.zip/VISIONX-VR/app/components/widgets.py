from __future__ import annotations

import math
from collections import deque
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from PySide6.QtCore import QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen
from PySide6.QtWidgets import QSizePolicy, QToolButton, QVBoxLayout, QWidget

from app import theme


class ImageView(QWidget):
    """Shows a BGR ndarray 1:1. Callers render at self.width() x self.height() (see render_* in visionx.render)."""

    def __init__(self, min_size=(240, 160), parent=None):
        super().__init__(parent)
        self._img: Optional[QImage] = None
        self.setMinimumSize(*min_size)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_image(self, bgr: np.ndarray):
        bgr = np.ascontiguousarray(bgr)
        h, w = bgr.shape[:2]
        self._img = QImage(bgr.data, w, h, 3 * w, QImage.Format.Format_BGR888).copy()
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(theme.NAVY))
        if self._img is not None:
            p.drawImage(self.rect(), self._img)

    def sizeHint(self):
        return QSize(480, 320)


class CollapsibleSection(QWidget):
    def __init__(self, title: str, content: QWidget, expanded=True, parent=None):
        super().__init__(parent)
        self.btn = QToolButton(); self.btn.setText(("▾ " if expanded else "▸ ") + title); self.btn.setCheckable(True)
        self.btn.setChecked(expanded); self.btn.setStyleSheet("text-align:left; font-weight:600;")
        self.btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        self.btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.content, self.title = content, title
        content.setVisible(expanded)
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(2)
        lay.addWidget(self.btn); lay.addWidget(content)
        self.btn.toggled.connect(self._toggle)

    def _toggle(self, on: bool):
        self.content.setVisible(on)
        self.btn.setText(("▾ " if on else "▸ ") + self.title)


class TimeSeriesPlot(QWidget):
    """Lightweight QPainter plot. Data is pulled from a bounded history; invalid samples (None) leave gaps."""

    def __init__(self, title: str, y_label: str, series: Sequence[Tuple[str, str]], y_range=(-0.3, 1.0), parent=None):
        super().__init__(parent)
        self.title, self.y_label, self.series = title, y_label, list(series)       # [(name, color)]
        self.base_range, self.zoom, self.auto = y_range, 1.0, False
        self.window_s = 10.0
        self.data: Dict[str, List[Tuple[float, Optional[float]]]] = {}
        self.markers: List[Tuple[float, str]] = []
        self.now = 0.0
        self.setMinimumHeight(150)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_data(self, now: float, window_s: float, data, markers):
        self.now, self.window_s, self.data, self.markers = now, window_s, data, markers
        self.update()

    def zoom_in(self): self.zoom = max(0.2, self.zoom * 0.7); self.auto = False; self.update()
    def zoom_out(self): self.zoom = min(5.0, self.zoom / 0.7); self.auto = False; self.update()
    def fit(self): self.auto = True; self.update()

    def _range(self):
        lo, hi = self.base_range
        if self.auto:
            vals = [v for s in self.data.values() for _, v in s if v is not None]
            if vals:
                a, b = min(vals), max(vals); pad = max(0.05, (b - a) * 0.1); return a - pad, b + pad
        c, h = (lo + hi) / 2, (hi - lo) / 2 * self.zoom
        return c - h, c + h

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height(); L, R, T, B = 48, 10, 22, 26
        pw, ph = max(10, W - L - R), max(10, H - T - B)
        p.fillRect(self.rect(), QColor(theme.PANEL))
        lo, hi = self._range()
        x_of = lambda t: L + (t - (self.now - self.window_s)) / self.window_s * pw
        y_of = lambda v: T + (1 - (v - lo) / (hi - lo)) * ph
        p.setPen(QPen(QColor(theme.BORDER), 1))
        f = QFont(); f.setPointSize(8); p.setFont(f)
        for i in range(5):                                         # y grid + labels
            v = lo + (hi - lo) * i / 4; y = y_of(v)
            p.drawLine(L, int(y), L + pw, int(y))
            p.setPen(QColor(theme.MUTED)); p.drawText(2, int(y) + 4, f"{v:+.2f}"); p.setPen(QPen(QColor(theme.BORDER), 1))
        for i in range(0, int(self.window_s) + 1, max(1, int(self.window_s // 5))):   # x grid + labels
            x = x_of(self.now - self.window_s + i)
            p.drawLine(int(x), T, int(x), T + ph)
            p.setPen(QColor(theme.MUTED)); p.drawText(int(x) - 12, H - 8, f"{i - self.window_s:.0f}s"); p.setPen(QPen(QColor(theme.BORDER), 1))
        p.setPen(QColor(theme.CYAN)); p.drawText(L, 14, f"{self.title}   [{self.y_label}]")
        lx = L + pw
        for name, col in reversed(self.series):
            lx -= 62; p.setPen(QColor(col)); p.drawText(lx, 14, f"— {name}")
        for t, kind in self.markers:                               # blink / lost / recovered markers
            if t < self.now - self.window_s:
                continue
            col = {"blink": theme.CYAN, "tracking_lost": theme.BAD, "tracking_recovered": theme.GOOD,
                   "saccade": theme.WARN, "fixation": theme.MUTED}.get(kind, theme.MUTED)
            p.setPen(QPen(QColor(col), 1, Qt.PenStyle.DashLine)); x = x_of(t); p.drawLine(int(x), T, int(x), T + ph)
        p.setClipRect(QRectF(L, T, pw, ph))
        for name, col in self.series:
            pen = QPen(QColor(col), 1.6); p.setPen(pen)
            prev: Optional[QPointF] = None
            for t, v in self.data.get(name, []):
                if v is None or t < self.now - self.window_s:
                    prev = None; continue
                pt = QPointF(x_of(t), y_of(v))
                if prev is not None:
                    p.drawLine(prev, pt)
                prev = pt


class SignalHistory:
    """Short plotting history per eye. Full-session data lives in the recorder, never here."""

    def __init__(self, maxlen=4000):
        self.q: deque = deque(maxlen=maxlen)

    def push(self, rec, side: str):
        e = rec.eye(side); ok = e.valid and e.pupil_rel is not None
        self.q.append((rec.capture_ts, e.pupil_rel[0] if ok else None, e.pupil_rel[1] if ok else None,
                       e.pupil_diameter_px if ok else None, e.openness))

    def clear(self): self.q.clear()

    def series(self, now: float, window: float):
        lo = now - window
        d = {"u (x)": [], "v (y)": [], "open": [], "diam px": []}
        for t, u, v, dia, op in self.q:
            if t < lo:
                continue
            d["u (x)"].append((t, u)); d["v (y)"].append((t, v)); d["open"].append((t, op)); d["diam px"].append((t, dia))
        return d
