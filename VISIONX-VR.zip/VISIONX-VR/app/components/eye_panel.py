from __future__ import annotations

import copy
from typing import Optional

from PySide6.QtWidgets import (QCheckBox, QComboBox, QGroupBox, QHBoxLayout, QLabel, QPushButton, QToolButton, QVBoxLayout)

from app.components.widgets import ImageView
from visionx.render.overlay import VIEW_MODES, OverlayOptions, render_eye
from visionx.tracking.base_provider import FrameBundle

LEGEND = ("px = source-frame pixels (never mirrored, origin top-left).  (u,v) = eye-relative, units of eye width, "
          "u=0 at image-left corner, v=0 on corner line (+down).  Pupil size is apparent pixels, not mm.")


def fmt(v, spec=".1f", unit=""):
    return "N/A" if v is None else format(v, spec) + unit


def pt(p, spec=".1f"):
    return "N/A" if p is None else f"({p[0]:{spec}}, {p[1]:{spec}})"


class EyePanel(QGroupBox):
    def __init__(self, side: str, controller, parent=None):
        super().__init__(f"{side.capitalize()} eye — live pupil view", parent)
        self.side, self.c = side, controller
        self.zoom, self.frozen, self.frozen_trails = 1.0, None, None
        self.view = ImageView((320, 210))
        self.mode = QComboBox(); self.mode.addItems(VIEW_MODES); self.mode.setCurrentText(controller.settings.get("monitor.view_mode"))
        self.mode.setToolTip("raw · landmarks · overlay · processed (derived) · side_by_side")
        mk = lambda t, tip, fn: self._btn(t, tip, fn)
        zi, zo = mk("＋", "Zoom in", lambda: self._zoom(1.25)), mk("－", "Zoom out", lambda: self._zoom(0.8))
        fit, rst = mk("Fit", "Fit eye crop to panel", lambda: self._set_zoom(1.0)), mk("1:1", "Reset zoom", lambda: self._set_zoom(1.0))
        self.cb = {n: QCheckBox(n) for n in ("Reticle", "Landmarks", "Trail", "Coords")}
        for b in self.cb.values():
            b.setChecked(True)
        self.freeze = QPushButton("Freeze view"); self.freeze.setCheckable(True); self.freeze.toggled.connect(self._freeze)
        cc = mk("Capture crop", "Save the raw eye crop of the displayed frame", lambda: self.c.capture_eye(side, False, self.frozen))
        ca = mk("Capture annotated", "Save the eye crop with tracking overlay", lambda: self.c.capture_eye(side, True, self.frozen))
        rt = mk("Reset trail", "Clear the displayed movement trail", lambda: self.c.trails.clear(side))
        r1, r2 = QHBoxLayout(), QHBoxLayout()
        for w in (self.mode, zi, zo, fit, rst, *self.cb.values()):
            r1.addWidget(w)
        for w in (self.freeze, cc, ca, rt):
            r2.addWidget(w)
        r1.addStretch(); r2.addStretch()
        self.info = QLabel(); self.info.setProperty("mono", True); self.info.setWordWrap(True)
        lay = QVBoxLayout(self); lay.addWidget(self.view, 1); lay.addLayout(r1); lay.addLayout(r2); lay.addWidget(self.info)
        leg = QLabel(LEGEND); leg.setProperty("muted", True); leg.setWordWrap(True); leg.setStyleSheet("font-size:8pt;"); lay.addWidget(leg)

    def _btn(self, text, tip, fn):
        b = QToolButton(); b.setText(text); b.setToolTip(tip); b.clicked.connect(lambda _=False: fn()); return b

    def _zoom(self, f): self.zoom = min(8.0, max(0.5, self.zoom * f))
    def _set_zoom(self, z): self.zoom = z

    def _freeze(self, on: bool):
        self.freeze.setText("Resume live" if on else "Freeze view")
        if on:
            self.frozen, self.frozen_trails = self._last, copy.deepcopy(self.c.trails)
            self.setTitle(f"{self.side.capitalize()} eye — FROZEN VIEW (tracking continues)")
        else:
            self.frozen, self.frozen_trails = None, None
            self.setTitle(f"{self.side.capitalize()} eye — live pupil view")

    _last: Optional[FrameBundle] = None

    def refresh(self, bundle: Optional[FrameBundle]):
        self._last = bundle if self.frozen is None else self._last
        b = self.frozen or bundle
        o = self.c.overlay_options()
        o.reticle, o.eye_outline, o.trail, o.coords = (self.cb["Reticle"].isChecked(), self.cb["Landmarks"].isChecked(),
                                                       self.cb["Trail"].isChecked(), self.cb["Coords"].isChecked())
        w, h = max(64, self.view.width()), max(48, self.view.height())
        mode = self.mode.currentText()
        if mode == "overlay" and not o.eye_outline:
            pass
        self.view.set_image(render_eye(b, self.side, (w, h), o, mode, self.zoom, self.frozen_trails or self.c.trails,
                                       self.frozen is not None))
        self.info.setText(self.measure_text(b))

    def measure_text(self, b: Optional[FrameBundle]) -> str:
        if b is None:
            return "No data."
        r = b.record; e = r.eye(self.side)
        ago = "N/A" if e.last_valid_ts is None else f"{r.capture_ts - e.last_valid_ts:.2f}s before this frame"
        v = e.velocity_uv
        rows = [
            f"state     : {e.status.upper():15s} valid={e.valid}  reason={e.reason or '-'}  src={e.provenance or '-'}",
            f"pupil px  : {pt(e.pupil_xy)}   candidate {pt(e.candidate_xy)}",
            f"pupil u,v : {pt(e.pupil_rel, '.3f')}   iris px {pt(e.iris_xy)}   iris u,v {pt(e.iris_rel, '.3f')}",
            f"pupil size: w {fmt(e.pupil_width_px)}  h {fmt(e.pupil_height_px)}  diam {fmt(e.pupil_diameter_px)} px (apparent)",
            f"openness  : {fmt(e.openness, '.3f')} (EAR)   quality {e.quality:.2f} (heuristic)  det {fmt(e.detector_quality, '.2f')}",
            f"movement  : Δ{pt(e.displacement_uv, '.4f')}  v {pt(v, '.2f')} u/s  |v| {fmt(e.speed_uv, '.2f')}  dir {e.direction} (image-plane)",
            f"last valid: {ago}",
        ]
        return "\n".join(rows) + ("\n[values from FROZEN frame]" if self.frozen else "")
