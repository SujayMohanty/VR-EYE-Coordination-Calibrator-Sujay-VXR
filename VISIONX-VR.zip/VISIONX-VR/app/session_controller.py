"""Single owner of camera, pipeline, calibration, capture and recording. Both windows are
subscribers; neither runs its own camera or estimator."""
from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional

from PySide6.QtCore import QObject, QTimer, Signal, Slot

from visionx.analysis.analysis_engine import AnalysisEngine
from visionx.calibration import calibration_manager as cal
from visionx.camera.camera_manager import CameraCapture, probe_cameras
from visionx.camera.frame_source import CvCameraSource, VideoFileSource
from visionx.capture.capture_manager import AutoCaptureTrigger, CaptureManager, build_artifacts
from visionx.config import Settings, user_config_path
from visionx.pipeline import TrackingPipeline
from visionx.recording.exporters import export_session
from visionx.recording.playback import ReplaySession, ReplayError
from visionx.recording.recorder import SessionRecorder
from visionx.render.overlay import OverlayOptions
from visionx.render.trails import TrailSet
from visionx.tracking.base_provider import FrameBundle
from visionx.tracking.landmark_tracker import MediaPipeLandmarkTracker, ModelNotFoundError
from visionx.tracking.webcam_provider import WebcamTrackingEngine
from visionx.utils.diagnostics import collect_environment
from visionx.utils.logging_config import RECENT
from visionx.vr.openxr_adapter import probe_openxr
from visionx.vr.udp_provider import UdpBridgeProvider

log = logging.getLogger("visionx.session")


class SessionController(QObject):
    bundle_ready = Signal(object)          # FrameBundle (GUI thread)
    state_changed = Signal(str)            # stopped | running | paused | replay | native
    event_emitted = Signal(dict)
    message = Signal(str, str)             # text, level
    capture_finished = Signal(object)
    calibration_changed = Signal()
    recording_changed = Signal(str)
    settings_applied = Signal()
    camera_state = Signal(str, str)
    _wake = Signal()                       # worker thread -> GUI thread
    _capture_cb = Signal(object)

    def __init__(self, settings: Settings, source: Optional[str] = None, parent=None):
        super().__init__(parent)
        self.settings, self.source = settings, source
        self.session_id = time.strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:4]
        self.state = "stopped"
        self.camera: Optional[CameraCapture] = None
        self.engine: Optional[WebcamTrackingEngine] = None
        self.analysis = AnalysisEngine(settings)
        self.pipeline: Optional[TrackingPipeline] = None
        self.recorder = SessionRecorder()
        self.last_recording_dir: Optional[Path] = None
        self.capture: Optional[CaptureManager] = None
        self.trigger = AutoCaptureTrigger()
        self.trails = TrailSet(settings.get("overlay.trail_length"))
        self.latest: Optional[FrameBundle] = None
        self.calibration: Optional[cal.CalibrationManager] = None
        self.gaze_model = None
        self.calibration_name: Optional[str] = None
        self.replay: Optional[ReplaySession] = None
        self.vr = None
        self.event_log: deque = deque(maxlen=500)
        self.counts = {"blinks": 0, "losses": 0}
        self._ui_q: deque = deque(maxlen=120)
        self._wake_pending = False
        self._lock = threading.Lock()
        self.screen_size = (1920, 1080)
        self._wake.connect(self._drain)
        self._capture_cb.connect(self._on_capture_done)
        self._replay_timer = QTimer(self); self._replay_timer.timeout.connect(self._replay_tick)
        self._vr_timer = QTimer(self); self._vr_timer.timeout.connect(self._vr_tick)
        self._last_tick = time.monotonic()

    # ----------------------------------------------------------------- paths
    @property
    def out_dir(self) -> str:
        return str(Path(self.settings.get("capture.directory")).expanduser())

    @property
    def profile_dir(self) -> str:
        return str(user_config_path().parent / "profiles")

    def overlay_options(self) -> OverlayOptions:
        return OverlayOptions.from_settings(self.settings)

    def _set_state(self, st: str):
        self.state = st
        self.state_changed.emit(st)

    def _msg(self, text, level="info"):
        getattr(log, "error" if level == "error" else "warning" if level == "warning" else "info")(text)
        self.message.emit(text, level)

    # ----------------------------------------------------------------- tracking
    def start_tracking(self) -> bool:
        if self.state in ("running", "paused"):
            return True
        if self.replay is not None:
            self.close_replay()
        provider = self.settings.get("tracking.provider")
        if provider != "webcam":
            return self._start_vr(provider)
        try:
            tracker = MediaPipeLandmarkTracker(proc_width=self.settings.get("tracking.proc_width"))
        except ModelNotFoundError as e:
            self._msg(str(e), "error"); return False
        except Exception as e:
            self._msg(f"Could not initialise MediaPipe: {e}", "error"); return False
        s = self.settings
        factory = (lambda: VideoFileSource(self.source)) if self.source else (
            lambda: CvCameraSource(s.get("camera.index"), s.get("camera.width"), s.get("camera.height"),
                                   s.get("camera.fps"), s.get("camera.brightness")))
        self.camera = CameraCapture(factory, on_state=lambda a, b: self.camera_state.emit(a, b))
        self.engine = WebcamTrackingEngine(s, tracker, self.session_id)
        self.engine.set_gaze_model(self.gaze_model)
        self.analysis = AnalysisEngine(s)
        self.pipeline = TrackingPipeline(self.camera, self.engine, self.analysis, self._on_bundle_worker)
        self.trails.clear()
        self.camera.start(); self.pipeline.start()
        self._set_state("running")
        return True

    def pause_tracking(self):
        if self.pipeline and self.state == "running":
            self.pipeline.pause(); self._set_state("paused")

    def resume_tracking(self):
        if self.pipeline and self.state == "paused":
            self.pipeline.resume(); self._set_state("running")

    def stop_tracking(self):
        if self.recorder.state != "idle":
            self.stop_recording()
        if self.calibration and self.calibration.state in ("running", "paused"):
            self.calibration.cancel(); self.calibration_changed.emit()
        if self._vr_timer.isActive():
            self._vr_timer.stop()
        if self.vr:
            self.vr.stop(); self.vr = None
        if self.pipeline:
            if not self.pipeline.stop():
                log.warning("pipeline thread did not stop in time")
            self.pipeline = None
        if self.camera:
            self.camera.stop(); self.camera = None
        if self.engine:
            self.engine.close(); self.engine = None
        self.latest = None
        self._set_state("stopped")

    def select_camera(self, index: int):
        self.settings.set("camera.index", index)
        if self.state in ("running", "paused"):
            self.stop_tracking(); self.start_tracking()

    def probe(self) -> List[Dict[str, Any]]:
        skip = (self.settings.get("camera.index"),) if self.camera and self.camera.running else ()
        return probe_cameras(5, skip)

    # worker thread ---------------------------------------------------
    def _on_bundle_worker(self, b: FrameBundle):
        if self.recorder.state == "recording":
            self.recorder.write(b.record, b.frame if self.settings.get("recording.save_video") else None)
        with self._lock:
            self._ui_q.append(b)
            if self._wake_pending:
                return
            self._wake_pending = True
        self._wake.emit()

    # GUI thread ------------------------------------------------------
    @Slot()
    def _drain(self):
        with self._lock:
            items = list(self._ui_q); self._ui_q.clear(); self._wake_pending = False
        for b in items:
            self._handle_bundle(b)

    def _handle_bundle(self, b: FrameBundle):
        rec = b.record
        self.latest = b
        self.trails.update(rec)
        for e in rec.events:
            self.event_log.append(e)
            self.counts["blinks"] += e["type"] == "blink"
            self.counts["losses"] += e["type"] == "tracking_lost"
            self.event_emitted.emit(e)
        if self.calibration and self.calibration.state == "running":
            self.calibration.feed(rec, rec.capture_ts)
            if self.calibration.state != "running":
                self._calibration_finished()
        mode = self.trigger.should_capture(rec, rec.capture_ts)
        if mode and self.state == "running":
            self._auto_capture(b, mode)
        self.bundle_ready.emit(b)

    # ----------------------------------------------------------------- native VR providers
    def _start_vr(self, provider: str) -> bool:
        if provider == "openxr":
            st = probe_openxr()
            self._msg("OpenXR: " + st.detail + " Native gaze reaches VISIONX via the UDP bridge.", "warning")
            return False
        vr = UdpBridgeProvider(self.settings.get("vr.udp_port"), self.settings.get("vr.stale_ms"), self.session_id)
        st = vr.start()
        if not st.initialized:
            self._msg(st.detail, "error"); return False
        self.vr = vr
        self._vr_timer.start(5)
        self._set_state("native")
        self._msg(st.detail, "info")
        return True

    def _vr_tick(self):
        if not self.vr:
            return
        for _ in range(20):
            r = self.vr.poll()
            if r is None:
                break
            if self.recorder.state == "recording":
                self.recorder.write(r)
            self._handle_bundle(FrameBundle(r, None, None, {}, "native"))

    # ----------------------------------------------------------------- capture
    def _cm(self) -> CaptureManager:
        if self.capture is None or str(self.capture.root.parent) != str(Path(self.out_dir)):
            if self.capture:
                self.capture.close()
            self.capture = CaptureManager(self.out_dir, self.session_id, lambda r: self._capture_cb.emit(r),
                                          self.settings.get("capture.max_files"))
        self.capture.max_files = self.settings.get("capture.max_files")
        return self.capture

    def _can_capture(self) -> Optional[FrameBundle]:
        if self.latest is None:
            self._msg("Nothing to capture: tracking has not produced a record yet.", "warning")
        return self.latest

    def _meta(self) -> Dict[str, Any]:
        return {"camera": self.camera.info() if self.camera else None, "calibration_profile": self.calibration_name,
                "provider": self.settings.get("tracking.provider"), "mirror_preview": self.settings.get("camera.mirror")}

    def capture_sample(self):
        b = self._can_capture()
        if b:
            self._cm().submit("sample", b, {}, self._meta())

    def capture_image(self, names: Optional[List[str]] = None):
        b = self._can_capture()
        if b:
            if b.frame is None:
                self._msg("No camera image available (numeric replay or native VR).", "warning"); return
            arts = build_artifacts(b, names or self.settings.get("capture.artifacts"), self.overlay_options(), self.trails)
            self._cm().submit("image", b, arts, self._meta())

    def capture_eye(self, side: str, annotated: bool, bundle: Optional[FrameBundle] = None):
        b = bundle or self._can_capture()
        if b:
            name = f"{side}_eye_{'overlay' if annotated else 'crop'}"
            self._cm().submit("image", b, build_artifacts(b, [name], self.overlay_options(), self.trails), self._meta(),
                              write_sample=False)

    def _auto_capture(self, b: FrameBundle, mode: str):
        arts = (build_artifacts(b, self.settings.get("capture.artifacts"), self.overlay_options(), self.trails)
                if self.settings.get("capture.auto_images") else {})
        meta = self._meta(); meta["auto_trigger"] = mode
        self._cm().submit("auto", b, arts, meta)

    @Slot(object)
    def _on_capture_done(self, res):
        self.capture_finished.emit(res)
        self._msg(res.message, "info" if res.status == "ok" else "warning" if res.status == "partial" else "error")

    # ----------------------------------------------------------------- recording
    def recording_description(self) -> str:
        s = self.settings
        what = ["time-stamped pupil/iris/gaze measurements and events"]
        what += [f for f, on in (("CSV", s.get("recording.save_csv")), ("JSONL", s.get("recording.save_jsonl"))) if on]
        extra = "RAW VIDEO of your face WILL be saved." if s.get("recording.save_video") else "No video or images are saved."
        return f"Saves: {', '.join(what)}.\n{extra}\nFolder: {Path(self.out_dir).resolve()}"

    def start_recording(self) -> bool:
        if self.state not in ("running", "native") or self.recorder.state != "idle":
            self._msg("Start tracking first (and stop the current recording).", "warning"); return False
        try:
            fs = self.latest.record.frame_size if self.latest else None
            self.last_recording_dir = self.recorder.start(
                self.out_dir, self.session_id, {**self._meta(), "settings": self.settings.values},
                self.settings.get("recording.save_csv"), self.settings.get("recording.save_jsonl"),
                self.settings.get("recording.save_video"), fs, self.camera.fps if self.camera and self.camera.fps else 30)
        except Exception as e:
            self._msg(f"Could not start recording: {e}", "error"); return False
        self.recording_changed.emit("recording"); self._msg(f"Recording to {self.last_recording_dir}", "info")
        return True

    def pause_recording(self):
        self.recorder.pause(); self.recording_changed.emit(self.recorder.state)

    def resume_recording(self):
        self.recorder.resume(); self.recording_changed.emit(self.recorder.state)

    def stop_recording(self):
        if self.recorder.state == "idle":
            return
        man = self.recorder.stop()
        self.recording_changed.emit("idle")
        lvl = "info" if not man.get("last_error") and not man.get("dropped_records") else "warning"
        self._msg(f"Recording saved: {man['counts']['records']} records, {man['counts']['events']} events"
                  + (f", {man['dropped_records']} DROPPED" if man.get("dropped_records") else "")
                  + (f". Error: {man['last_error']}" if man.get("last_error") else ""), lvl)

    def export(self, session_dir: str, fmt: str, out_path: str) -> Optional[Path]:
        try:
            p = export_session(session_dir, out_path, fmt)
            self._msg(f"Exported to {p}", "info"); return p
        except Exception as e:
            self._msg(f"Export failed: {e}", "error"); return None

    # ----------------------------------------------------------------- replay
    def open_replay(self, directory: str) -> bool:
        try:
            rs = ReplaySession(directory)
        except (ReplayError, OSError, ValueError) as e:
            self._msg(f"Cannot open session: {e}", "error"); return False
        if self.state in ("running", "paused", "native"):
            self.stop_tracking()
        self.close_replay()
        self.replay = rs
        self.trails.clear()
        self._set_state("replay"); self._show_replay_frame()
        return True

    def close_replay(self):
        self._replay_timer.stop()
        if self.replay:
            self.replay.close(); self.replay = None
        if self.state == "replay":
            self.latest = None; self._set_state("stopped")

    def replay_play(self):
        if self.replay:
            self.replay.play(); self._last_tick = time.monotonic(); self._replay_timer.start(15)

    def replay_pause(self):
        if self.replay:
            self.replay.pause(); self._replay_timer.stop()

    def replay_stop(self):
        if self.replay:
            self.replay_pause(); self.replay.stop(); self.trails.clear(); self._show_replay_frame()

    def replay_step(self, n: int):
        if self.replay:
            self.replay_pause(); self.replay.step(n); self._show_replay_frame()

    def replay_seek(self, i: int):
        if self.replay:
            self.replay.seek(i); self._show_replay_frame()

    def _replay_tick(self):
        now = time.monotonic(); dt, self._last_tick = now - self._last_tick, now
        if not self.replay:
            return
        passed = self.replay.advance(dt)
        if passed:
            for r in passed[:-1]:
                self.trails.update(r)
            self._show_replay_frame()
        if not self.replay.playing:
            self._replay_timer.stop()

    def _show_replay_frame(self):
        rec = self.replay.current
        self._handle_bundle(FrameBundle(rec, self.replay.video_frame(), None, {}, "replay"))

    # ----------------------------------------------------------------- calibration
    def start_calibration(self, validate: bool = False, points: Optional[int] = None) -> Optional[cal.CalibrationManager]:
        if self.state != "running":
            self._msg("Start tracking before calibrating.", "warning"); return None
        s = self.settings
        if validate and self.gaze_model is None:
            self._msg("Nothing to validate: calibrate or load a profile first.", "warning"); return None
        self.calibration = cal.CalibrationManager(
            points or int(s.get("calibration.points")), s.get("calibration.samples_per_point"), s.get("calibration.settle_ms"),
            max(0.3, s.get("tracking.confidence_threshold")), s.get("calibration.use_head_pose"), self.screen_size,
            "validate" if validate else "calibrate", self.gaze_model if validate else None)
        self.calibration.start(time.monotonic())
        self.calibration_changed.emit(); self.state_changed.emit(self.state)
        return self.calibration

    def _calibration_finished(self):
        c = self.calibration
        if c.mode == "calibrate" and c.state == "done":
            self.gaze_model = c.model; self.calibration_name = c.model.calibration_id
            if self.engine:
                with self.pipeline.lock:
                    self.engine.set_gaze_model(self.gaze_model)
        self.calibration_changed.emit(); self.state_changed.emit(self.state)

    def save_profile(self, name: str) -> Optional[Path]:
        if self.gaze_model is None:
            self._msg("No calibration to save.", "warning"); return None
        try:
            p = cal.save_profile(self.profile_dir, name, self.gaze_model, self.camera.info() if self.camera else {})
            self.calibration_name = name; self._msg(f"Profile saved: {p}", "info"); return p
        except Exception as e:
            self._msg(f"Could not save profile: {e}", "error"); return None

    def load_profile(self, name: str) -> bool:
        try:
            m, doc = cal.load_profile(self.profile_dir, name)
        except Exception as e:
            self._msg(f"Could not load profile: {e}", "error"); return False
        self.gaze_model, self.calibration_name = m, name
        if self.engine:
            with self.pipeline.lock:
                self.engine.set_gaze_model(m)
        self._msg(f"Loaded profile '{name}' (valid only for the same user/camera/seating).", "info")
        self.state_changed.emit(self.state); return True

    def delete_profile(self, name: str) -> bool:
        return cal.delete_profile(self.profile_dir, name)

    def clear_calibration(self):
        self.gaze_model, self.calibration_name, self.calibration = None, None, None
        if self.engine:
            with self.pipeline.lock:
                self.engine.set_gaze_model(None)
        self.calibration_changed.emit(); self.state_changed.emit(self.state)

    # ----------------------------------------------------------------- settings / status
    def apply_settings(self):
        s = self.settings
        self.trails.set_maxlen(s.get("overlay.trail_length"))
        self.trigger.mode, self.trigger.interval_s, self.trigger.min_interval_s = (
            s.get("capture.auto_mode"), s.get("capture.auto_interval_s"), s.get("capture.min_interval_s"))
        if self.engine and self.pipeline:
            with self.pipeline.lock:
                self.engine.configure()
                self.analysis.__init__(s)  # new thresholds
        self.settings_applied.emit()

    def display_status(self) -> Optional[str]:
        if self.state == "replay":
            return "REPLAY"
        if self.state == "native":
            return "NATIVE VR"
        if self.state == "paused":
            return "PAUSED"
        if self.calibration and self.calibration.state in ("running", "paused"):
            return "CALIBRATING"
        if self.state == "stopped":
            return "STOPPED"
        return None

    def stats(self) -> Dict[str, Any]:
        cm, pl = self.capture, self.pipeline
        return {"camera": self.camera.info() if self.camera else {}, "proc_fps": pl.proc_fps if pl else None,
                "latency_ms": pl.latency_ms if pl else None, "dropped": pl.frames_dropped if pl else 0,
                "errors": pl.errors if pl else 0, "rec_state": self.recorder.state, "rec_duration": self.recorder.duration_s,
                "rec_dir": str(self.recorder.dir) if self.recorder.dir else None, "rec_pending": self.recorder.pending,
                "rec_error": self.recorder.last_error, "rec_dropped": self.recorder.dropped,
                "cap_counts": dict(cm.counts) if cm else {}, "cap_pending": cm.pending if cm else 0,
                "cap_last": cm.last_success if cm else None, "cap_error": cm.last_error if cm else None,
                "cap_free": cm.disk_free() if cm else None, "out_dir": str(Path(self.out_dir).resolve()),
                "blinks": self.counts["blinks"], "losses": self.counts["losses"], "state": self.state}

    def diagnostics_text(self) -> str:
        env, st = collect_environment(), self.stats()
        L = [f"OS: {env['os']}", f"Python: {env['python']}"] + [f"  {k}: {v or 'NOT INSTALLED'}" for k, v in env["packages"].items()]
        L += [f"Face model: {env['face_model_path']} -> {'present' if env['face_model_present'] else 'MISSING (run scripts/download_models.py)'}",
              f"Session: {self.session_id}   state: {self.state}   provider: {self.settings.get('tracking.provider')}",
              f"Camera: {st['camera']}", f"Pipeline: running={bool(self.pipeline and self.pipeline.running)} fps={st['proc_fps']} "
              f"latency_ms={st['latency_ms']} dropped={st['dropped']} errors={st['errors']} last_error={self.pipeline.last_error if self.pipeline else None}"]
        r = self.latest.record if self.latest else None
        if r:
            for e in (r.left, r.right):
                L.append(f"{e.side}: status={e.status} reason={e.reason} q={e.quality:.2f} provenance={e.provenance}")
            L.append(f"Gaze: {r.gaze.status} calibration={self.calibration_name or 'NOT CALIBRATED'}")
        L += [f"Recording: {st['rec_state']} dir={st['rec_dir']} pending={st['rec_pending']} dropped={st['rec_dropped']} err={st['rec_error']}",
              f"Capture: {st['cap_counts']} pending={st['cap_pending']} err={st['cap_error']}  dir={st['out_dir']}",
              f"VR: {self.vr.status().to_dict() if self.vr else 'no VR provider active'}",
              f"Threads alive: {threading.active_count()}", "Recent warnings/errors:"]
        L += [f"  {time.strftime('%H:%M:%S', time.localtime(t))} {lv} {m}" for t, lv, m in list(RECENT.items)[-15:]]
        return "\n".join(L)

    def shutdown(self):
        self._replay_timer.stop()
        self.close_replay()
        self.stop_tracking()
        if self.capture:
            self.capture.close(); self.capture = None
