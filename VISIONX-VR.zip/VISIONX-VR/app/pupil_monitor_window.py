from __future__ import annotations

import time
from collections import deque
from typing import Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (QDoubleSpinBox, QGroupBox, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
                               QPushButton, QScrollArea, QSlider, QSplitter, QVBoxLayout, QWidget)

from app import actions, theme
from app.components.dialogs import CaptureDetailDialog
from app.components.eye_panel import EyePanel, fmt, pt
from app.components.widgets import CollapsibleSection, SignalHistory, TimeSeriesPlot
from visionx.tracking.base_provider import FrameBundle


class PupilMonitorWindow(QMainWindow):
    """Separate top-level window: consumes the SAME FrameBundles as the dashboard."""

    def __init__(self, controller, manager):
        super().__init__()
        self.c, self.wm = controller, manager
        self.setWindowTitle("Pupil Track & Capture Monitor — VISIONX VR"); self.resize(760, 900)
        self.latest: Optional[FrameBundle] = None
        self.hist = {"left": SignalHistory(), "right": SignalHistory()}
        self.markers = deque(maxlen=300)
        self._tick_n = 0
        self._build()
        self._menus()
        c = controller
        c.bundle_ready.connect(self._on_bundle); c.event_emitted.connect(self._on_event)
        c.capture_finished.connect(self._on_capture); c.state_changed.connect(self._on_state)
        c.recording_changed.connect(lambda *_: self._update_buttons()); c.settings_applied.connect(self._apply_rate)
        self.timer = QTimer(self); self.timer.timeout.connect(self._tick); self._apply_rate()
        self._update_buttons()

    def _apply_rate(self):
        self.timer.start(int(1000 / self.c.settings.get("monitor.update_hz")))

    # ------------------------------------------------------------------ build
    def _build(self):
        c = self.c
        root = QWidget(); lay = QVBoxLayout(root)
        hdr = QHBoxLayout()
        self.h_title = QLabel(f"<b style='color:{theme.CYAN}'>Pupil Track & Capture Monitor</b>")
        self.h_info = QLabel(); self.h_info.setProperty("mono", True)
        self.h_state = QLabel("STOPPED"); self.h_rec = QLabel("")
        bd, bm = QPushButton("Dashboard"), QPushButton("Diagnostics")
        bd.clicked.connect(self.wm.show_main); bm.clicked.connect(self.wm.show_diagnostics)
        for w in (self.h_title, self.h_info): hdr.addWidget(w)
        hdr.addStretch(); hdr.addWidget(self.h_state); hdr.addWidget(self.h_rec); hdr.addWidget(bd); hdr.addWidget(bm)
        lay.addLayout(hdr)
        # eyes
        self.eyes = {s: EyePanel(s, c) for s in ("left", "right")}
        sp = QSplitter(Qt.Orientation.Horizontal); sp.addWidget(self.eyes["left"]); sp.addWidget(self.eyes["right"])
        lay.addWidget(sp, 3)
        # plots
        pw = QWidget(); pl = QVBoxLayout(pw); row = QHBoxLayout()
        row.addWidget(QLabel("Window (s):")); self.win = QDoubleSpinBox(); self.win.setRange(2, 120); self.win.setValue(c.settings.get("monitor.plot_window_s"))
        row.addWidget(self.win)
        for t, f in (("＋", lambda: [p.zoom_in() for p in self.plots.values()]), ("－", lambda: [p.zoom_out() for p in self.plots.values()]),
                     ("Fit", lambda: [p.fit() for p in self.plots.values()])):
            b = QPushButton(t); b.clicked.connect(lambda _=False, f=f: f()); b.setMaximumWidth(48); row.addWidget(b)
        row.addStretch(); pl.addLayout(row)
        ser = [("u (x)", theme.BLUE), ("v (y)", theme.CYAN), ("open", theme.MUTED)]
        self.plots = {s: TimeSeriesPlot(f"{s.capitalize()} eye — pupil u,v (eye widths) & EAR", "eye widths / EAR", ser, (-0.3, 1.0)) for s in ("left", "right")}
        ph = QHBoxLayout(); [ph.addWidget(p) for p in self.plots.values()]; pl.addLayout(ph)
        lay.addWidget(CollapsibleSection("Pupil movement plots (gaps = invalid samples; dashed = events)", pw), 1)
        # gaze
        self.gaze = QLabel(); self.gaze.setProperty("mono", True); self.gaze.setWordWrap(True)
        lay.addWidget(CollapsibleSection("Gaze summary", self.gaze))
        # capture
        cw = QWidget(); cl = QVBoxLayout(cw)
        r1, r2 = QHBoxLayout(), QHBoxLayout()
        self.b = {}
        for key, text, fn in (("sample", "Capture Sample", c.capture_sample), ("image", "Capture Image", c.capture_image),
                              ("recstart", "● Start Recording", lambda: actions.start_recording_dialog(c, self)),
                              ("recpause", "Pause", c.pause_recording), ("recresume", "Resume", c.resume_recording),
                              ("recstop", "■ Stop", c.stop_recording)):
            btn = QPushButton(text); btn.clicked.connect(lambda _=False, f=fn: f()); self.b[key] = btn; (r1 if key in ("sample", "image") else r2).addWidget(btn)
        of = QPushButton("Open folder"); of.clicked.connect(lambda: actions.open_folder(c.out_dir)); r2.addWidget(of)
        ex = QPushButton("Export…"); ex.clicked.connect(lambda: actions.export_dialog(c, self)); self.b["export"] = ex; r2.addWidget(ex)
        r1.addStretch(); cl.addLayout(r1); cl.addLayout(r2)
        self.store = QLabel(); self.store.setProperty("mono", True); self.store.setWordWrap(True); cl.addWidget(self.store)
        self.history = QListWidget(); self.history.setMinimumHeight(110); self.history.itemDoubleClicked.connect(self._inspect)
        ib = QPushButton("Inspect selected capture"); ib.clicked.connect(lambda: self.history.currentItem() and self._inspect(self.history.currentItem()))
        cl.addWidget(QLabel("Recent captures (double-click to inspect stored files):")); cl.addWidget(self.history); cl.addWidget(ib)
        lay.addWidget(CollapsibleSection("Capture, recording & storage", cw))
        # events
        self.events = QListWidget(); self.events.setMinimumHeight(110)
        lay.addWidget(CollapsibleSection("Event timeline", self.events))
        # replay
        rw = QWidget(); rl = QVBoxLayout(rw); rr = QHBoxLayout()
        for t, f in (("Open session…", lambda: actions.open_replay_dialog(c, self)), ("▶", c.replay_play), ("❚❚", c.replay_pause), ("■", c.replay_stop),
                     ("◀", lambda: c.replay_step(-1)), ("▶|", lambda: c.replay_step(1)), ("Summary…", lambda: actions.summary_dialog(c, self)),
                     ("Close replay", c.close_replay)):
            bt = QPushButton(t); bt.clicked.connect(lambda _=False, f=f: f()); rr.addWidget(bt)
        self.slider = QSlider(Qt.Orientation.Horizontal); self.slider.sliderMoved.connect(c.replay_seek)
        self.rlabel = QLabel("No replay open. Numeric replay never shows video unless it was recorded."); self.rlabel.setProperty("muted", True)
        rl.addLayout(rr); rl.addWidget(self.slider); rl.addWidget(self.rlabel)
        lay.addWidget(CollapsibleSection("Replay & session analysis", rw, expanded=False))
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(root); self.setCentralWidget(sc)

    def _menus(self):
        mb, c, wm = self.menuBar(), self.c, self.wm
        mk = lambda t, f: (lambda a: (a.triggered.connect(lambda _=False: f()), a)[1])(QAction(t, self))
        m = mb.addMenu("&Window")
        for t, f in (("Dashboard", wm.show_main), ("Restore default layout", wm.restore_default_layout), ("Diagnostics", wm.show_diagnostics),
                     ("Quit VISIONX VR", wm.request_quit)):
            m.addAction(mk(t, f))
        m = mb.addMenu("&Capture"); m.addAction(mk("Capture Sample", c.capture_sample)); m.addAction(mk("Capture Image", c.capture_image))

    # ------------------------------------------------------------------ data in
    def _on_bundle(self, b: FrameBundle):
        self.latest = b
        for s in ("left", "right"):
            self.hist[s].push(b.record, s)

    def _on_event(self, e):
        self.markers.append((e["ts"], e["type"]))
        extra = ""
        if "duration_ms" in e: extra += f" {e['duration_ms']:.0f}ms"
        if "eye" in e: extra += f" [{e['eye']}]"
        if "amplitude_uv" in e: extra += f" amp {e['amplitude_uv']:.2f}u {e.get('direction', '')}"
        self.events.addItem(f"{time.strftime('%H:%M:%S')}  {e['type']}{extra}")
        if self.events.count() > 300:
            self.events.takeItem(0)
        self.events.scrollToBottom()

    def _on_capture(self, res):
        it = QListWidgetItem(f"{res.capture_id}  {time.strftime('%H:%M:%S', time.localtime(res.timestamp))}  {res.status.upper()}  "
                             f"{res.summary.get('state')}  files={len(res.files)}" + (f"  FAILED: {', '.join(res.failed)}" if res.failed else ""))
        it.setData(Qt.ItemDataRole.UserRole, res); self.history.insertItem(0, it)
        if self.history.count() > 100:
            self.history.takeItem(100)
        self.events.addItem(f"{time.strftime('%H:%M:%S')}  {'capture_saved' if res.status != 'failed' else 'capture_FAILED'} {res.capture_id}")

    def _inspect(self, item):
        res = item.data(Qt.ItemDataRole.UserRole)
        if res:
            CaptureDetailDialog(res, self).exec()

    def _on_state(self, st):
        if st in ("replay", "running", "native", "stopped"):
            if getattr(self, "_mode", None) != st:     # never mix live and replayed samples in the plots
                for h in self.hist.values(): h.clear()
                self.markers.clear()
            self._mode = st
        self._update_buttons()

    def _update_buttons(self):
        c, rs = self.c, self.c.recorder.state
        en = {"sample": c.latest is not None, "image": c.latest is not None and c.latest.frame is not None,
              "recstart": c.state in ("running", "native") and rs == "idle", "recpause": rs == "recording", "recresume": rs == "paused",
              "recstop": rs != "idle", "export": rs == "idle" and (c.last_recording_dir is not None or c.replay is not None)}
        for k, v in en.items(): self.b[k].setEnabled(bool(v))
        self.h_rec.setText({"recording": "<b style='color:#FF5C5C'>● REC</b>", "paused": "<b style='color:#FFB020'>❚❚ PAUSED</b>"}.get(rs, ""))

    # ------------------------------------------------------------------ refresh
    def _tick(self):
        if not self.isVisible():
            return
        self._tick_n += 1
        c, b = self.c, self.latest
        for p in self.eyes.values():
            p.refresh(b)
        st = c.display_status() or (None if b is None else {"tracking": "TRACKING", "low_confidence": "LOW CONFIDENCE", "lost": "LOST", "no_face": "NO FACE"}.get(b.record.state, "LOST"))
        st = st or "STOPPED"
        self.h_state.setText(f"<b style='color:{theme.STATE_HEX.get(st, theme.MUTED)}'>● {st}</b>")
        self.h_info.setText(f"session {c.session_id}  provider {c.settings.get('tracking.provider') if c.state != 'replay' else 'replay'}"
                            + (f"  t={b.record.capture_ts:.2f}s frame {b.record.frame_id}" if b else ""))
        if self._tick_n % 3 == 0 and b is not None:
            now, win = b.record.capture_ts, self.win.value()
            for s, p in self.plots.items():
                p.set_data(now, win, self.hist[s].series(now, win), list(self.markers))
        if self._tick_n % 6 == 0:
            self._update_gaze(b); self._update_store(); self._update_replay()

    def _update_gaze(self, b):
        c = self.c
        if b is None:
            self.gaze.setText("No data."); return
        g, r = b.record.gaze, b.record
        if g.status == "not_calibrated":
            head = "NOT CALIBRATED — showing pupil-relative measurements only (no screen gaze is computed)."
        else:
            head = f"status {g.status.upper()}" + (f" ({g.reason})" if g.reason else "")
        self.gaze.setText("\n".join([
            head, f"profile    : {c.calibration_name or 'none'}   (valid only for this user/camera/seating)",
            f"norm xy    : {pt(g.norm_xy, '.3f')}   screen px {pt(g.screen_xy, '.0f')}" if g.norm_xy else f"gaze ray   : origin {g.origin} dir {g.direction}" if g.direction else "norm xy    : N/A",
            f"validity   : combined={g.valid}  left={r.left.valid}  right={r.right.valid}   quality {fmt(g.quality, '.2f')}",
            f"last valid : {'N/A' if g.last_valid_ts is None else f'{r.capture_ts - g.last_valid_ts:.2f}s before this frame'}",
            f"head pose  : " + ("N/A" if not r.head_pose else f"yaw {r.head_pose['yaw']:+.1f} pitch {r.head_pose['pitch']:+.1f} roll {r.head_pose['roll']:+.1f} deg (approx)")]))

    def _update_store(self):
        s = self.c.stats(); cc = s["cap_counts"]
        free = s["cap_free"]; low = free is not None and free < 500 * 2**20
        lines = [f"samples saved {cc.get('samples', 0)} | eye crops {cc.get('eye_crops', 0)} | annotated frames {cc.get('annotated_frames', 0)} | raw frames {cc.get('raw_frames', 0)}",
                 f"blinks {s['blinks']} | tracking-loss events {s['losses']} | recording {s['rec_state']} {s['rec_duration']:.0f}s | pending writes capture {s['cap_pending']} / recorder {s['rec_pending']}",
                 f"output dir: {s['out_dir']}", f"last successful capture: {'never' if s['cap_last'] is None else time.strftime('%H:%M:%S', time.localtime(s['cap_last']))}"
                 + (f" | disk free {free / 2**30:.1f} GB" if free is not None else "") + ("  ⚠ LOW DISK SPACE" if low else "")]
        if s["cap_error"]: lines.append(f"latest save error: {s['cap_error']}")
        if s["rec_error"]: lines.append(f"recorder error: {s['rec_error']}")
        if s["rec_dropped"]: lines.append(f"⚠ recorder dropped {s['rec_dropped']} records (disk too slow)")
        self.store.setText("\n".join(lines))

    def _update_replay(self):
        rs = self.c.replay
        if rs is None:
            self.rlabel.setText("No replay open."); return
        self.slider.setRange(0, len(rs) - 1)
        if not self.slider.isSliderDown():
            self.slider.blockSignals(True); self.slider.setValue(rs.index); self.slider.blockSignals(False)
        self.rlabel.setText(f"REPLAY {rs.index + 1}/{len(rs)}  t={rs.current.capture_ts - rs.t0:.2f}/{rs.duration_s:.2f}s  video={'yes' if rs.has_video else 'no (numeric data only)'}")

    def closeEvent(self, e):
        self.wm.on_monitor_close(e)
