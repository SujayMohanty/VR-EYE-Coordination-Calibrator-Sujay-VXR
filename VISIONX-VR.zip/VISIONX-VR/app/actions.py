"""UI actions shared by both windows (dialogs wrapping controller operations)."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import QApplication, QFileDialog, QInputDialog, QMessageBox

from app.components.dialogs import CalibrationWindow, SummaryDialog, format_summary
from visionx.calibration.calibration_manager import list_profiles
from visionx.recording.playback import ReplayError, ReplaySession

Yes = QMessageBox.StandardButton.Yes
No = QMessageBox.StandardButton.No


def open_folder(path):
    p = Path(path); p.mkdir(parents=True, exist_ok=True)
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(p.resolve())))


def start_recording_dialog(c, parent):
    if c.state not in ("running", "native"):
        QMessageBox.information(parent, "Recording", "Start tracking first, then start recording."); return
    if c.recorder.state != "idle":
        return
    if QMessageBox.question(parent, "Start recording?", c.recording_description() + "\n\nStart recording now?", Yes | No, No) == Yes:
        c.start_recording()


def select_camera_dialog(c, parent):
    QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
    try:
        cams = c.probe()
    finally:
        QApplication.restoreOverrideCursor()
    if not cams:
        QMessageBox.warning(parent, "Cameras", "No camera could be opened. It may be in use by another application, "
                                               "unplugged, or blocked by Windows privacy settings."); return
    items = [f"Camera {x['index']}" + (" (in use by VISIONX)" if x["in_use_by_app"] else f" — {x['width']}x{x['height']}") for x in cams]
    cur = next((i for i, x in enumerate(cams) if x["index"] == c.settings.get("camera.index")), 0)
    item, ok = QInputDialog.getItem(parent, "Select camera", "Camera:", items, cur, False)
    if ok:
        c.select_camera(cams[items.index(item)]["index"]); c.settings.save()


def open_replay_dialog(c, parent):
    d = QFileDialog.getExistingDirectory(parent, "Open recorded session folder (contains records.jsonl)", c.out_dir)
    if d:
        c.open_replay(d)


def export_dialog(c, parent):
    src = str(c.replay.dir) if c.replay else (str(c.last_recording_dir) if c.last_recording_dir else "")
    if c.recorder.state != "idle":
        QMessageBox.information(parent, "Export", "Stop the recording before exporting it."); return
    if not src:
        src = QFileDialog.getExistingDirectory(parent, "Session folder to export", c.out_dir)
        if not src:
            return
    fmt, ok = QInputDialog.getItem(parent, "Export session", "Format:", ["csv", "json", "jsonl"], 0, False)
    if ok:
        p = c.export(src, fmt, str(Path(src) / f"export.{fmt}"))
        if p:
            QMessageBox.information(parent, "Export complete", f"Written to:\n{p}")


def summary_dialog(c, parent):
    try:
        if c.replay:
            d = c.replay.summary()
        elif c.last_recording_dir and c.recorder.state == "idle":
            rs = ReplaySession(str(c.last_recording_dir)); d = rs.summary(); rs.close()
        else:
            d = {"note": "No finished recording or open replay. Showing live counters.", **c.stats()}
            d.pop("camera", None)
    except (ReplayError, OSError) as e:
        QMessageBox.warning(parent, "Session summary", str(e)); return
    SummaryDialog("Session summary", format_summary(d), parent).exec()


def calibration_flow(c, parent, validate=False, points=None):
    scr = (parent.screen() if parent is not None else QGuiApplication.primaryScreen())
    c.screen_size = (scr.size().width(), scr.size().height())
    m = c.start_calibration(validate, points)
    if m is None:
        return
    c._cal_win = CalibrationWindow(c, m, scr, on_close=lambda mgr: _calibration_done(c, parent, mgr))


def _calibration_done(c, parent, m):
    c.calibration_changed.emit()
    if m.state == "cancelled":
        QMessageBox.information(parent, "Calibration", "Cancelled."); return
    if m.state == "failed":
        QMessageBox.warning(parent, "Calibration failed", m.error or "unknown error"); return
    if m.state != "done":
        return
    if m.mode == "validate":
        mt = m.metrics
        SummaryDialog("Validation result", f"Mean accuracy: {mt['mean_accuracy_norm']:.3f} (normalised) ≈ {mt['mean_accuracy_px']:.0f}px\n"
                      f"Worst target: {mt['max_accuracy_norm']:.3f}\n\n{mt['note']}", parent).exec(); return
    mt = m.metrics
    txt = (f"Model degree {mt['degree']}; {mt['n_targets']} targets, {mt['n_samples']} samples.\n"
           f"Cross-validated error (leave-one-target-out): {mt['cv_mean_error_norm']:.3f} normalised ≈ {mt['cv_mean_error_px']:.0f}px "
           f"(worst target {mt['cv_max_error_norm']:.3f}).\nTraining RMSE: {mt['train_rmse_norm']:.3f}.\n"
           f"Skipped targets: {mt['targets_skipped'] or 'none'}.\n\nThis is a webcam screen calibration: valid only for this user, camera and seating.")
    SummaryDialog("Calibration complete", txt, parent).exec()
    name, ok = QInputDialog.getText(parent, "Save calibration profile", "Profile name (blank = don't save):", text=m.model.calibration_id)
    if ok and name.strip():
        c.save_profile(name.strip())


def profile_load_dialog(c, parent):
    names = list_profiles(c.profile_dir)
    if not names:
        QMessageBox.information(parent, "Profiles", "No saved calibration profiles."); return
    n, ok = QInputDialog.getItem(parent, "Load calibration profile", "Profile:", names, 0, False)
    if ok:
        c.load_profile(n)


def profile_delete_dialog(c, parent):
    names = list_profiles(c.profile_dir)
    if not names:
        QMessageBox.information(parent, "Profiles", "No saved calibration profiles."); return
    n, ok = QInputDialog.getItem(parent, "Delete calibration profile", "Profile:", names, 0, False)
    if ok and QMessageBox.question(parent, "Delete profile", f"Permanently delete '{n}'?", Yes | No, No) == Yes:
        c.delete_profile(n)


def profile_save_dialog(c, parent):
    if c.gaze_model is None:
        QMessageBox.information(parent, "Profiles", "Calibrate first."); return
    n, ok = QInputDialog.getText(parent, "Save calibration profile", "Profile name:", text=c.gaze_model.calibration_id)
    if ok and n.strip():
        c.save_profile(n.strip())


def delete_captures_dialog(c, parent):
    d = Path(c.out_dir)
    if QMessageBox.question(parent, "Open data folder", f"Data is stored under:\n{d.resolve()}\n\nOpen the folder to review or delete files?", Yes | No) == Yes:
        open_folder(d)
