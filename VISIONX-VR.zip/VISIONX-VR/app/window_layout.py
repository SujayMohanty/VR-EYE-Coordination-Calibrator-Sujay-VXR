"""Pure-Python window arrangement logic (no Qt import) so it is unit-testable."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple


@dataclass(frozen=True)
class Rect:
    x: int
    y: int
    w: int
    h: int

    def intersects_area(self, o: "Rect") -> int:
        iw = min(self.x + self.w, o.x + o.w) - max(self.x, o.x)
        ih = min(self.y + self.h, o.y + o.h) - max(self.y, o.y)
        return max(0, iw) * max(0, ih)


MAIN_DEFAULT = (1200, 800)
MONITOR_DEFAULT = (760, 900)


def default_layout(screens: Sequence[Rect], main_size=MAIN_DEFAULT, mon_size=MONITOR_DEFAULT, gap: int = 8) -> Dict[str, Rect]:
    """Side by side when they fit; monitor on a second screen if one exists; otherwise shrink both."""
    if not screens:
        screens = [Rect(0, 0, 1920, 1080)]
    s = screens[0]
    mw, mh = main_size
    pw, ph = mon_size
    if s.w >= mw + pw + gap:
        h_main, h_mon = min(mh, s.h), min(ph, s.h)
        return {"main": Rect(s.x, s.y, mw, h_main), "monitor": Rect(s.x + mw + gap, s.y, pw, h_mon)}
    if len(screens) > 1:
        s2 = screens[1]
        return {"main": Rect(s.x, s.y, min(mw, s.w), min(mh, s.h)),
                "monitor": Rect(s2.x, s2.y, min(pw, s2.w), min(ph, s2.h))}
    total = mw + pw
    w_main = int((s.w - gap) * mw / total)
    w_mon = s.w - gap - w_main
    return {"main": Rect(s.x, s.y, w_main, min(mh, s.h)), "monitor": Rect(s.x + w_main + gap, s.y, w_mon, min(ph, s.h))}


def ensure_visible(r: Rect, screens: Sequence[Rect], min_visible: int = 100 * 100) -> Optional[Rect]:
    """Return r nudged to be visible, or None if a saved geometry is unusable (e.g. monitor unplugged)."""
    if r.w < 200 or r.h < 150:
        return None
    best = max(screens, key=lambda s: r.intersects_area(s), default=None)
    if best is None or r.intersects_area(best) < min_visible:
        return None
    x = min(max(r.x, best.x - r.w + 100), best.x + best.w - 100)
    y = min(max(r.y, best.y), best.y + best.h - 60)
    return Rect(x, y, r.w, r.h)
