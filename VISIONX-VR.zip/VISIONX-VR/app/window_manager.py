from __future__ import annotations

import logging
from typing import List

from PySide6.QtCore import QObject, QRect
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QApplication, QMessageBox

from app.components.dialogs import DiagnosticsDialog
from app.main_window import MainWindow
from app.pupil_monitor_window import PupilMonitorWindow
from app.window_layout import MAIN_DEFAULT, MONITOR_DEFAULT, Rect, default_layout, ensure_visible

log = logging.getLogger("visionx.windows")


class WindowManager(QObject):
    """Owns window lifecycle. One monitor instance, created lazily, hidden (not destroyed) on close, so
    reopening never creates a second camera/tracker (those belong to the SessionController)."""

    def __init__(self, controller):
        super().__init__()
        self.c = controller
        self.main = MainWindow(controller, self)
        self.monitor: PupilMonitorWindow | None = None
        self.diag: DiagnosticsDialog | None = None
        self._quitting = False

    # ------------------------------------------------------------------ geometry
    def _screens(self) -> List[Rect]:
        scr = QGuiApplication.screens()
        prim = QGuiApplication.primaryScreen()
        scr = sorted(scr, key=lambda s: 0 if s == prim else 1)
        out = []
        for s in scr:
            g = s.availableGeometry(); out.append(Rect(g.x(), g.y(), g.width(), g.height()))
        return out

    def _place(self, win, key, rect: Rect):
        win.setGeometry(QRect(rect.x, rect.y, rect.w, rect.h))

    def _saved(self, key):
        v = self.c.settings.window_state.get(key)
        if isinstance(v, list) and len(v) == 4 and all(isinstance(x, int) for x in v):
            return ensure_visible(Rect(*v), self._screens())
        return None

    def show_all(self, open_monitor: bool = True):
        lay = default_layout(self._screens())
        m = self._saved("main") or lay["main"]
        self._place(self.main, "main", m); self.main.show()
        if open_monitor:
            self.show_monitor(initial=True)

    def show_main(self):
        self.main.show()
        if self.main.isMinimized():
            self.main.showNormal()
        self.main.raise_(); self.main.activateWindow()

    def show_monitor(self, initial: bool = False):
        first = self.monitor is None
        if first:
            self.monitor = PupilMonitorWindow(self.c, self)
            lay = default_layout(self._screens())
            self._place(self.monitor, "monitor", self._saved("monitor") or lay["monitor"])
        self.monitor.show()
        if self.monitor.isMinimized():
            self.monitor.showNormal()
        self.monitor.raise_(); self.monitor.activateWindow()

    def show_diagnostics(self):
        if self.diag is None:
            self.diag = DiagnosticsDialog(self.c)
        self.diag.show(); self.diag.raise_(); self.diag.activateWindow()

    def restore_default_layout(self):
        lay = default_layout(self._screens(), MAIN_DEFAULT, MONITOR_DEFAULT)
        self.show_monitor()
        self.main.showNormal(); self.monitor.showNormal()
        self._place(self.main, "main", lay["main"]); self._place(self.monitor, "monitor", lay["monitor"])
        self.main.show(); self.monitor.show()

    def save_state(self):
        ws = self.c.settings.window_state
        for key, w in (("main", self.main), ("monitor", self.monitor)):
            if w is not None and not w.isMinimized():
                g = w.geometry(); ws[key] = [g.x(), g.y(), g.width(), g.height()]
        try:
            self.c.settings.save()
        except OSError as e:
            log.warning("could not save settings: %s", e)

    # ------------------------------------------------------------------ closing
    def request_quit(self):
        if self._quitting:
            return
        if self.c.recorder.state != "idle":
            if QMessageBox.question(self.main, "Recording active", "A recording is active. Stop it and quit?") != QMessageBox.StandardButton.Yes:
                return
        self._quitting = True
        self.save_state()
        self.c.shutdown()
        QApplication.quit()

    def on_main_close(self, event):
        if self._quitting:
            event.accept(); return
        if self.monitor is not None and self.monitor.isVisible():
            event.ignore(); self.main.hide()          # monitor keeps working; Window menu reopens the dashboard
            return
        event.ignore(); self.request_quit()

    def on_monitor_close(self, event):
        if self._quitting:
            event.accept(); return
        event.ignore(); self.monitor.hide()           # tracking continues; no worker is touched
        if not self.main.isVisible():
            self.request_quit()
