from __future__ import annotations

import time
from typing import Dict, Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QActionGroup
from PySide6.QtWidgets import (QCheckBox, QFormLayout, QGroupBox, QLabel, QMainWindow, QMessageBox, QScrollArea, QSplitter,
                               QToolBar, QVBoxLayout, QWidget)

from app import actions, theme
from app.components.dialogs import SettingsDialog
from app.components.widgets import ImageView
from visionx.render.overlay import put_text, render_main
from visionx.tracking.base_provider import FrameBundle
from visionx.vr.openxr_adapter import probe_openxr

OVERLAY_TOGGLES = [("Face box", "face_box"), ("Facial landmarks", "landmarks"), ("Eye outlines", "eye_outline"),
                   ("Blue pupil reticle", "reticle"), ("Iris marker", "iris"), ("Movement trail", "trail"),
                   ("Gaze indicator", "gaze"), ("Coordinates", "coords"), ("Head-pose arrow", "head_pose")]

GUIDE = """VISIONX VR quick guide

1. Tracking ▸ Start Tracking (camera index/resolution: Camera ▸ Select Camera, Settings ▸ Camera).
2. The blue reticle appears only while a pupil estimate is ACCEPTED. LOW CONFIDENCE shows a hollow ring; LOST shows text only.
3. Pupil Monitor opens a second window with magnified eyes, plots, capture inspector and event timeline.
4. Calibration (needs tracking) gives screen gaze. Without it pupil values are eye-relative and gaze says NOT CALIBRATED.
5. Recording never starts silently: you confirm what will be saved. Raw video is opt-in (Settings ▸ Recording).
6. Everything is processed locally. Nothing is uploaded.

Limits: webcam pupil localisation depends on lighting/resolution; dark irises may give LOW CONFIDENCE.
Saccade/fixation events are approximate at webcam rates. Pupil size is in apparent pixels, not millimetres."""


class MainWindow(QMainWindow):
    def __init__(self, controller, manager):
        super().__init__()
        self.c, self.wm = controller, manager
        self.setWindowTitle("VISIONX VR — Main Tracking Dashboard"); self.resize(1200, 800)
        self.latest: Optional[FrameBundle] = None
        self.cam_view = ImageView((480, 320))
        self.metric_lbl: Dict[str, QLabel] = {}
        self._build_central(); self._build_actions(); self._build_menus(); self._build_toolbar()
        self.rec_lbl = QLabel(""); self.statusBar().addPermanentWidget(self.rec_lbl)
        c = controller
        c.bundle_ready.connect(self._on_bundle); c.state_changed.connect(self._update_controls)
        c.recording_changed.connect(self._update_controls); c.calibration_changed.connect(self._update_controls)
        c.message.connect(self._on_message); c.capture_finished.connect(lambda _: self._update_controls())
        self.timer = QTimer(self); self.timer.timeout.connect(self._tick); self._apply_rate()
        c.settings_applied.connect(self._apply_rate)
        self.mtimer = QTimer(self); self.mtimer.timeout.connect(self._update_metrics); self.mtimer.start(250)
        self._update_controls()

    def _apply_rate(self):
        self.timer.start(int(1000 / self.c.settings.get("monitor.update_hz")))

    # ------------------------------------------------------------------ layout
    def _build_central(self):
        side = QWidget(); sl = QVBoxLayout(side)
        box = QGroupBox("Live metrics"); form = QFormLayout(box)
        for key, label in [("camera", "Camera"), ("res", "Resolution"), ("cfps", "Capture FPS"), ("pfps", "Tracking FPS"),
                           ("lat", "Latency (capture→record)"), ("face", "Face"), ("le", "Left eye"), ("re", "Right eye"),
                           ("lc", "Left confidence"), ("rc", "Right confidence"), ("gaze", "Gaze"), ("cal", "Calibration"),
                           ("prov", "Provider"), ("dur", "Session duration"), ("samples", "Captured samples"),
                           ("images", "Captured images"), ("rec", "Recording"), ("loss", "Tracking loss")]:
            l = QLabel("N/A"); l.setProperty("mono", True); l.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.metric_lbl[key] = l; form.addRow(label, l)
        ov = QGroupBox("Overlays"); ol = QVBoxLayout(ov)
        for text, key in OVERLAY_TOGGLES:
            cb = QCheckBox(text); cb.setChecked(self.c.settings.get(f"overlay.{key}"))
            cb.toggled.connect(lambda on, k=key: self._set_overlay(k, on)); ol.addWidget(cb)
        for lab in ("trail_left", "trail_right"):
            cb = QCheckBox("Left trail" if lab.endswith("left") else "Right trail"); cb.setChecked(self.c.settings.get(f"overlay.{lab}"))
            cb.toggled.connect(lambda on, k=lab: self._set_overlay(k, on)); ol.addWidget(cb)
        sl.addWidget(box); sl.addWidget(ov); sl.addStretch()
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(side); sc.setMinimumWidth(300)
        sp = QSplitter(Qt.Orientation.Horizontal); sp.addWidget(self.cam_view); sp.addWidget(sc); sp.setStretchFactor(0, 4); sp.setStretchFactor(1, 1)
        self.setCentralWidget(sp)

    def _set_overlay(self, key, on):
        self.c.settings.set(f"overlay.{key}", on); self.c.apply_settings()

    def _act(self, text, fn, tip="", checkable=False, shortcut=None):
        a = QAction(text, self); a.setToolTip(tip or text); a.setCheckable(checkable)
        a.triggered.connect(lambda _=False: fn())
        if shortcut:
            a.setShortcut(shortcut)
        return a

    def _build_actions(self):
        c, wm = self.c, self.wm
        A = self._act
        self.a = dict(
            start=A("Start Tracking", c.start_tracking, "Open the camera and start tracking", shortcut="Ctrl+T"),
            pause=A("Pause", c.pause_tracking), resume=A("Resume", c.resume_tracking), stop=A("Stop Tracking", c.stop_tracking),
            camera=A("Select Camera…", lambda: actions.select_camera_dialog(c, self)),
            monitor=A("Open Pupil Monitor", wm.show_monitor, shortcut="Ctrl+M"),
            calib=A("Start Calibration", lambda: actions.calibration_flow(c, self)),
            recalib=A("Recalibrate", lambda: actions.calibration_flow(c, self)),
            validate=A("Validate Calibration", lambda: actions.calibration_flow(c, self, True)),
            sample=A("Capture Sample", c.capture_sample, shortcut="Ctrl+S"), image=A("Capture Image", c.capture_image, shortcut="Ctrl+I"),
            recstart=A("Start Recording", lambda: actions.start_recording_dialog(c, self)),
            recpause=A("Pause Recording", c.pause_recording), recresume=A("Resume Recording", c.resume_recording),
            recstop=A("Stop Recording", c.stop_recording),
            export=A("Export Data…", lambda: actions.export_dialog(c, self)),
            diag=A("Open Diagnostics", wm.show_diagnostics), settings=A("Settings…", lambda: SettingsDialog(c, self).exec()))

    def _build_menus(self):
        mb, a, c, wm = self.menuBar(), self.a, self.c, self.wm
        A = self._act
        m = mb.addMenu("&Dashboard"); m.addAction(A("Show Dashboard", wm.show_main)); m.addAction(a["monitor"]); m.addSeparator()
        m.addAction(A("Restore Default Window Layout", wm.restore_default_layout)); m.addAction(A("Quit VISIONX VR", wm.request_quit))
        m = mb.addMenu("&Pupil Monitor"); m.addAction(a["monitor"])
        m = mb.addMenu("&Camera"); m.addAction(a["camera"])
        mir = A("Mirrored preview", lambda: None, checkable=True); mir.setChecked(c.settings.get("camera.mirror"))
        mir.toggled.connect(lambda on: (c.settings.set("camera.mirror", on), c.apply_settings())); m.addAction(mir)
        m = mb.addMenu("C&alibration")
        for t, n in (("5-point", 5), ("9-point", 9), ("13-point", 13)):
            m.addAction(A(f"Start {t} calibration", lambda n=n: actions.calibration_flow(c, self, False, n)))
        m.addAction(a["recalib"]); m.addAction(a["validate"]); m.addSeparator()
        m.addAction(A("Save Profile…", lambda: actions.profile_save_dialog(c, self)))
        m.addAction(A("Load Profile…", lambda: actions.profile_load_dialog(c, self)))
        m.addAction(A("Delete Profile…", lambda: actions.profile_delete_dialog(c, self)))
        m.addAction(A("Clear / Reset Calibration", c.clear_calibration))
        m = mb.addMenu("&Tracking")
        for k in ("start", "pause", "resume", "stop"):
            m.addAction(a[k])
        sub = m.addMenu("Performance preset"); g = QActionGroup(self)
        for p in ("performance", "balanced", "precision"):
            x = A(p.capitalize(), lambda p=p: (c.settings.apply_preset(p), c.apply_settings(), self._notice("Preset applies fully on next Start Tracking.")), checkable=True)
            x.setChecked(c.settings.get("tracking.preset") == p); g.addAction(x); sub.addAction(x)
        m = mb.addMenu("Ca&pture"); m.addAction(a["sample"]); m.addAction(a["image"])
        m.addAction(A("Open Capture Folder", lambda: actions.open_folder(c.out_dir + "/captures")))
        m = mb.addMenu("&Recording")
        for k in ("recstart", "recpause", "recresume", "recstop"):
            m.addAction(a[k])
        m.addAction(A("Open Recording Folder", lambda: actions.open_folder(c.last_recording_dir or c.out_dir)))
        m.addAction(A("Open Session for Replay…", lambda: actions.open_replay_dialog(c, self))); m.addAction(A("Close Replay", c.close_replay))
        m = mb.addMenu("A&nalytics"); m.addAction(A("Session Summary…", lambda: actions.summary_dialog(c, self))); m.addAction(a["export"])
        m = mb.addMenu("&VR Integration"); sub = m.addMenu("Provider (applies on next Start)"); g = QActionGroup(self)
        for p, lab in (("webcam", "Webcam"), ("udp_bridge", "Native VR via UDP bridge"), ("openxr", "OpenXR (capability probe only)")):
            x = A(lab, lambda p=p: c.settings.set("tracking.provider", p), checkable=True); x.setChecked(c.settings.get("tracking.provider") == p)
            g.addAction(x); sub.addAction(x)
        m.addAction(A("Probe OpenXR…", self._probe_xr))
        m.addAction(A("How native gaze reaches VISIONX…", lambda: QMessageBox.information(self, "Native VR", (
            "Native headset gaze is received only from a real headset app (see unity/README.md) over a local UDP bridge "
            f"on 127.0.0.1:{c.settings.get('vr.udp_port')}. Webcam estimates are never presented as native gaze. "
            "Select 'Native VR via UDP bridge' and press Start Tracking."))))
        m = mb.addMenu("D&iagnostics"); m.addAction(a["diag"])
        m = mb.addMenu("&Settings"); m.addAction(a["settings"])
        m.addAction(A("Reset Settings", self._reset_settings)); m.addAction(A("Restore Default Window Layout", wm.restore_default_layout))
        m = mb.addMenu("&Help"); m.addAction(A("Quick Guide", lambda: QMessageBox.information(self, "Quick guide", GUIDE)))
        m.addAction(A("About", lambda: QMessageBox.about(self, "VISIONX VR", "VISIONX VR 1.0\nLocal, real-time webcam eye tracking with a pupil-monitor workstation.\nNo cloud, no telemetry.")))

    def _build_toolbar(self):
        tb = QToolBar("Controls"); tb.setMovable(False); self.addToolBar(tb); a = self.a
        for k in ("start", "pause", "resume", "stop", "camera", "monitor", "calib", "recalib", "sample", "image", "recstart", "recstop", "export", "diag", "settings"):
            tb.addAction(a[k])
            if k in ("stop", "monitor", "recalib", "image", "recstop", "export"):
                tb.addSeparator()

    def _probe_xr(self):
        st = probe_openxr()
        QMessageBox.information(self, "OpenXR probe", "\n".join(f"{k}: {v}" for k, v in st.to_dict().items()))

    def _reset_settings(self):
        if QMessageBox.question(self, "Reset settings", "Reset ALL settings to defaults?") == QMessageBox.StandardButton.Yes:
            self.c.settings.reset(); self.c.apply_settings(); self.c.settings.save()

    # ------------------------------------------------------------------ state
    def _notice(self, t): self.statusBar().showMessage(t, 6000)

    def _on_message(self, text, level):
        self.statusBar().setStyleSheet(f"color:{ {'error': theme.BAD, 'warning': theme.WARN}.get(level, '#DCE6F5') };")
        self.statusBar().showMessage(text.replace("\n", " "), 12000)
        if level == "error":
            QMessageBox.warning(self, "VISIONX VR", text)

    _prev_state = "stopped"

    def _update_controls(self, *_):
        c, a = self.c, self.a
        st, rs = c.state, c.recorder.state
        if st != self._prev_state:
            if st in ("running", "native"):
                self._t0 = time.time()
            self._prev_state = st
        live, active = st in ("running", "paused"), st in ("running", "paused", "native")
        rules = {
            "start": (st in ("stopped", "replay"), "Already running."), "pause": (st == "running", "Requires running tracking."),
            "resume": (st == "paused", "Tracking is not paused."), "stop": (active, "Tracking is not running."),
            "calib": (st == "running", "Start (and don't pause) webcam tracking first."), "recalib": (st == "running", "Start webcam tracking first."),
            "validate": (st == "running" and c.gaze_model is not None, "Needs running tracking and a calibration/profile."),
            "sample": (c.latest is not None, "No tracking record yet."), "image": (c.latest is not None and c.latest.frame is not None, "Needs a camera frame."),
            "recstart": (st in ("running", "native") and rs == "idle", "Start tracking first; or a recording is already active."),
            "recpause": (rs == "recording", "Not recording."), "recresume": (rs == "paused", "Recording is not paused."),
            "recstop": (rs != "idle", "Not recording."),
            "export": (rs == "idle" and (c.last_recording_dir is not None or c.replay is not None), "Record or open a session first (stop any active recording)."),
        }
        for k, (ok, why) in rules.items():
            a[k].setEnabled(bool(ok)); a[k].setToolTip(a[k].text().replace("&", "") + ("" if ok else f"  —  disabled: {why}"))
        self.rec_lbl.setText({"recording": "<span style='color:#FF5C5C'>● REC</span>", "paused": "<span style='color:#FFB020'>❚❚ REC PAUSED</span>"}.get(rs, ""))

    def _on_bundle(self, b: FrameBundle):
        self.latest = b

    def _tick(self):
        if not self.isVisible():
            return
        c = self.c
        w, h = max(64, self.cam_view.width()), max(48, self.cam_view.height())
        msg = {"stopped": "Press Start Tracking", "native": "Native VR gaze mode — no camera image"}.get(c.state, "Waiting for camera frames…")
        if c.camera and c.camera.state != "streaming":
            msg = f"Camera {c.camera.state}: {c.camera.detail[:90]}"
        b = self.latest if c.state != "stopped" else None
        img = render_main(b, (w, h), c.overlay_options(), c.trails, c.display_status(), msg)
        if c.state == "running" and b is not None and b.mode == "live" and time.monotonic() - b.record.capture_ts > 1.0:
            put_text(img, "NO RECENT FRAMES (camera stalled?)", (12, 56), 0.5, (70, 70, 235))
        self.cam_view.set_image(img)

    def _update_metrics(self):
        if not self.isVisible():
            return
        c, L, st = self.c, self.metric_lbl, self.c.stats()
        cam, r = st["camera"], (self.latest.record if self.latest else None)
        f = lambda v, s=".1f": "N/A" if v is None else format(v, s)
        L["camera"].setText(f"{cam.get('name') or 'N/A'} [{cam.get('state', '-')}]")
        L["res"].setText(f"{cam.get('width')}x{cam.get('height')}" if cam.get("width") else "N/A")
        L["cfps"].setText(f(cam.get("capture_fps") or None)); L["pfps"].setText(f(st["proc_fps"] or None))
        L["lat"].setText(f(st["latency_ms"]) + " ms" if st["latency_ms"] is not None else "N/A")
        if r is None:
            for k in ("face", "le", "re", "lc", "rc", "gaze"):
                L[k].setText("N/A")
        else:
            L["face"].setText("detected" if r.face_detected else "NOT DETECTED")
            for s, k, kc in (("left", "le", "lc"), ("right", "re", "rc")):
                e = r.eye(s); L[k].setText(f"{e.status.upper()}" + (f" ({e.reason})" if e.reason else "")); L[kc].setText(f"{e.quality:.2f}")
            L["gaze"].setText(("valid " + (f"({r.gaze.norm_xy[0]:.2f}, {r.gaze.norm_xy[1]:.2f})" if r.gaze.norm_xy else "(native ray)")) if r.gaze.valid else r.gaze.status.upper() + (f" ({r.gaze.reason})" if r.gaze.reason else ""))
        L["cal"].setText(c.calibration_name or "NOT CALIBRATED")
        L["prov"].setText({"native": "Native VR (UDP bridge)", "replay": "Replay"}.get(c.state, c.settings.get("tracking.provider")))
        L["dur"].setText(time.strftime("%H:%M:%S", time.gmtime(time.time() - self._t0)) if c.state in ("running", "paused", "native") else "N/A")
        cc = st["cap_counts"]; L["samples"].setText(str(cc.get("samples", 0)))
        L["images"].setText(str(cc.get("eye_crops", 0) + cc.get("annotated_frames", 0) + cc.get("raw_frames", 0)))
        L["rec"].setText(st["rec_state"].upper() + (f" {st['rec_duration']:.0f}s" if st["rec_state"] != "idle" else ""))
        L["loss"].setText(f"{st['losses']} events, {st['blinks']} blinks")

    _t0 = time.time()

    def closeEvent(self, e):
        self.wm.on_main_close(e)
