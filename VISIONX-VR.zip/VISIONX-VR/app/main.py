"""VISIONX VR entry point:  python -m app.main  [--source clip.mp4] [--no-monitor] [--autostart] [--reset-settings]"""
from __future__ import annotations

import argparse
import logging
import sys


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="visionx")
    ap.add_argument("--source", help="video file instead of a camera (development / demo)")
    ap.add_argument("--no-monitor", action="store_true", help="do not open the Pupil Monitor at launch")
    ap.add_argument("--autostart", action="store_true", help="start tracking immediately")
    ap.add_argument("--reset-settings", action="store_true")
    ap.add_argument("--offscreen", action="store_true", help="Qt offscreen platform (CI)")
    args = ap.parse_args(argv)
    if args.offscreen:
        import os; os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        print("PySide6 is not installed. Run: python -m pip install -r requirements.txt", file=sys.stderr)
        return 2
    from app import theme
    from app.session_controller import SessionController
    from app.window_manager import WindowManager
    from visionx.config import Settings, user_config_path
    from visionx.utils.logging_config import setup_logging

    setup_logging(str(user_config_path().parent / "logs"))
    log = logging.getLogger("visionx")
    settings = Settings() if args.reset_settings else Settings.load()
    for err in getattr(settings, "errors", []):
        log.warning("settings: %s", err)
    app = QApplication(sys.argv[:1])
    app.setApplicationName("VISIONX VR"); app.setStyleSheet(theme.STYLE)
    app.setQuitOnLastWindowClosed(False)
    controller = SessionController(settings, args.source)
    app.aboutToQuit.connect(controller.shutdown)
    wm = WindowManager(controller)
    wm.show_all(settings.get("monitor.auto_open") and not args.no_monitor)
    if args.autostart:
        controller.start_tracking()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
