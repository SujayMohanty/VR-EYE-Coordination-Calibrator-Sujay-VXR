NAVY, PANEL, BORDER = "#08111F", "#0E1B30", "#1F3354"
BLUE, CYAN, SECOND, MUTED = "#00B7FF", "#40E7FF", "#167DFF", "#8198B5"
GOOD, WARN, BAD = "#35D07F", "#FFB020", "#FF5C5C"

STYLE = f"""
QWidget {{ background:{NAVY}; color:#DCE6F5; font-family:'Segoe UI','Inter',sans-serif; font-size:10pt; }}
QMainWindow, QDialog {{ background:{NAVY}; }}
QGroupBox {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:8px; margin-top:14px; padding:8px; }}
QGroupBox::title {{ subcontrol-origin:margin; left:10px; padding:0 6px; color:{CYAN}; font-weight:600; }}
QPushButton, QToolButton {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:6px; padding:5px 10px; }}
QPushButton:hover, QToolButton:hover {{ border-color:{BLUE}; }}
QPushButton:disabled, QToolButton:disabled {{ color:#4E5D75; border-color:#16233A; }}
QPushButton:checked, QToolButton:checked {{ background:{SECOND}; border-color:{CYAN}; }}
QMenuBar, QMenu, QToolBar, QStatusBar {{ background:{PANEL}; }}
QMenu::item:selected, QMenuBar::item:selected {{ background:{SECOND}; }}
QMenu::item:disabled {{ color:#4E5D75; }}
QToolBar {{ border-bottom:1px solid {BORDER}; spacing:4px; padding:4px; }}
QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QPlainTextEdit, QListWidget, QTextEdit {{
    background:#0A1527; border:1px solid {BORDER}; border-radius:5px; padding:3px; }}
QTabWidget::pane {{ border:1px solid {BORDER}; }}
QTabBar::tab {{ background:{PANEL}; padding:6px 12px; border:1px solid {BORDER}; }}
QTabBar::tab:selected {{ background:{SECOND}; }}
QLabel[mono="true"] {{ font-family:Consolas,'Cascadia Mono',monospace; font-size:9pt; }}
QLabel[muted="true"] {{ color:{MUTED}; }}
QScrollArea {{ border:none; }}
QSlider::groove:horizontal {{ height:4px; background:{BORDER}; }}
QSlider::handle:horizontal {{ background:{CYAN}; width:12px; margin:-5px 0; border-radius:6px; }}
"""
STATE_HEX = {"TRACKING": BLUE, "LOW CONFIDENCE": WARN, "LOST": BAD, "NO FACE": BAD, "CALIBRATING": "#BE78E6",
             "PAUSED": "#AAAAAA", "REPLAY": "#3CC8C8", "NATIVE VR": "#F064F0", "STOPPED": "#787878"}
